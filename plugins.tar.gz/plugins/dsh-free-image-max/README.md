# dsh-free-image-max（极速生图）

给 **dsh-free-image** 加的一层优化，不换工具、不抢注册：模型看到的仍然是
`image_generate`，参数表、结果卡片、工作区路径都不变；变的是**怎么把这张图做出来**。

一句话：**公网优先（实测 6–8 秒），提示词自动扩写/翻译，额度按 45 秒排队，交付前逐字节检查，
失败只重试该重试的那一次；公网不可用时才落到本机 SD（8GB M1 实测 512×512/12 步 65.8 秒）。**

> 为什么强调"公网优先"：dsh-free-image 1.1 起会**本机 SD 优先**。本地没有额度、没有水印，
> 但这台机器上一张要 1 分钟左右，而公网免费档是 6–8 秒。本插件的 `backend: auto` 把顺序
> 反过来：先用公网，公网额度/服务失败时才探本机。
> 想要本机优先（无水印、可离线）就把 `backend` 设成 `local`。

## 实测现状（2026-10-25，本机）

| 事实 | 实测 |
|---|---|
| 公网免费档 | 匿名可用，但 **1 张新图 / 45 秒 / IP**；额度内 200，超额 `402 FREE_LIMIT` + `Retry-After` |
| 公网实际模型 | 服务端只渲染 `sana`（DreamShaper 8 LCM 别名）；`model=flux` 也会被映射到 sana |
| 公网新图 | 768×768 或 1024×576，**6.7–8.0 秒**，右下角有 pollinations.ai 水印 |
| 公网缓存命中 | 同 prompt+seed 再请求，`x-cache: HIT`，**1.2–1.7 秒** |
| 公网失败 | 402 在 0.7–0.9 秒内返回，`retry-after` 33–44 秒 |
| 本机 SD | AWPainting v1.2，512×512 / 12 步 / DPM++ 2M Karras = **65.8 秒**，无水印 |
| 非 ASCII | 服务端把中文等字符替换成 `?` 写进 EXIF，CLIP 也读不懂——所以提示词必须先折成 ASCII |

## 它改了什么

```
image_generate 调用
        │
        ▼
[本插件 · tools/execute 公开钩子]
   1. 计划：提示词优化 + 画幅/数量/seed 推断
   2. 选后端：auto = 公网优先；local = 本机；public = 只公网
   3. 公网：45 秒额度闸门 → 显式 seed → 请求 → 交付前检测 → 缓存
      本机：探 127.0.0.1:7860 → A1111 txt2img（同一份优化后的提示词）
   4. 附件 + 工作区落盘（并行）
        │
        ▼
  返回 value（backend / model / aspect / images …）
  → 宿主编排后交给 free-image 自己的 render / presentationMeta / 卡片
```

- **不注册同名工具**（宿主对同名工具会直接拒绝），只在 `tools/execute` 上接管
  `image_generate` 的执行，返回符合 free-image `OUTPUT_SCHEMA` 的 `{ value }`。
- **不改 free-image 的源码、schema、行配置**。卸载本插件，下一次调用立刻回到原实现。
- 工具说明和展示文案仍由 free-image 提供；本插件只在系统提示词里补一小段
  （`guidance`，默认开），告诉模型"把用户原话交给工具，别自己翻译；count 默认 1"。

## 提示词优化

免费档实际模型是 SDXL 系的 Sana，英文 CLIP 对中文原句几乎没有约束；服务端还会把非 ASCII
替换成 `?`。所以优化是**确定性的标签流**，不是"再写一段散文"：

| 输入 | 输出（截取） |
|---|---|
| `雪夜森林里的小木屋，窗户透出暖光` | `snowy night forest wooden cabin, window glowing warm light, masterpiece, best quality, highly detailed, sharp focus, professional lighting` |
| `黄昏时的海边灯塔，巨浪拍打礁石，电影感` | `dusk seaside lighthouse, giant waves crashing reef rocks, cinematic, wide composition, masterpiece, …` |
| `竖版手机壁纸：雪山星空，极简风格，四张` | `vertical phone wallpaper: snowy mountains starry sky, minimalist style, clean background, negative space, …, vertical composition`；同时推断 `aspect=9:16`、`count=4` |
| `a friendly dragon reading a book by candlelight, fantasy art` | 原句保留 + `fantasy concept art, epic, highly detailed`（不重复堆叠已有词） |

处理顺序：

1. 去请求壳（"帮我画一张……"、`generate an image of`）与结尾客套话；
2. 最长匹配中英术语表（383 条：场景、主体、风格、光照、颜色、构图、动作）；
3. 没翻出来的字与非 ASCII **折成 ASCII**（服务端本来就会变 `?`，留着只会有害）；
4. 命中风格预设（最多 2 个）→ 补风格标签；
5. 按画幅补构图标签；
6. 原句没有质量词才补质量尾巴；全程去重、按字符预算截断（默认 450）。

显式传入的 `aspect` / `count` / `seed` / `model` 一律优先，推断只补缺省。

## 交付前检测（四层）

一个 `200 image/jpeg` 仍可能是断图、纯色占位图，或上一次请求的错图。检测从便宜到贵：

1. **魔数 + 头部尺寸**：PNG IHDR / JPEG SOF / WebP VP8·VP8L·VP8X / GIF；尺寸、画幅比例、
   EOI 结束标记、部署的 `maxImageBytes`。
2. **JPEG 基线 DC 解码**（纯 Node，无原生依赖）：只解 DC 系数就能得到 8×8 块均值，
   算亮度方差、相邻块梯度（清晰度）、Cb/Cr 色度方差；顺带验证 Huffman 流没有断裂。
   768×768 的图 9216 个块，解码约 10 毫秒。
3. **PNG 反滤波 + 抽样统计**：inflate、五种 filter 还原、抽样算同样的统计量。
4. **EXIF 核对**：Pollinations 会把 `{"prompt":…,"seed":…}` 写进 JPEG；严格比对 prompt
   （允许服务端截断成前缀）与 seed；如果服务端把非 ASCII 写成 `?`，用 ASCII 折叠再比一次。

判定：亮度标准差 < 2.5 视为空白；没有可解码统计量时退回"字节/像素 < 0.008"启发式。
不合格的图**不会交付**：换 seed 重画（受 `retryInvalidImages` 与总预算约束），仍不合格才报错。

## 额度、缓存与重试

- **seed 永远显式发**。同一个 prompt+seed 是服务端缓存键：失败后用同一 seed 补拿，通常
  1.2–1.7 秒命中，不再消耗 45 秒额度。
- **45 秒闸门**：所有新生成串行；上次成功/402 的 `retry-after` 写回闸门；`count>1` 时
  按批预算等待，等不到就返回已经拿到的图。
- **本地缓存**：`<DSH_HOME>/free-image-max/cache`，内容寻址 + 原子落盘 + LRU（默认 256MB）。
  只对**显式 seed** 和失败补拿生效——随机 seed 的新请求不会命中，所以"再画一张"仍是新图。
- **失败矩阵**：

  | 失败 | 处理 |
  |---|---|
  | 402 / 429 | 读 `retry-after`；≤ `firstWaitSeconds`（默认 45）就等，等不到抛给模型；`auto` 且本机 SD 在跑则兜底 |
  | 5xx / 网络 | 重试 `retryServerErrors` 次（默认 1），指数退避 |
  | 超时 | **不重发**（服务端可能还在画）；记下 seed，下次同 prompt 先拿缓存 |
  | 校验失败 | 换 seed 重画，最多 `retryInvalidImages` 次（默认 1，会再消耗一次额度） |
  | 附件/工作区写失败 | 工作区失败只记 `saveError`，不影响聊天里看图 |

- **验证失败不重试超时**，**402 不盲目重试**，**免费档不并行**（并行只会多拿几个 402）。

## 配置

写在 bundle 行的 `config` 里；未知键会在装配阶段报错。

| 字段 | 默认 | 说明 |
|---|---|---|
| `enabled` | `true` | 总开关；关掉 = 完全交回 free-image |
| `backend` | `auto` | `auto` 公网优先、本机兜底；`public` 只公网；`local` 只本机 |
| `guidance` | `true` | 系统提示词加一小段"原话交给工具、count 默认 1" |
| `enhancePrompt` | `true` | 提示词优化总开关 |
| `autoAspect` / `autoCount` | `true` | 缺省时从原句推断画幅/数量 |
| `model` | `sana` | 公网模型；免费档发别的也会被映射回 sana |
| `endpoint` | `https://image.pollinations.ai/prompt/` | 可换代理/自建端点 |
| `apiKey` | `''` | pollen key；填了解除 45 秒限制（也读 `POLLINATIONS_API_KEY`） |
| `authMode` | `bearer` | `bearer` 或 legacy 的 `query` |
| `requestTimeoutSeconds` | `45` | 公网单张超时 |
| `maxCallSeconds` | `90` | 公网单次调用总预算（含等待） |
| `firstWaitSeconds` | `45` | 402 时最多等多久 |
| `batchWaitSeconds` | `100` | `count>1` 时整批等待预算 |
| `retryServerErrors` | `1` | 5xx/网络重试次数 |
| `retryInvalidImages` | `1` | 校验失败重画次数 |
| `strictMetadata` | `true` | 严格核对 EXIF prompt/seed |
| `qualityTail` | 见源码 | 质量尾巴；留空关闭 |
| `promptMaxChars` | `450` | 优化后提示词上限 |
| `cacheTtlSeconds` | `3600` | 本地缓存 TTL；`0` 关闭 |
| `cacheMaxMegabytes` | `256` | 缓存上限 |
| `warmup` | `true` | 启动时 DNS/TLS 预热 |
| `localEndpoint` | `http://127.0.0.1:7860` | 本机 SD WebUI |
| `localSteps` / `localCfg` / `localSampler` | `16` / `6.5` / `DPM++ 2M Karras` | 本机采样参数 |
| `localTimeoutSeconds` | `240` | 本机单张超时 |
| `log` | `false` | 排查时打开 |

## 安装

要求：已安装 **dsh-free-image ≥ 1.0**（在 1.1.0 上验证）。本插件不复制、不修改它的文件。

**本机已安装并激活**（2026-10-25 12:43，`desktop` profile）：

- 依赖：`~/.dsh/profiles/desktop/package.json` 里
  `"dsh-free-image-max": "link:/Users/example/Documents/deepseek-harness/default-workspace/dsh-free-image-max"`；
- bundle：已自动追加到 `dsh.profile.bundles` 末尾；
- 实测本会话的一次调用返回
  `Rendered 1 image(s) with sana (public) at 1:1`，768×768、85,380 B，服务端缓存命中；
- 本地缓存已落到 `~/.dsh/free-image-max/cache/`（上一条的 prompt/seed/backend/stats 都在）。

安装前的 profile 备份在
`backups/free-image-max-install-20261025-123745/`（package.json / pnpm-lock / cordis.patch.yml）。

其它机器安装：在 Web UI 插件页"安装本地 bundle / 从文件夹安装"，或由带
`plugin_manager` 的会话执行：

```text
plugin_manager: install_bundle target=/Users/example/Documents/deepseek-harness/default-workspace/dsh-free-image-max
```

安装后仍然只有一个 `image_generate` 工具（两个插件不会冲突）；返回卡片的文本会写
`with sana (public)` 或 `with <checkpoint> (local-stable-diffusion)`。
想回退：从 profile 移除本 bundle（或恢复上面的备份）即可，dsh-free-image 原样工作。

## 验证

```bash
cd /Users/example/Documents/deepseek-harness/default-workspace/dsh-free-image-max
npm test              # 53 个测试
node tools/live-probe.mjs --prompt "雪夜森林里的小木屋，窗户透出暖光" --seed 20261025
```

测试覆盖：

- 提示词：翻译、去壳、画幅/数量推断、去重、ASCII 折叠、确定性；
- 检测：真实 JPEG/PNG 通过，纯白图/截断图被拒，EXIF prompt/seed 不符被拒；
- 引擎：本地缓存、服务端缓存、402 等待、校验重画、count 串行、有 key 并行；
- 本机 SD：`/sdapi/v1/options` 探测、txt2img、`backend: auto` 的 402 兜底；
- **契约测试**：把 free-image 自己的 `apply` 跑在最小 ctx 上，拿它注册的
  `render` / `presentationMeta` / `presentResult` 去消费本插件产出的 value。

真实端点已验证（2026-10-25）：

| 场景 | 结果 |
|---|---|
| 中文 1:1 新图 | 6.67 s，768×768，85,380 B，EXIF prompt/seed 完全一致 |
| 同 prompt+seed 再请求 | 1.21–1.67 s，`x-cache: HIT`，同字节 |
| 16:9 新图 | 8.01 s，1024×576（服务端按约 0.59MP 保持比例缩放） |
| 本地缓存 | < 1 ms（同进程第二轮） |
| 本机 SD 512×512/12 步 | 65.8 s，无水印；24 步见 `bench-report.md` |

限制：公网图有水印；免费额度仍是 45 秒/张；服务端把画布限制在约 0.59MP（报告的是实际尺寸）；
本机 SD 速度取决于显卡/内存；词典未覆盖的中文会被折掉（原句仍保留在 value 的
`originalPrompt` 里）。

## 文件结构

```
index.js              钩子、后端策略、系统提示词、附件/工作区
lib/config.js          Standard Schema 配置（未知键拒绝）
lib/prompt.js          提示词优化 + 术语表 + 画幅/数量推断
lib/plan.js            调用参数 → 执行计划
lib/client.js          公网 HTTP、402/5xx 分类、超时
lib/limiter.js         45 秒额度闸门、RateLimitError
lib/engine.js          调度、缓存、校验、重试、本机生成
lib/detect.js          JPEG DC 解码 / PNG 反滤波 / EXIF 核对
lib/local.js           本机 SD 探测与 txt2img
lib/cache.js           磁盘 LRU
lib/workspace.js       generated-images/<date>/ 落盘
test/                  53 个测试 + 图片 fixtures
tools/live-probe.mjs   真实端点探针
```

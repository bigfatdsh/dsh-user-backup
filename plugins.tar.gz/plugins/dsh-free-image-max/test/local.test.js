import assert from 'node:assert/strict'
import { mkdtemp, readFile, rm } from 'node:fs/promises'
import { createServer } from 'node:http'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import test from 'node:test'

import { apply } from '../index.js'

const PNG = await readFile(new URL('./fixtures/sample.png', import.meta.url))

/** 模拟 A1111：options + txt2img。 */
function localServer(portHolder) {
  return createServer((request, response) => {
    if (request.url === '/sdapi/v1/options') {
      response.writeHead(200, { 'content-type': 'application/json' })
      response.end(JSON.stringify({ sd_model_checkpoint: 'test-checkpoint.safetensors' }))
      return
    }
    if (request.url === '/sdapi/v1/txt2img') {
      request.resume()
      portHolder.calls += 1
      response.writeHead(200, { 'content-type': 'application/json' })
      response.end(JSON.stringify({ images: [PNG.toString('base64')], info: '{}' }))
      return
    }
    response.writeHead(404)
    response.end()
  })
}

function makeContext() {
  const listeners = new Map()
  const ctx = {
    logger: { info: () => {}, warn: () => {} },
    tools: { get: (name) => (name === 'image_generate' ? { name } : undefined) },
    attachments: {
      imageLimits: { mediaTypes: ['image/jpeg', 'image/png', 'image/webp'], maxImageBytes: 8 * 1024 * 1024 },
      saveImage: async ({ data, mediaType, name }) => ({ attachmentId: 'att-local', mediaType, bytes: data.byteLength, width: 256, height: 256, name }),
    },
    on(event, handler) {
      listeners.set(event, handler)
      return () => {}
    },
    get: () => undefined,
    effect: (fn) => fn(),
  }
  return { ctx, listeners }
}

async function callHook(port, config, cwd) {
  const { ctx, listeners } = makeContext()
  apply(ctx, {
    backend: 'local',
    localEndpoint: `http://127.0.0.1:${port}`,
    localTimeoutSeconds: 20,
    maxCallSeconds: 15,
    requestTimeoutSeconds: 5,
    strictMetadata: false,
    cacheTtlSeconds: 0,
    cacheMaxMegabytes: 0,
    guidance: false,
    warmup: false,
    ...config,
  })
  return listeners.get('tools/execute')({
    name: 'image_generate',
    arguments: { prompt: '雪夜森林里的小木屋，窗户透出暖光', seed: 9 },
    agent: { session: { header: { cwd } } },
    signal: new AbortController().signal,
  }, () => {
    throw new Error('next() must not be called')
  })
}

test('backend=local 走本机 SD，产出 backend/model 正确', async () => {
  const holder = { calls: 0 }
  const server = localServer(holder)
  await new Promise((resolve) => server.listen(0, '127.0.0.1', resolve))
  const cwd = await mkdtemp(join(tmpdir(), 'fim-local-'))
  try {
    const result = await callHook(server.address().port, {}, cwd)
    assert.equal(result.value.backend, 'local-stable-diffusion')
    assert.equal(result.value.model, 'test-checkpoint.safetensors')
    assert.equal(result.value.images.length, 1)
    assert.equal(holder.calls, 1)
  } finally {
    server.close()
    await rm(cwd, { recursive: true, force: true })
  }
})

test('backend=auto 时公网 402 会兜底到本机', async () => {
  const holder = { calls: 0 }
  const local = localServer(holder)
  await new Promise((resolve) => local.listen(0, '127.0.0.1', resolve))
  const publicServer = createServer((request, response) => {
    response.writeHead(402, { 'content-type': 'application/json', 'retry-after': '60' })
    response.end(JSON.stringify({ status: 402, success: false, error: { code: 'FREE_LIMIT', message: 'retry after 60s' } }))
  })
  await new Promise((resolve) => publicServer.listen(0, '127.0.0.1', resolve))
  const cwd = await mkdtemp(join(tmpdir(), 'fim-local-'))
  try {
    const result = await callHook(local.address().port, {
      backend: 'auto',
      endpoint: `http://127.0.0.1:${publicServer.address().port}/prompt/`,
      firstWaitSeconds: 0,
    }, cwd)
    assert.equal(result.value.backend, 'local-stable-diffusion')
    assert.equal(holder.calls, 1)
  } finally {
    local.close()
    publicServer.close()
    await rm(cwd, { recursive: true, force: true })
  }
})

import assert from 'node:assert/strict'
import { mkdtemp, readFile, rm } from 'node:fs/promises'
import { createServer } from 'node:http'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import test from 'node:test'

import { DiskCache } from '../lib/cache.js'
import { resolveConfig } from '../lib/config.js'
import { ImageEngine, ImageValidationError } from '../lib/engine.js'
import { GenerationLimiter } from '../lib/limiter.js'
import { buildPlan } from '../lib/plan.js'

const GOOD = await readFile(new URL('./fixtures/sample.jpg', import.meta.url))
const BLANK = await readFile(new URL('./fixtures/solid-white.jpg', import.meta.url))
const SOURCE = await readFile(new URL('./fixtures/source.jpg', import.meta.url))

async function harness(handler, overrides = {}) {
  const server = createServer(handler)
  await new Promise((resolve) => server.listen(0, '127.0.0.1', resolve))
  const port = server.address().port
  const config = resolveConfig({
    endpoint: `http://127.0.0.1:${port}/prompt/`,
    strictMetadata: false,
    cacheTtlSeconds: 60,
    cacheMaxMegabytes: 0,
    requestTimeoutSeconds: 5,
    maxCallSeconds: 15,
    firstWaitSeconds: 3,
    batchWaitSeconds: 3,
    log: false,
    ...overrides,
  })
  const directory = await mkdtemp(join(tmpdir(), 'fim-engine-'))
  const cache = new DiskCache({ maxMegabytes: 8, directory })
  const limiter = new GenerationLimiter({ intervalMs: 20 })
  const engine = new ImageEngine(config, { cache, limiter })
  return {
    config,
    engine,
    close: async () => {
      server.close()
      await rm(directory, { recursive: true, force: true })
    },
  }
}

function imageResponse(body, headers = {}) {
  return (request, response) => {
    response.writeHead(200, { 'content-type': 'image/jpeg', 'x-model-used': 'sana', ...headers })
    response.end(body)
  }
}

test('成功生成并按显式 seed 命中本地缓存', async () => {
  let requests = 0
  const h = await harness((request, response) => {
    requests += 1
    imageResponse(GOOD)(request, response)
  })
  try {
    const plan = buildPlan({ prompt: 'a friendly dragon reading a book by candlelight, fantasy art', seed: 502 }, h.config)
    const first = await h.engine.generate(plan, { deadline: Date.now() + 10_000 })
    assert.equal(first.images.length, 1)
    assert.equal(first.images[0].cache, 'new')
    assert.equal(requests, 1)
    const second = await h.engine.generate(plan, { deadline: Date.now() + 10_000 })
    assert.equal(second.images[0].cache, 'local')
    assert.equal(requests, 1)
    assert.equal(h.engine.snapshotStats().cacheHits, 1)
  } finally {
    await h.close()
  }
})

test('402 读 retry-after 后等待并成功', async () => {
  let requests = 0
  const h = await harness((request, response) => {
    requests += 1
    if (requests === 1) {
      response.writeHead(402, { 'content-type': 'application/json', 'retry-after': '0' })
      response.end(JSON.stringify({ status: 402, success: false, error: { code: 'FREE_LIMIT', message: 'retry after 0s' } }))
      return
    }
    imageResponse(GOOD)(request, response)
  })
  try {
    const plan = buildPlan({ prompt: 'a cat', seed: 7 }, h.config)
    const result = await h.engine.generate(plan, { deadline: Date.now() + 10_000 })
    assert.equal(result.images.length, 1)
    assert.equal(requests, 2)
    assert.equal(h.engine.stats.rateLimits, 1)
  } finally {
    await h.close()
  }
})

test('校验失败换 seed 重画成功', async () => {
  let requests = 0
  const h = await harness((request, response) => {
    requests += 1
    if (requests === 1) imageResponse(BLANK)(request, response)
    else imageResponse(GOOD)(request, response)
  }, { retryInvalidImages: 1 })
  try {
    const plan = buildPlan({ prompt: 'a cat', seed: 11 }, h.config)
    const result = await h.engine.generate(plan, { deadline: Date.now() + 10_000 })
    assert.equal(result.images.length, 1)
    assert.notEqual(result.images[0].seed, 11)
    assert.equal(requests, 2)
    assert.equal(h.engine.stats.validationRetries, 1)
  } finally {
    await h.close()
  }
})

test('校验失败且不再重试时抛出', async () => {
  const h = await harness((request, response) => imageResponse(BLANK)(request, response), { retryInvalidImages: 0 })
  try {
    const plan = buildPlan({ prompt: 'a cat', seed: 11 }, h.config)
    await assert.rejects(
      () => h.engine.generate(plan, { deadline: Date.now() + 10_000 }),
      (error) => error instanceof ImageValidationError && /flat/.test(error.message),
    )
  } finally {
    await h.close()
  }
})

test('count=2 串行拿两张，seed 递增', async () => {
  let requests = 0
  const h = await harness((request, response) => {
    requests += 1
    imageResponse(GOOD)(request, response)
  })
  try {
    const plan = buildPlan({ prompt: 'a cat', count: 2 }, h.config)
    const result = await h.engine.generate(plan, { deadline: Date.now() + 10_000 })
    assert.equal(result.images.length, 2)
    assert.equal(requests, 2)
    assert.equal(result.images[1].seed, result.images[0].seed + 1)
    assert.deepEqual(result.warnings, [])
  } finally {
    await h.close()
  }
})

test('严格模式：EXIF 的 prompt 不符时拒绝', async () => {
  const h = await harness((request, response) => imageResponse(SOURCE)(request, response), {
    strictMetadata: true,
    retryInvalidImages: 0,
  })
  try {
    const plan = buildPlan({ prompt: 'a cat that is definitely not in the fixture', seed: 11, aspect: '1:1' }, h.config)
    await assert.rejects(
      () => h.engine.generate(plan, { deadline: Date.now() + 10_000 }),
      (error) => error instanceof ImageValidationError && /does not match/.test(error.message),
    )
  } finally {
    await h.close()
  }
})

test('服务端缓存 HIT 被标记为 server', async () => {
  const h = await harness((request, response) => imageResponse(GOOD, { 'x-cache': 'HIT' })(request, response), {
    cacheTtlSeconds: 0,
  })
  try {
    const plan = buildPlan({ prompt: 'a cat', seed: 12 }, h.config)
    const result = await h.engine.generate(plan, { deadline: Date.now() + 10_000 })
    assert.equal(result.images[0].cache, 'server')
  } finally {
    await h.close()
  }
})

test('有 key 时并行且带 Authorization', async () => {
  const headers = []
  let active = 0
  let peak = 0
  const h = await harness((request, response) => {
    headers.push(request.headers.authorization)
    active += 1
    peak = Math.max(peak, active)
    setTimeout(() => {
      active -= 1
      imageResponse(GOOD)(request, response)
    }, 30)
  }, { apiKey: 'pk_test', authMode: 'bearer', cacheTtlSeconds: 0 })
  try {
    const plan = buildPlan({ prompt: 'a cat', count: 3 }, h.config)
    const result = await h.engine.generate(plan, { deadline: Date.now() + 10_000 })
    assert.equal(result.images.length, 3)
    assert.ok(peak >= 2, `expected parallel requests, peak=${peak}`)
    assert.deepEqual(headers, ['Bearer pk_test', 'Bearer pk_test', 'Bearer pk_test'])
  } finally {
    await h.close()
  }
})

test('402 要求付费（不是免费额度）时不等待，立即上抛', async () => {
  const started = Date.now()
  const h = await harness((request, response) => {
    response.writeHead(402, { 'content-type': 'application/json' })
    response.end(JSON.stringify({ status: 402, success: false, error: { code: 'PAYMENT_REQUIRED', message: 'Payment required' } }))
  })
  try {
    const plan = buildPlan({ prompt: 'a cat', seed: 21 }, h.config)
    await assert.rejects(
      () => h.engine.generate(plan, { deadline: Date.now() + 10_000 }),
      (error) => error.name === 'RateLimitError' && error.paymentRequired === true,
    )
    assert.ok(Date.now() - started < 2_000, 'must not wait for a payment 402')
  } finally {
    await h.close()
  }
})

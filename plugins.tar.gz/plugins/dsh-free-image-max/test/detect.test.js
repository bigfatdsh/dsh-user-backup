import assert from 'node:assert/strict'
import { readFileSync } from 'node:fs'
import test from 'node:test'

import { inspectImage, sniffMediaType } from '../lib/detect.js'

const fixture = (name) => new Uint8Array(readFileSync(new URL(`./fixtures/${name}`, import.meta.url)))

test('魔数嗅探', () => {
  assert.equal(sniffMediaType(fixture('sample.jpg')), 'image/jpeg')
  assert.equal(sniffMediaType(fixture('sample.png')), 'image/png')
  assert.equal(sniffMediaType(new Uint8Array([1, 2, 3, 4])), undefined)
})

test('真实图片通过并解出尺寸与统计量', () => {
  const result = inspectImage(fixture('sample.jpg'), { width: 256, height: 256, strictMetadata: false })
  assert.equal(result.ok, true, result.reasons.join('; '))
  assert.equal(result.mediaType, 'image/jpeg')
  assert.equal(result.width, 256)
  assert.equal(result.height, 256)
  assert.ok(result.stats.lumaStd > 10)
  assert.ok(result.stats.detail > 1)
})

test('PNG 也做反滤波统计', () => {
  const result = inspectImage(fixture('sample.png'), { width: 256, height: 256, strictMetadata: false })
  assert.equal(result.ok, true, result.reasons.join('; '))
  assert.ok(result.stats.lumaStd > 10)
})

test('纯白 PNG / JPEG 被判定为空白', () => {
  for (const name of ['solid-white.png', 'solid-white.jpg']) {
    const result = inspectImage(fixture(name), { width: 256, height: 256, strictMetadata: false })
    assert.equal(result.ok, false, name)
    assert.ok(result.reasons.some((reason) => reason.includes('flat') || reason.includes('blank')), result.reasons.join('; '))
  }
})

test('截断的 JPEG 被拒绝', () => {
  const bytes = fixture('source.jpg')
  const truncated = bytes.slice(0, Math.floor(bytes.length * 0.5))
  const result = inspectImage(truncated, { width: 768, height: 768, strictMetadata: false })
  assert.equal(result.ok, false)
  assert.ok(result.reasons.some((reason) => reason.includes('truncated') || reason.includes('invalid')), result.reasons.join('; '))
})

test('EXIF 的 prompt/seed 与请求不符时拒绝（严格模式）', () => {
  const result = inspectImage(fixture('source.jpg'), {
    width: 768,
    height: 768,
    prompt: 'a completely different prompt',
    seed: 999,
    strictMetadata: true,
  })
  assert.equal(result.ok, false)
  assert.ok(result.reasons.some((reason) => reason.includes('does not match')))
  const lenient = inspectImage(fixture('source.jpg'), {
    width: 768,
    height: 768,
    prompt: 'a completely different prompt',
    seed: 999,
    strictMetadata: false,
  })
  assert.equal(lenient.ok, true)
})

test('画幅不符时拒绝', () => {
  const result = inspectImage(fixture('sample.jpg'), { width: 1280, height: 720, strictMetadata: false })
  assert.equal(result.ok, false)
  assert.ok(result.reasons.some((reason) => reason.includes('aspect')))
})

test('超长提示词按前缀匹配（服务端可能截断 EXIF）', () => {
  const bytes = fixture('source.jpg')
  const full = 'a friendly dragon reading a book by candlelight, fantasy art, b1792901208, ' + 'extra detail, '.repeat(40)
  const result = inspectImage(bytes, { width: 768, height: 768, prompt: full, seed: 502, strictMetadata: true })
  assert.equal(result.ok, true, result.reasons.join('; '))
})

test('服务端把非 ASCII 写成问号时，折叠后仍可通过 EXIF 核对', () => {
  const result = inspectImage(fixture('source.jpg'), {
    width: 768,
    height: 768,
    prompt: 'a friendly dragon reading a book by candlelight, fantasy art, b1792901208 ? ? ?',
    seed: 502,
    strictMetadata: true,
  })
  assert.equal(result.ok, true, result.reasons.join('; '))
})

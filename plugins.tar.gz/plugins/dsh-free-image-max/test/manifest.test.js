import assert from 'node:assert/strict'
import { readFile, stat } from 'node:fs/promises'
import test from 'node:test'

const root = new URL('../', import.meta.url)
const read = (name) => readFile(new URL(name, root), 'utf8')

test('manifest 必需字段、导出与文件都在', async () => {
  const pkg = JSON.parse(await read('package.json'))
  assert.equal(pkg.name, 'dsh-free-image-max')
  assert.equal(pkg.type, 'module')
  assert.equal(pkg.main, 'index.js')
  assert.equal(pkg.icon, './icon.svg')
  assert.equal(pkg.dsh.bundle.patch, './cordis.patch.yml')
  assert.deepEqual(Object.keys(pkg.exports).sort(), ['.', './icon', './locale/*.json', './package.json'].sort())
  for (const file of ['index.js', 'cordis.patch.yml', 'icon.svg', 'locale/zh.json', 'locale/en.json', 'lib/config.js']) {
    assert.ok((await stat(new URL(file, root))).size > 0, file)
  }
})

test('bundle 补丁只插入一行且 id/name 一致', async () => {
  const patch = await read('cordis.patch.yml')
  assert.match(patch, /- insert:/)
  assert.match(patch, /- id: free-image-max/)
  assert.match(patch, /name: 'dsh-free-image-max'/)
  assert.doesNotMatch(patch, /free-image:\s*$|disabled:\s*true/)
})

test('locale 是合法 JSON 且有标题', async () => {
  for (const file of ['locale/zh.json', 'locale/en.json']) {
    const value = JSON.parse(await read(file))
    assert.equal(typeof value.title, 'string')
    assert.ok(value.title.length > 0)
    assert.equal(typeof value.description, 'string')
  }
})

test('图标是 SVG 且小于 256 KiB', async () => {
  const bytes = await read('icon.svg')
  assert.match(bytes, /^<svg/)
  assert.ok(Buffer.byteLength(bytes) < 256 * 1024)
})

test('index.js 导出 apply / Config / inject / name', async () => {
  const mod = await import('../index.js')
  assert.equal(typeof mod.apply, 'function')
  assert.equal(typeof mod.Config['~standard'].validate, 'function')
  assert.ok(Array.isArray(mod.inject))
  assert.equal(mod.name, 'free-image-max')
})

import assert from 'node:assert/strict'
import test from 'node:test'

import { resolveConfig } from '../lib/config.js'
import { buildPlan } from '../lib/plan.js'
import { inferAspect, inferCount, optimizePrompt, stripRequestShell, translateChinese } from '../lib/prompt.js'

const CONFIG = resolveConfig({})

test('中文提示词被翻成标签流，不留汉字', () => {
  const result = optimizePrompt('雪夜森林里的小木屋，窗户透出暖光')
  assert.match(result.prompt, /snowy night forest/)
  assert.match(result.prompt, /wooden cabin/)
  assert.match(result.prompt, /warm light/)
  assert.equal(result.remainingChinese, 0)
  assert.doesNotMatch(result.prompt, /[\u4e00-\u9fff]/)
})

test('请求壳被去掉，主体不被误删', () => {
  assert.equal(stripRequestShell('帮我画一张赛博朋克城市'), '赛博朋克城市')
  assert.equal(stripRequestShell('请生成一张猫的图片，谢谢'), '猫的图片')
  assert.equal(stripRequestShell('a cat'), 'a cat')
  assert.equal(stripRequestShell('  "a red fox"  '), 'a red fox')
})

test('术语表最长匹配：赛博朋克不会被拆开', () => {
  const { text } = translateChinese('赛博朋克城市')
  assert.match(text, /cyberpunk city/)
  assert.doesNotMatch(text, /赛博/)
})

test('画幅推断：竖版/横幅/海报', () => {
  assert.equal(inferAspect('竖版手机壁纸，雪山'), '9:16')
  assert.equal(inferAspect('宽屏桌面壁纸'), '16:9')
  assert.equal(inferAspect('一张电影海报'), '2:3')
  assert.equal(inferAspect('a cat'), undefined)
  assert.equal(inferAspect('16:9 banner'), '16:9')
})

test('数量推断：中文与英文，且从提示词里删掉', () => {
  const zh = inferCount('雪山星空，四张')
  assert.equal(zh.count, 4)
  assert.doesNotMatch(zh.text, /四张/)
  const en = inferCount('a cat, 3 variations')
  assert.equal(en.count, 3)
  assert.doesNotMatch(en.text, /variations/)
  assert.equal(inferCount('a cat').count, undefined)
  assert.equal(inferCount('九个太阳').count, undefined)
})

test('buildPlan：缺省参数才推断，显式参数一律尊重', () => {
  const auto = buildPlan({ prompt: '竖版手机壁纸：雪山星空，四张' }, CONFIG)
  assert.equal(auto.aspect, '9:16')
  assert.equal(auto.count, 4)
  assert.equal(auto.width, 720)
  assert.equal(auto.height, 1280)
  assert.equal(auto.inferredAspect, true)
  assert.equal(auto.inferredCount, true)

  const explicit = buildPlan({ prompt: '竖版手机壁纸：雪山星空，四张', aspect: '16:9', count: 2, seed: 7 }, CONFIG)
  assert.equal(explicit.aspect, '16:9')
  assert.equal(explicit.count, 2)
  assert.equal(explicit.seed, 7)
  assert.equal(explicit.inferredAspect, false)
  assert.equal(explicit.inferredCount, false)
  assert.equal(explicit.width, 1280)
})

test('免费档固定 sana；有 key 时显式模型生效', () => {
  assert.equal(buildPlan({ prompt: 'a cat', model: 'turbo' }, CONFIG).model, 'sana')
  const keyed = resolveConfig({ apiKey: 'pk_test' })
  assert.equal(buildPlan({ prompt: 'a cat', model: 'turbo' }, keyed).model, 'turbo')
  assert.equal(buildPlan({ prompt: 'a cat' }, keyed).model, 'sana')
})

test('同输入逐字节同输出；长度受限', () => {
  const a = optimizePrompt('赛博朋克城市，霓虹灯，雨夜，电影感', { aspect: '16:9' })
  const b = optimizePrompt('赛博朋克城市，霓虹灯，雨夜，电影感', { aspect: '16:9' })
  assert.equal(a.prompt, b.prompt)
  assert.ok(a.prompt.length <= 450)
  const long = optimizePrompt('a cat, '.repeat(200), { maxChars: 120 })
  assert.ok(long.prompt.length <= 120)
})

test('风格标签不重复堆叠', () => {
  const result = optimizePrompt('cyberpunk city at night', {})
  assert.equal(result.prompt.toLowerCase().split('cyberpunk').length - 1, 1)
})

test('开 enhance=false 只做规范化/ASCII 折叠/截断', () => {
  const result = optimizePrompt('  a   cat  ', { enhance: false, maxChars: 30 })
  assert.equal(result.prompt, 'a cat')
  assert.equal(result.changed, false)
  const chinese = optimizePrompt('画一张 小猫', { enhance: false, maxChars: 30 })
  assert.equal(chinese.prompt, '')
  assert.throws(() => buildPlan({ prompt: '画一张 小猫' }, { ...CONFIG, enhancePrompt: false, qualityTail: '' }), /no ASCII characters/)
})

test('翻不出来的字不会以非 ASCII 发给服务端', () => {
  const result = optimizePrompt('黄昏时的海边灯塔，巨浪拍打礁石，电影感')
  assert.ok(result.prompt.length > 0)
  assert.doesNotMatch(result.prompt, /[^\x20-\x7e]/)
  assert.match(result.prompt, /seaside lighthouse/)
  assert.match(result.prompt, /giant waves/)
  assert.equal(result.promptInfo === undefined, true) // optimizePrompt 本身不返回 promptInfo
})

test('无法翻译的汉字被折掉后仍然是纯 ASCII', () => {
  const result = optimizePrompt('一个完全无法翻译的词：龘靐齉', { qualityTail: '' })
  assert.doesNotMatch(result.prompt, /[^\x20-\x7e]/)
  assert.ok(result.dropped > 0)
})

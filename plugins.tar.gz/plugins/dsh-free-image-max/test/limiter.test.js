import assert from 'node:assert/strict'
import test from 'node:test'

import { GenerationLimiter, RateLimitError, sleep } from '../lib/limiter.js'

test('免费闸门串行且按间隔放行', async () => {
  const limiter = new GenerationLimiter({ intervalMs: 40 })
  const starts = []
  const tasks = [1, 2].map(() => limiter.run(async () => {
    starts.push(Date.now())
    return 'ok'
  }, { waitMs: 5_000 }))
  assert.deepEqual(await Promise.all(tasks), ['ok', 'ok'])
  assert.ok(starts[1] - starts[0] >= 30, `gap=${starts[1] - starts[0]}`)
})

test('等待预算不够时直接抛 RateLimitError', async () => {
  const limiter = new GenerationLimiter({ intervalMs: 5_000 })
  limiter.noteGeneration(Date.now())
  await assert.rejects(
    () => limiter.run(async () => 'never', { waitMs: 0 }),
    (error) => error instanceof RateLimitError && error.retryAfterMs > 0,
  )
})

test('retry-after 写回闸门', () => {
  const limiter = new GenerationLimiter({ intervalMs: 45_000 })
  limiter.noteLimit(2_000)
  assert.ok(limiter.remaining() >= 1_900)
})

test('sleep 可被取消', async () => {
  const controller = new AbortController()
  const pending = sleep(5_000, controller.signal)
  controller.abort(new Error('stop'))
  await assert.rejects(() => pending, /stop/)
})

test('服务端缓存命中不推进 45 秒闸门', async () => {
  const limiter = new GenerationLimiter({ intervalMs: 5_000 })
  const started = Date.now()
  const first = await limiter.run(async () => ({ quotaConsumed: false }), { waitMs: 0 })
  const second = await limiter.run(async () => ({ quotaConsumed: false }), { waitMs: 0 })
  assert.equal(first.quotaConsumed, false)
  assert.equal(second.quotaConsumed, false)
  assert.ok(Date.now() - started < 1_000, 'cache hits must not wait')
})

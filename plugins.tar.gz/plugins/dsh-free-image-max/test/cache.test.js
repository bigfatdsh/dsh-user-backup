import assert from 'node:assert/strict'
import { mkdtemp, readdir, rm } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import test from 'node:test'

import { cacheKey, DiskCache } from '../lib/cache.js'

const BYTES = new Uint8Array([0xff, 0xd8, 0xff, 0xe0, 1, 2, 3, 4, 5, 6])

test('缓存键：同参数稳定，seed 变了就变', () => {
  const base = { prompt: 'a cat', width: 1024, height: 1024, model: 'sana', seed: 1 }
  assert.equal(cacheKey(base), cacheKey({ ...base }))
  assert.notEqual(cacheKey(base), cacheKey({ ...base, seed: 2 }))
  assert.notEqual(cacheKey(base), cacheKey({ ...base, prompt: 'a dog' }))
})

test('写读命中，坏文件当 miss', async () => {
  const directory = await mkdtemp(join(tmpdir(), 'fim-cache-'))
  try {
    const cache = new DiskCache({ maxMegabytes: 4, directory })
    await cache.put('abc', BYTES, { mediaType: 'image/jpeg', width: 256, height: 256, createdAt: Date.now() })
    const hit = await cache.get('abc')
    assert.deepEqual(Array.from(hit.bytes), Array.from(BYTES))
    assert.equal(hit.meta.mediaType, 'image/jpeg')

    const fresh = new DiskCache({ maxMegabytes: 4, directory })
    const fromDisk = await fresh.get('abc')
    assert.equal(fromDisk.meta.width, 256)
    assert.deepEqual(Array.from(fromDisk.bytes), Array.from(BYTES))

    // 篡改图片：sha256 对不上，必须当 miss 并删掉。
    const { writeFile } = await import('node:fs/promises')
    await writeFile(join(directory, 'abc.jpg'), new Uint8Array([0, 0, 0]))
    const corrupted = new DiskCache({ maxMegabytes: 4, directory })
    assert.equal(await corrupted.get('abc'), undefined)
    const names = await readdir(directory)
    assert.ok(!names.includes('abc.jpg'))
  } finally {
    await rm(directory, { recursive: true, force: true })
  }
})

test('上限为 0 时完全不落盘', async () => {
  const directory = await mkdtemp(join(tmpdir(), 'fim-cache-'))
  try {
    const cache = new DiskCache({ maxMegabytes: 0, directory })
    await cache.put('abc', BYTES, { mediaType: 'image/jpeg' })
    assert.equal(await cache.get('abc'), undefined)
    assert.deepEqual(await readdir(directory), [])
  } finally {
    await rm(directory, { recursive: true, force: true })
  }
})

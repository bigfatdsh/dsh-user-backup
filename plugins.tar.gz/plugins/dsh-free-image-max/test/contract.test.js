/**
 * 契约测试：本插件返回的 value 必须能被 dsh-free-image 自己的 render /
 * presentationMeta / presentResult 消费——这正是宿主在执行流水线里做的事。
 *
 * 这里不安装、不启动宿主：把 free-image 的 apply 跑在一个最小 ctx 上，拿到它注册的
 * 工具定义；再用同一个定义去渲染本插件产出的值。任何字段名/形状不兼容都会在这里
 * 立刻炸掉，而不是等到真实会话里卡片空白。
 */

import assert from 'node:assert/strict'
import { mkdtemp, readFile, rm } from 'node:fs/promises'
import { createServer } from 'node:http'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import test from 'node:test'

import { apply as applyFreeImage } from '../../dsh-free-image/index.js'
import { apply } from '../index.js'

const JPEG = await readFile(new URL('./fixtures/sample.jpg', import.meta.url))

test('本插件产出的 value 能被 free-image 的展示契约消费', async () => {
  let definition
  const listeners = new Map()
  const attachments = []
  const ctx = {
    logger: { info: () => {}, warn: () => {} },
    tools: {
      register: (def) => {
        definition = def
        return () => {}
      },
      get: (name) => (name === 'image_generate' ? definition : undefined),
    },
    attachments: {
      imageLimits: { mediaTypes: ['image/jpeg', 'image/png', 'image/webp'], maxImageBytes: 8 * 1024 * 1024 },
      saveImage: async ({ data, mediaType, name }) => {
        const ref = { attachmentId: `att-${attachments.length + 1}`, mediaType, bytes: data.byteLength, width: 256, height: 256, name }
        attachments.push(ref)
        return ref
      },
    },
    on(event, handler) {
      listeners.set(event, handler)
      return () => {}
    },
    get: () => undefined,
    effect: (fn) => fn(),
  }

  applyFreeImage(ctx, undefined)
  assert.equal(typeof definition?.output?.render, 'function')
  assert.equal(typeof definition?.output?.presentationMeta, 'function')

  const server = createServer((request, response) => {
    response.writeHead(200, { 'content-type': 'image/jpeg', 'x-model-used': 'sana' })
    response.end(JPEG)
  })
  await new Promise((resolve) => server.listen(0, '127.0.0.1', resolve))
  const cwd = await mkdtemp(join(tmpdir(), 'fim-contract-'))
  try {
    apply(ctx, {
      endpoint: `http://127.0.0.1:${server.address().port}/prompt/`,
      strictMetadata: false,
      cacheTtlSeconds: 0,
      cacheMaxMegabytes: 0,
      requestTimeoutSeconds: 5,
      maxCallSeconds: 15,
      guidance: false,
      warmup: false,
    })
    const hook = listeners.get('tools/execute')
    const args = { prompt: '雪夜森林里的小木屋，窗户透出暖光', seed: 502 }
    const exec = {
      name: 'image_generate',
      arguments: args,
      agent: { session: { header: { cwd } } },
      signal: new AbortController().signal,
    }
    const result = await hook(exec, () => {
      throw new Error('next() must not be called')
    })

    // 1) 能被序列化（宿主的 snapshotToolValue 会做同样的事）。
    const frozen = JSON.parse(JSON.stringify(result.value))
    assert.equal(frozen.backend, 'public')
    assert.equal(frozen.images.length, 1)

    // 2) free-image 的文本 render。
    const content = definition.output.render(args, frozen)
    assert.ok(Array.isArray(content))
    assert.equal(content[0].type, 'text')
    assert.match(content[0].text, /Rendered 1 image\(s\) with sana \(public\) at 1:1/)
    assert.match(content[0].text, /generated-images\//)
    assert.match(content[0].text, /already attached/)

    // 3) free-image 的 presentationMeta：卡片拿到的附件字段必须齐全。
    const meta = definition.output.presentationMeta(args, frozen)
    assert.equal(meta.kind, 'dsh-free-image')
    assert.equal(meta.images.length, 1)
    assert.equal(meta.images[0].attachmentId, 'att-1')
    assert.equal(meta.images[0].mediaType, 'image/jpeg')
    assert.equal(meta.images[0].width, 256)
    assert.equal(meta.images[0].height, 256)

    // 4) free-image 的 presentResult：把 meta 变成 image content block。
    const presented = definition.presentResult(args, { meta })
    assert.equal(presented.card, 'generic')
    assert.equal(presented.content[0].type, 'image')
    assert.equal(presented.content[0].attachment.attachmentId, 'att-1')
  } finally {
    server.close()
    await rm(cwd, { recursive: true, force: true })
  }
})

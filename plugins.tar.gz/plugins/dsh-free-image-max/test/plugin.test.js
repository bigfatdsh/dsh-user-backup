import assert from 'node:assert/strict'
import { mkdtemp, readFile, rm, stat } from 'node:fs/promises'
import { createServer } from 'node:http'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import test from 'node:test'

import { apply, Config, GUIDANCE_SECTION } from '../index.js'

const JPEG = await readFile(new URL('./fixtures/sample.jpg', import.meta.url))

/** 最小 Cordis 上下文替身：只实现本插件用到的面。 */
function makeContext(options = {}) {
  const listeners = new Map()
  const sections = []
  const attachments = []
  const ctx = {
    logger: { info: () => {}, warn: () => {} },
    tools: {
      get: (name) => (options.hasTool === false ? undefined : name === 'image_generate' ? { name } : undefined),
    },
    attachments: {
      imageLimits: { mediaTypes: ['image/jpeg', 'image/png', 'image/webp'], maxImageBytes: 8 * 1024 * 1024 },
      saveImage: async ({ data, mediaType, name }) => {
        const ref = { attachmentId: `att-${attachments.length + 1}`, mediaType, bytes: data.byteLength, width: 256, height: 256, name }
        attachments.push(ref)
        return ref
      },
    },
    on(event, handler) {
      listeners.set(event, handler)
      return () => listeners.delete(event)
    },
    get(name) {
      if (name === 'systemPrompt') {
        return {
          section: (section) => {
            sections.push(section)
            return () => {}
          },
        }
      }
      return undefined
    },
    effect(fn) {
      return fn()
    },
  }
  return { ctx, listeners, sections, attachments }
}

async function withServer(handler, fn) {
  const server = createServer(handler)
  await new Promise((resolve) => server.listen(0, '127.0.0.1', resolve))
  const port = server.address().port
  try {
    return await fn(port)
  } finally {
    server.close()
  }
}

test('apply 注册 tools/execute，并把 image_generate 变成一张缓存未命中的图', async () => {
  const cwd = await mkdtemp(join(tmpdir(), 'fim-plugin-'))
  try {
    await withServer((request, response) => {
      response.writeHead(200, { 'content-type': 'image/jpeg', 'x-model-used': 'sana' })
      response.end(JPEG)
    }, async (port) => {
      const { ctx, listeners } = makeContext()
      apply(ctx, {
        endpoint: `http://127.0.0.1:${port}/prompt/`,
        strictMetadata: false,
        cacheTtlSeconds: 0,
        cacheMaxMegabytes: 0,
        requestTimeoutSeconds: 5,
        maxCallSeconds: 15,
        guidance: false,
      })
      const handler = listeners.get('tools/execute')
      assert.equal(typeof handler, 'function')
      const result = await handler({
        name: 'image_generate',
        arguments: { prompt: '雪夜森林里的小木屋，窗户透出暖光', seed: 502 },
        agent: { session: { header: { cwd } } },
        signal: new AbortController().signal,
      }, () => {
        throw new Error('next() must not be called for image_generate')
      })
      assert.equal(result.value.model, 'sana')
      assert.equal(result.value.aspect, '1:1')
      assert.equal(result.value.images.length, 1)
      assert.equal(result.value.images[0].seed, 502)
      assert.match(result.value.prompt, /snowy night forest/)
      const relative = result.value.images[0].path
      assert.match(relative, /^generated-images\/\d{4}-\d{2}-\d{2}\/.*\.jpg$/)
      assert.equal((await stat(join(cwd, relative))).size, JPEG.byteLength)
    })
  } finally {
    await rm(cwd, { recursive: true, force: true })
  }
})

test('其它工具原样 next()', async () => {
  const { ctx, listeners } = makeContext()
  apply(ctx, { guidance: false, warmup: false, cacheMaxMegabytes: 0 })
  let nextCalls = 0
  const handled = await listeners.get('tools/execute')({ name: 'bash', arguments: {} }, () => {
    nextCalls += 1
    return 'dispatched'
  })
  assert.equal(nextCalls, 1)
  assert.equal(handled, 'dispatched')
})

test('没有 image_generate 时直接 next()，插件保持惰性', async () => {
  const { ctx, listeners } = makeContext({ hasTool: false })
  apply(ctx, { guidance: false, warmup: false, cacheMaxMegabytes: 0 })
  let nextCalls = 0
  await listeners.get('tools/execute')({ name: 'image_generate', arguments: { prompt: 'x' } }, () => {
    nextCalls += 1
  })
  assert.equal(nextCalls, 1)
})

test('guidance 段落逐字节稳定且提到 image_generate', () => {
  const { ctx, sections } = makeContext()
  apply(ctx, { warmup: false, cacheMaxMegabytes: 0 })
  assert.equal(sections.length, 1)
  assert.equal(sections[0].text, GUIDANCE_SECTION)
  assert.match(GUIDANCE_SECTION, /image_generate/)
  assert.match(GUIDANCE_SECTION, /do not translate/)
  assert.equal(sections[0].order, 10250)
})

test('free-image 的 schema 多出未知必填字段时交还 next()', async () => {
  const { ctx, listeners } = makeContext()
  ctx.tools.get = () => ({
    name: 'image_generate',
    output: { schema: { required: ['prompt', 'futureField'], properties: { images: { items: { required: ['attachment'] } } } } },
  })
  apply(ctx, { guidance: false, warmup: false, cacheMaxMegabytes: 0 })
  let nextCalls = 0
  await listeners.get('tools/execute')({ name: 'image_generate', arguments: { prompt: 'x' } }, () => {
    nextCalls += 1
    return 'original'
  })
  assert.equal(nextCalls, 1)
})

test('enabled=false 时不注册任何东西', () => {
  const { ctx, listeners, sections } = makeContext()
  apply(ctx, { enabled: false })
  assert.equal(listeners.size, 0)
  assert.equal(sections.length, 0)
})

test('Config 校验：未知键拒绝，默认值完整', () => {
  const good = Config['~standard'].validate({ guidance: false })
  assert.equal(good.issues, undefined)
  assert.equal(good.value.guidance, false)
  assert.equal(good.value.cacheTtlSeconds, 3600)
  const bad = Config['~standard'].validate({ gudance: true })
  assert.ok(bad.issues.some((issue) => issue.message.includes('gudance')))
})

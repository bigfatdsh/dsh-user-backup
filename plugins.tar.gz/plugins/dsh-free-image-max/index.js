/**
 * dsh-free-image-max —— 挂在 dsh-free-image 外面的优化层。
 *
 * ## 为什么不注册新工具
 *
 * 宿主对同名工具是硬拒绝（"tool ... is already registered"）。所以这里不抢
 * `image_generate` 这个名字，也不改 free-image 的 schema，而是用 `tools/execute`
 * 这个**公开的 around-dispatch 钩子**接管它的执行：
 *
 *   tools/pre-execute → guards → [本插件] → 原工具 execute
 *
 * 对模型、对 UI、对别的插件来说，仍然是同一个 `image_generate`：参数表不变、
 * 结果 schema 不变、卡片不变。卸载本插件就立刻回到 free-image 原实现。
 *
 * ## 它改了什么
 *
 *   1. 提示词：去请求壳、中英术语翻译、风格/质量尾巴、去重限量（prompt.js）。
 *   2. 参数：没给画幅/数量时从原句推断；seed 永远显式，失败后复用。
 *   3. 网络：免费档固定 sana、30 秒超时、402 精确等待、5xx 一次重试。
 *   4. 调度：45 秒额度串行闸门、失败 seed 复用、显式 seed 的本地缓存。
 *   5. 交付前：JPEG DC 解码/ PNG 反滤波查空图、EXIF 核对 prompt+seed，
 *      不合格换 seed 重画一次（engine.js + detect.js）。
 *
 * @module dsh-free-image-max
 */

import { randomBytes } from 'node:crypto'

import { Config, resolveConfig } from './lib/config.js'
import { ImageEngine } from './lib/engine.js'
import { LocalBackendProbe } from './lib/local.js'
import { buildPlan } from './lib/plan.js'
import { prepareWorkspaceDirectory, saveImageFile, slugify, stamp } from './lib/workspace.js'

export const name = 'free-image-max'

/** 只依赖工具注册表与附件；systemPrompt 通过 ctx.get 可选获取。 */
export const inject = ['tools', 'attachments']

export { Config }

/** 被优化的工具名。 */
const TOOL_NAME = 'image_generate'

/**
 * 本插件能填的字段。free-image 升级后如果 OUTPUT_SCHEMA 多出未知必填字段，
 * 直接交还 next()，让原实现工作——宁可这次不优化，也不能让工具调用报 schema 错。
 */
const SUPPORTED_TOP_LEVEL = new Set([
  'prompt', 'originalPrompt', 'model', 'requestedModel', 'backend', 'aspect',
  'width', 'height', 'images', 'inferred', 'cache', 'timing', 'warnings',
])
const SUPPORTED_IMAGE = new Set([
  'attachment', 'mediaType', 'width', 'height', 'bytes', 'seed', 'path',
  'saveError', 'cache', 'quality', 'latencyMs',
])

/**
 * 系统提示词里的使用说明。
 *
 * 为什么值得花这几十个 token：
 *   * 模型原本会自己把中文翻成英文、再补一堆质量词——这些工作现在由本插件在毫秒级
 *     完成，模型再写一遍只会多花输出 token，还可能和术语表打架。
 *   * 免费档 45 秒一张，count>1 是最大的浪费来源；一句"默认 count 1"能省掉整次失败。
 *
 * 文本逐字节稳定，开关不变不产生额外的前缀缓存失效。
 */
export const GUIDANCE_SECTION = [
  '## Images',
  '',
  '`image_generate` optimizes the prompt itself and picks the fastest available backend. Pass the',
  'user\'s request as written, in whatever language they used — do not translate it or add style/',
  'quality tags. The tool also infers the aspect ratio and seed. The public service allows one new',
  'image per 45 seconds (a local fallback can take a minute), so call it with count 1 unless the user',
  'explicitly asks for several variations.',
].join('\n')

/**
 * 插件入口。
 *
 * @param {object} ctx - Cordis 上下文。
 * @param {unknown} rawConfig - 插件行 config。
 */
export function apply(ctx, rawConfig) {
  const config = resolveConfig(rawConfig)
  if (!config.enabled) {
    ctx.logger?.info?.('free-image-max: disabled by config')
    return
  }

  const engine = new ImageEngine(config, { logger: ctx.logger })
  const localProbe = new LocalBackendProbe({ endpoint: config.localEndpoint })
  const tool = ctx.tools.get(TOOL_NAME)
  if (tool === undefined) {
    ctx.logger?.warn?.(`free-image-max: tool "${TOOL_NAME}" is not registered (is dsh-free-image installed?); the optimizer is idle until it appears`)
  } else {
    ctx.logger?.info?.(
      `free-image-max: optimizing ${TOOL_NAME} (model=${config.model}${config.apiKey === '' ? ', keyless 45s quota' : ', pollen key'})`,
    )
  }

  // 只接管 image_generate；其余工具原样 next()，不改变任何执行路径。
  ctx.on('tools/execute', async (exec, next) => {
    if (exec.name !== TOOL_NAME) return next()
    const definition = ctx.tools.get(TOOL_NAME, exec.agent)
    if (definition === undefined) return next()
    if (!canOptimize(definition)) {
      warnUnsupportedOnce(ctx, definition)
      return next()
    }

    // 只走本机：探一次（15 秒缓存），没在跑就给出可操作的错误。
    if (config.backend === 'local') {
      const local = await localProbe.get(exec.signal, { fresh: true })
      if (local === undefined) {
        throw new Error(`backend is "local" but no Stable Diffusion WebUI answers at ${config.localEndpoint}/sdapi/v1/options`)
      }
      return runImageCall({ ctx, config, engine, exec, backend: 'local', local })
    }

    // 默认 auto：公网优先（实测 6–8 秒），比本机 SD（8GB M1 上 1 分钟左右）快一个数量级。
    // 公网额度耗尽或服务 5xx 时才探本机，探到就用本机兜底；不预先探测，省掉每次的 1.5 秒。
    try {
      return await runImageCall({ ctx, config, engine, exec, backend: 'public' })
    } catch (error) {
      if (config.backend === 'auto' && shouldFallbackToLocal(error)) {
        const local = await localProbe.get(exec.signal, { fresh: true })
        if (local !== undefined) {
          ctx.logger?.warn?.(`free-image-max: public backend failed (${error instanceof Error ? error.message : String(error)}); falling back to local Stable Diffusion (${local.model})`)
          return runImageCall({ ctx, config, engine, exec, backend: 'local', local })
        }
      }
      throw error
    }
  })

  // 系统提示词说明：可选服务，拿不到就静默跳过。
  if (config.guidance) {
    const systemPrompt = typeof ctx.get === 'function' ? ctx.get('systemPrompt') : undefined
    if (systemPrompt?.section !== undefined) {
      ctx.effect(() => systemPrompt.section({
        name: 'tool:image_generate:optimizer',
        order: 10250,
        text: GUIDANCE_SECTION,
      }))
    }
  }

  if (config.warmup) warmConnection(config, ctx.logger)

}

/**
 * 接管一次 image_generate：计划 → 生成 → 附件 + 工作区 → 值。
 *
 * 返回值必须满足 free-image 的 OUTPUT_SCHEMA；注册表会用它自己的 render /
 * presentationMeta 归一化，所以这里不碰展示文案。
 *
 * @param {object} options
 * @param {object} options.ctx
 * @param {object} options.config
 * @param {ImageEngine} options.engine
 * @param {object} options.exec
 * @returns {Promise<{value: object}>}
 */
async function runImageCall({ ctx, config, engine, exec, backend, local }) {
  const startedAt = performance.now()
  const deadline = Date.now() + config.maxCallSeconds * 1000
  const plan = buildPlan(exec.arguments, config)
  const limits = ctx.attachments.imageLimits

  const generated = backend === 'local'
    ? await engine.generateLocal(plan, {
        signal: exec.signal,
        local,
        allowedMediaTypes: limits.mediaTypes,
        maxImageBytes: limits.maxImageBytes,
      })
    : await engine.generate(plan, {
        signal: exec.signal,
        deadline,
        allowedMediaTypes: limits.mediaTypes,
        maxImageBytes: limits.maxImageBytes,
      })

  if (generated.images.length === 0) {
    const reason = generated.warnings.length > 0 ? generated.warnings.join('; ') : 'no image was rendered'
    throw new Error(reason)
  }

  const cwd = exec.agent?.session.header.cwd
  let workspace
  if (typeof cwd === 'string' && cwd !== '') {
    try {
      workspace = await prepareWorkspaceDirectory(cwd)
    } catch (error) {
      ctx.logger?.warn?.(`free-image-max: could not prepare workspace: ${error instanceof Error ? error.message : String(error)}`)
    }
  }
  const unique = randomBytes(3).toString('hex')
  const at = workspace?.at ?? stamp()
  const images = []
  const warnings = [...generated.warnings]

  for (let index = 0; index < generated.images.length; index += 1) {
    exec.signal?.throwIfAborted?.()
    const image = generated.images[index]
    let attachment
    let path
    try {
      const results = await Promise.allSettled([
        ctx.attachments.saveImage({
          data: image.bytes,
          mediaType: image.mediaType,
          name: `${slugify(plan.originalPrompt)}-${String(index + 1)}`,
        }),
        workspace === undefined
          ? Promise.resolve(undefined)
          : saveImageFile({
              cwd,
              directory: workspace.directory,
              data: image.bytes,
              mediaType: image.mediaType,
              prompt: plan.originalPrompt,
              index,
              unique,
              at,
            }),
      ])
      if (results[0].status === 'rejected') throw results[0].reason
      attachment = results[0].value
      if (results[1].status === 'fulfilled') path = results[1].value
      else warnings.push(`image ${index + 1} could not be saved to the workspace: ${results[1].reason instanceof Error ? results[1].reason.message : String(results[1].reason)}`)
    } catch (error) {
      const message = error instanceof Error ? error.message : String(error)
      if (images.length === 0) throw new Error(`could not store the rendered image: ${message}`)
      warnings.push(`image ${index + 1} could not be stored: ${message}`)
      continue
    }

    images.push({
      attachment,
      mediaType: image.mediaType,
      width: attachment.width,
      height: attachment.height,
      bytes: attachment.bytes,
      seed: image.seed,
      ...(path === undefined ? {} : { path }),
      cache: image.cache,
      quality: image.quality,
      ...(image.latencyMs === undefined ? {} : { latencyMs: image.latencyMs }),
    })
  }

  if (images.length === 0) throw new Error('no rendered image could be stored')

  const servedModels = generated.images.map((image) => image.servedModel).filter((value) => typeof value === 'string')
  const value = {
    prompt: plan.prompt,
    originalPrompt: plan.originalPrompt,
    model: servedModels[0] ?? plan.model,
    backend: generated.images[0]?.backend ?? (backend === 'local' ? 'local-stable-diffusion' : 'public'),
    requestedModel: plan.requestedModel,
    aspect: plan.aspect,
    width: images[0]?.width ?? plan.width,
    height: images[0]?.height ?? plan.height,
    images,
    inferred: plan.inferredAspect || plan.inferredCount
      ? { aspect: plan.inferredAspect, count: plan.inferredCount, styles: plan.promptInfo.styles }
      : { styles: plan.promptInfo.styles },
    cache: images.every((image) => image.cache === 'local') ? 'local' : images.some((image) => image.cache === 'server') ? 'server' : 'new',
    timing: {
      totalMs: Math.round(performance.now() - startedAt),
      ...(generated.images[0]?.latencyMs === undefined ? {} : { firstImageMs: generated.images[0].latencyMs }),
    },
    ...(warnings.length === 0 ? {} : { warnings }),
  }
  return { value }
}

/** 检查 free-image 当前输出契约是否仍在可填范围内。 */
function canOptimize(definition) {
  const schema = definition?.output?.schema
  if (schema === undefined) return true
  const topLevel = Array.isArray(schema.required) ? schema.required : []
  if (topLevel.some((key) => !SUPPORTED_TOP_LEVEL.has(key))) return false
  const item = schema.properties?.images?.items
  const itemRequired = Array.isArray(item?.required) ? item.required : []
  return !itemRequired.some((key) => !SUPPORTED_IMAGE.has(key))
}

let unsupportedWarned = false

/** 只提示一次：升级 mismatch 不该每张图刷一行日志。 */
function warnUnsupportedOnce(ctx, definition) {
  if (unsupportedWarned) return
  unsupportedWarned = true
  const required = definition?.output?.schema?.required ?? []
  ctx.logger?.warn?.(
    `free-image-max: dsh-free-image now requires output fields this optimizer does not produce (${required.join(', ')}); handing image_generate back to the original implementation`,
  )
}

/** 公网不可用时是否值得用本机兜底：额度、5xx/网络、服务端拒绝都算；超时不兜底。 */
function shouldFallbackToLocal(error) {
  if (error === undefined || error === null) return false
  if (error.name === 'RateLimitError') return true
  if (error.name === 'ImageTimeoutError') return false
  if (error.status === 402 || error.status === 429) return true
  if (typeof error.status === 'number' && error.status >= 500) return true
  // 网络层失败（fetch failed）也值得再给本机一次机会。
  return /image request failed|fetch failed|ECONNRESET|ENOTFOUND/i.test(String(error.message ?? ''))
}

/**
 * 预热：DNS + TLS。Node 的全局 fetch 连接池对空闲连接只保留几秒，收益主要在
 * "装好插件马上出图"的场景；失败完全忽略。
 *
 * @param {object} config
 * @param {object} [logger]
 */
function warmConnection(config, logger) {
  let origin
  try {
    origin = new URL(config.endpoint).origin
  } catch {
    return
  }
  const timer = setTimeout(() => {
    const host = new URL(config.endpoint).hostname
    void import('node:dns/promises')
      .then(({ lookup }) => lookup(host))
      .catch(() => {})
    void fetch(`${origin}/robots.txt`, {
      method: 'HEAD',
      headers: { 'user-agent': 'dsh-free-image-max/1.0' },
      signal: AbortSignal.timeout(5_000),
    }).catch(() => {})
    logger?.info?.('free-image-max: connection warmed')
  }, 1_200)
  timer.unref?.()
}

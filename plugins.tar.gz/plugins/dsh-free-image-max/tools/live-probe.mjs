#!/usr/bin/env node
/**
 * 真实端点探针：不经过 DSH，直接跑一遍"优化 → 请求 → 校验 → 落盘"。
 *
 * 用途：装插件前确认网络、免费额度、EXIF 核对与检测阈值；也用来复现 README 里的数字。
 *
 *   node tools/live-probe.mjs --prompt "雪夜森林里的小木屋，窗户透出暖光" --seed 20261025
 *
 * 注意：免费档一张新图会占用 45 秒额度；同 prompt+seed 重复跑会走服务端缓存。
 *
 * @module dsh-free-image-max/tools/live-probe
 */

import { mkdir, writeFile } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import { join, dirname } from 'node:path'

import { DiskCache } from '../lib/cache.js'
import { resolveConfig } from '../lib/config.js'
import { ImageEngine } from '../lib/engine.js'
import { GenerationLimiter } from '../lib/limiter.js'
import { LocalBackendProbe } from '../lib/local.js'
import { buildPlan } from '../lib/plan.js'

/** 极简参数解析。 */
function parseArgs(argv) {
  const out = {}
  for (let i = 0; i < argv.length; i += 1) {
    const key = argv[i]
    if (!key.startsWith('--')) continue
    const name = key.slice(2)
    if (name === 'no-strict') {
      out.strict = false
      continue
    }
    if (name === 'no-cache') {
      out.cache = false
      continue
    }
    out[name] = argv[i + 1]
    i += 1
  }
  return out
}

const args = parseArgs(process.argv.slice(2))
const prompt = args.prompt ?? '雪夜森林里的小木屋，窗户透出暖光'
const aspect = args.aspect
const seed = args.seed === undefined ? Math.floor(Math.random() * 2_000_000_000) : Number(args.seed)
const count = args.count === undefined ? 1 : Number(args.count)
const outPath = args.out ?? join(tmpdir(), `dsh-free-image-max-${Date.now()}.jpg`)

const config = resolveConfig({
  cacheTtlSeconds: args.cache === false ? 0 : 3600,
  cacheMaxMegabytes: 0,
  strictMetadata: args.strict !== false,
  log: true,
  ...(args.steps === undefined ? {} : { localSteps: Number(args.steps) }),
})
const cacheDirectory = join(tmpdir(), `fim-live-cache-${process.pid}`)
const engine = new ImageEngine(config, {
  cache: new DiskCache({ maxMegabytes: 0, directory: cacheDirectory }),
  limiter: new GenerationLimiter(),
  logger: console,
})

const plan = buildPlan({ prompt, ...(aspect === undefined ? {} : { aspect }), ...(args.model === undefined ? {} : { model: args.model }), seed, count }, config)
console.log('prompt:', plan.originalPrompt)
console.log('plan  :', JSON.stringify({ prompt: plan.prompt, aspect: plan.aspect, width: plan.width, height: plan.height, count: plan.count, model: plan.model, seed }))

const backend = args.backend ?? 'public'
const started = performance.now()
let result
if (backend === 'local') {
  const local = await new LocalBackendProbe({ endpoint: config.localEndpoint }).get(undefined, { fresh: true })
  if (local === undefined) throw new Error(`no Stable Diffusion WebUI at ${config.localEndpoint}`)
  console.log('local :', JSON.stringify(local))
  result = await engine.generateLocal(plan, { local })
} else {
  result = await engine.generate(plan, { deadline: Date.now() + config.maxCallSeconds * 1000 })
}
const elapsed = Math.round(performance.now() - started)

for (let index = 0; index < result.images.length; index += 1) {
  const image = result.images[index]
  const file = index === 0 ? outPath : outPath.replace(/\.(\w+)$/, `-${index + 1}.$1`)
  await mkdir(dirname(file), { recursive: true })
  await writeFile(file, image.bytes)
  console.log('image :', JSON.stringify({
    file,
    mediaType: image.mediaType,
    width: image.width,
    height: image.height,
    bytes: image.bytes.byteLength,
    seed: image.seed,
    cache: image.cache,
    serverCache: image.serverCache,
    latencyMs: image.latencyMs,
    quality: image.quality,
    stats: image.stats,
    exifPrompt: image.exif?.prompt,
    exifSeed: image.exif?.seed,
    exifModel: image.exif?.model,
  }))
}
console.log('total :', JSON.stringify({ elapsedMs: elapsed, warnings: result.warnings, stats: result.stats }))

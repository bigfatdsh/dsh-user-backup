# dsh-free-image-max · 实测报告

采样日期：2026-10-25（Asia/Shanghai）
机器：Apple M1 / 8GB / macOS
本机出图：Stable Diffusion WebUI（A1111 API）`127.0.0.1:7860`，模型 `AWPainting_v1.2.safetensors`
公网出图：`image.pollinations.ai` 匿名免费档，实际模型 `sana`
工具：`node --test`（Node 24.16）、`curl`、`tools/live-probe.mjs`

> 所有数字都是单次或少量采样的真实值，不是理论值。公网耗时受排队/网络影响；
> 本机耗时受 GPU/内存占用影响。它们的作用是对比量级，不是 SLA。

## 1. 两条出图路径

| 指标 | 公网免费档（sana） | 本机 SD（AWPainting） |
|---|---|---|
| 新图耗时 | **6.67 s**（1024² 请求，实出 768×768） | **65.8 s**（512×512，12 步） |
| 同上，默认步数 | — | **88.3 s**（512×512，24 步，free-image 1.1 默认） |
| 同 prompt+seed 再请求 | **1.21–1.67 s**（服务端 `x-cache: HIT`） | 本地缓存 < 1 ms（本插件） |
| 尺寸 | 约 0.59 MP：768×768 / 1024×576 | 512×768 / 512×912 等（SD1.5 安全尺寸） |
| 水印 | 右下角 pollinations.ai | 无 |
| 额度 | **1 张新图 / 45 秒 / IP** | 无（受 GPU 排队限制） |
| 非 ASCII | 服务端替换成 `?`，CLIP 读不懂 | SD 文本编码器同样只吃英文 |
| 失败 | 402 `FREE_LIMIT`（0.7–0.9 s，retry-after 33–44 s） | HTTP 5xx / 超时 |

结论：**在这台机器上公网快一个数量级**。dsh-free-image 1.1 是"本机 SD 优先"，
所以不装本插件时，一张图先走本地 = 88.3 秒；本插件 `backend: auto` 改走公网 =
6.7 秒，约 **13 倍**。

## 2. 公网逐项测量

| # | 场景 | 结果 |
|---|---|---|
| 1 | 中文提示词 `雪夜森林里的小木屋，窗户透出暖光`，1:1，seed 20261025 | 6.672 s，768×768，85,380 B，`x-cache: MISS` |
| 2 | 同 URL 再请求 | 1.205 s，同 85,380 B，`x-cache: HIT` |
| 3 | 同 URL 第三次（另一进程） | 1.670 s，同字节 |
| 4 | 16:9 `黄昏时的海边灯塔，巨浪拍打礁石，电影感`，seed 771123 | 8.005 s，1024×576，75,553 B |
| 5 | 30 秒客户端超时的 16:9 请求（旧默认） | 客户端 30 s 放弃；服务端随后生成完成，同 seed 重取 848 ms 命中 |
| 6 | 免费额度已用完时的新请求 | 0.717–0.903 s 返回 402，`retry-after: 33–44` |
| 7 | 非 ASCII 提示词 | EXIF `prompt` 里中文变成 `?`；检测层按 ASCII 折叠核对 |

第 5 条是默认超时从 30 s 提到 45 s 的直接原因；也是"失败后复用 seed"这条逻辑的由来。

## 3. 本机 SD 逐项测量

| 步数 | 画布 | 耗时 | 输出 |
|---|---|---|---|
| 4 | 512×512 | 22.0 s | PNG，417,443 B（走本插件 `renderLocalImage` 的实测） |
| 12 | 512×512 | 65.8 s | PNG，415,793 B |
| 24 | 512×512 | 88.3 s | PNG，625,960 B |

采样器 `DPM++ 2M Karras`，CFG 6.5，负面词与 dsh-free-image 一致。
本插件默认 `localSteps: 16`（约 70 s，按 4/12/24 步曲线估算），并只在
`backend: local` 或公网兜底时使用。

## 4. 本插件的额外开销

| 环节 | 开销 |
|---|---|
| 提示词优化（2000 次平均） | **0.054 ms** |
| 768×768 JPEG DC 解码 + EXIF 核对（20 次平均） | **13.7 ms** |
| 本地缓存命中（进程内第二轮） | **< 1 ms** |
| 公网缓存写入（原子 rename） | 2–4 ms |
| 附件 saveImage + 工作区写入（并行） | 由附件服务决定，通常 10–30 ms |

也就是说：相对 6–8 秒的网络/生成，检测与优化的开销在 1% 以内。

## 5. 检测层实测

fixtures：

| 样本 | 结果 |
|---|---|
| 256×256 真实 JPEG/PNG | 通过；`lumaStd` 32.9 / 35.5，`detail` 10.1 |
| 256×256 纯白 JPEG/PNG | 拒绝：`luma std 0` |
| 768×768 真实 JPEG 截断 50% | 拒绝：`entropy data ended early` + `no end marker` |
| EXIF prompt/seed 与请求不符 | 拒绝：`metadata does not match` / `seed ... does not match` |
| 服务端把非 ASCII 写成 `?` | ASCII 折叠后通过，不误杀 |
| 画幅比例 2:1 与请求 1:1 不符 | 拒绝：`does not match the requested aspect` |

768×768 的 JPEG 在 9216 个 8×8 块上算亮度方差、相邻块梯度、色度方差，约 10 ms。

## 6. 延迟预算（免费档）

- 新图：6–8 s 生成 + 0.2–0.4 s TLS（冷启动）→ **6–8.5 s**。
- 服务端缓存：1.2–1.7 s。
- 本地缓存：< 1 ms。
- 额度用完：等待 `retry-after`（默认最多 45 s），再 6–8 s；等不到则本机兜底或报错。
- 第二次连续请求（45 s 内）：**总耗时约 47–52 s**（等额度后公网），仍比本机 73–88 s 快。
- `count=4`：默认批预算 100 s，只等得到约 2 张；把 `batchWaitSeconds` 提到 180 才能等满 4 张
  （约 160–170 s）。这是免费额度的硬约束，不是调度问题。

## 7. 测试

```
$ npm test
# tests 53
# pass 53
# fail 0
```

包含：

- 提示词/规划/检测/缓存/闸门/引擎（mock HTTP）；
- 本机 SD（mock `/sdapi/v1/options` + `/txt2img`）；
- `backend: auto` 的 402 兜底；
- **契约测试**：用 dsh-free-image 自己注册的 `render` / `presentationMeta` /
  `presentResult` 消费本插件产出的 value；
- schema 兼容守卫：free-image 新增未知必填字段时自动交还原实现。

## 8. 复现

```bash
cd /Users/yangletian/Documents/deepseek-harness/default-workspace/dsh-free-image-max

# 单元/契约测试
npm test

# 真实公网（会消耗一次 45 秒额度；同 prompt+seed 再跑走服务端缓存）
node tools/live-probe.mjs --prompt "雪夜森林里的小木屋，窗户透出暖光" --seed 20261025
node tools/live-probe.mjs --prompt "雪夜森林里的小木屋，窗户透出暖光" --seed 20261025

# 本机 SD（不消耗公网额度；把 --out 换成自己的路径）
node tools/live-probe.mjs --backend local --prompt "..." --aspect 1:1 --seed 9 --steps 12 --out /tmp/local.png
```

## 9. 安装后的 DSH 内实测

2026-10-25 12:43 装入 `desktop` profile 后，本会话直接调用 `image_generate`：

```
prompt: 雪夜森林里的小木屋，窗户透出暖光
seed:   20261025
result: Rendered 1 image(s) with sana (public) at 1:1.
        768x768 image/jpeg, saved as
        generated-images/2026-10-25/雪夜森林里的小木屋-窗户透出暖光-124409-1-aaa9b9.jpg
```

- 文件 85,380 B；与 12:19 的 live-probe 同尺寸同字节量级；
- `~/.dsh/free-image-max/cache/` 出现对应条目：optimized prompt、seed、
  `backend: "public"`、`servedModel: "sana"`、`stats.detail = 8.32`；
- 系统提示词里出现本插件的 `## Images` 段，证明插件已装配（不是只写了文件）。

这一步同时验证了：工具名不变、free-image 的 render 契约通过、工作区落盘、
本地缓存写入。

## 10. 已知偏差

- 公网缓存 HIT 的 1.21 s 与 1.67 s 是两次独立进程测量，CDN 命中率/网络抖动会带来 0.5 s 级波动。
- 本机 SD 数字是在有其他程序运行的情况下测的；空载可能更快。
- 服务端把画布限制在约 0.59 MP，所以请求 1024×1024 实际返回 768×768；value 里报告的是
  实际尺寸（与 free-image 1.1 的行为一致）。
- 免费额度按 IP 计，和同网络的其他使用者共享；402 的 retry-after 可能比你自己的上一张更短或更长。

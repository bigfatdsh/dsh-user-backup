# dsh-plugin-fast — 装插件的快车道

一个 Host-only 的 DSH 插件：把「装一个插件」从 *多步命令 + 装完不知道好没好* 压成**一次调用**。

## 它解决的两件事

**1. 装得慢。** 本机实测（macOS arm64 / pnpm 11.28.5 / 2026-10-26）：

| 操作 | 耗时 |
|---|---|
| `pnpm --version`（纯启动） | 454 ms |
| `pnpm install --frozen-lockfile`（空转） | 628 ms |
| `pnpm add link:<本地目录>` | 850–1150 ms |
| `dsh plugin --profile desktop add link:<本地目录>` | 1169 ms |
| **本插件：本地插件 instant 路径** | **1–3 ms** |
| **本插件：已装过的包（缓存命中）** | **1–2 ms** |
| 本插件：`plugin_doctor` 全量体检（22 个 bundle） | 37–67 ms |

本地插件在 pnpm 里做的事只有两件：写一行 `dependencies`、建一个 symlink。
这两步自己做是毫秒级，pnpm 那 600–900 ms 全是冷启动。所以 `link:` / 本地目录
这类插件走 **instant 路径**，完全不启动 pnpm。

npm 上的新包绕不过 pnpm（它的启动成本就在那里），但装完的**验证**从"人肉排错几分钟"降到毫秒级。

**2. 装完没人验证。** 桌面版 profile 是 `autoInstallPeers: false`，插件声明的 peer
依赖可能根本没装 —— 表现是**装好了、设置页不出现、日志只有一句
`1 entry did not activate … failed to import`**。本插件在安装后立刻做两件事：

- **静态 import 图检查**：解析入口文件的裸模块 import，按 node 的规则逐条解析
  （profile 的 `node_modules` → 宿主自己的 app 树），不需要真的 import 一遍，无副作用。
- **peer 依赖体检**：声明了却解析不到、又不是 optional 的，直接报出来。
  宿主树里能取到的（`@deepseek-ai/*`）算满足，不会误报。只带 `cordis.patch.yml`、
  没有 JS 入口的资源型 bundle 记作 `config-only`，不算坏。

本地插件如果自己带依赖，instant 路径装不上它的依赖 —— 这时会自动**退回 pnpm** 补一次，
而不是给你一个"装好了但一 import 就炸"的结果。

## 三个工具

| 工具 | 作用 |
|---|---|
| `plugin_install_fast` | 装 + 写进 `dsh.profile.bundles` + 体检，一次调用。支持多个 spec 批量装。 |
| `plugin_doctor` | 体检本 profile 所有已登记 bundle：版本、缺哪个 import、缺哪个 peer。 |
| `plugin_speed` | 安装耗时账本 + 本机 pnpm 解析结果。 |

`plugin_install_fast` 的 `spec` 支持：`dsh-xxx`、`dsh-xxx@1.2.3`、`link:/绝对路径`、
`./本地目录`、`*.tgz`。

## 返回里怎么看

```json
{
  "ok": true,
  "cached": false,
  "modes": { "instant": 1 },
  "ms": 3,
  "installed": [{
    "name": "dsh-plugin-fast",
    "version": "1.0.0",
    "bundles": "added",
    "imports": { "ok": true, "missing": [] },
    "peers": { "ok": true, "missing": [], "satisfiedByHost": ["@deepseek-ai/dsh-tools"] }
  }],
  "next": "刷新 Web 页面，在 设置 → 插件 里确认已启用"
}
```

- `ok: false` ⇒ 看 `installed[].imports.missing` 和 `peers.missing`，那就是激活失败的根因。
- `bundles: "added"` ⇒ 这次新写进了 `dsh.profile.bundles`（bundle 层改动对**当前运行**是热加载的）。
- 设置页属于浏览器半端，**要刷新页面**才会出现新面板。

## 安装

```bash
dsh plugin --profile desktop add link:/Users/yangletian/Documents/deepseek-harness/default-workspace/adapted/dsh-plugin-fast
```

（或者用它自己：`plugin_install_fast` 传 `link:<上面的目录>`。）

装完刷新 Web 页面，**设置 → 插件**里应能看到「插件安装加速」。

## 边界

- 只处理 Host 侧：不改浏览器半端的加载顺序。
- instant 路径只用于**链接式**依赖（`link:` / 本地目录）。如果目标位置已经是 npm 装出来的实体目录，不替换，老老实实走 pnpm。
- instant 路径不写 `pnpm-lock.yaml`；下次真正的 `pnpm install` 会把它对齐（这是不启动 pnpm 的代价）。
- `plugin_speed` 的耗时账本在 `~/.dsh/plugin-fast/state.json`。

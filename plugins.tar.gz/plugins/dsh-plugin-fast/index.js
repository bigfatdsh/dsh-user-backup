/**
 * dsh-plugin-fast —— 装插件这件事的快车道
 * ============================================================================
 * 给 Agent 三个工具：
 *   plugin_install_fast  一次调用装完 + 登记 + 体检（含缓存与批量）
 *   plugin_doctor        体检 profile 里所有已登记 bundle：缺 import / 缺 peer
 *   plugin_speed         看这台机器上的安装耗时账本与 pnpm 解析结果
 *
 * 为什么值得单独做：DSH 装插件最贵的不是 pnpm 那两三秒，而是
 *   ① 用 `dsh plugin add` 每次多付一次 Electron 启动；
 *   ② 装完没人验证 —— 桌面版 autoInstallPeers:false 会让插件静默不激活，
 *      于是"装好了但设置页没有"，排错要花掉几分钟。
 */

import { loadHostDeps } from './lib/hostdeps.mjs'
import { doctor, installPlugins, speedReport } from './lib/installer.mjs'

const hostDeps = await loadHostDeps()
const defineTool = hostDeps.defineTool

export const name = 'dsh-plugin-fast'
export const inject = ['tools']

export function apply(ctx, config) {
  const log = (msg) => { if (config?.log) ctx.logger?.info?.(`[plugin-fast] ${msg}`) }

  const textOutput = {
    schema: { type: 'object', properties: {}, additionalProperties: true },
    render: (_args, value) => [{
      type: 'text',
      text: typeof value === 'string' ? value : JSON.stringify(value, null, 2),
    }],
  }

  /** 宿主只吃无损 JSON：函数 / 循环引用 / Error 实例都会让它报错。 */
  const safe = (v) => {
    if (v === undefined || v === null) return v
    if (typeof v === 'string' || typeof v === 'number' || typeof v === 'boolean') return v
    try { return JSON.parse(JSON.stringify(v)) } catch { return String(v) }
  }

  const tool = (spec) => ctx.tools.register(defineTool({
    ...spec,
    parameters: spec.parameters || {},
    output: spec.output || textOutput,
    async execute(args, exec) {
      try {
        return safe(await spec.execute(args || {}, exec))
      } catch (e) {
        return { ok: false, error: String(e?.message || e), stack: String(e?.stack || '').split('\n').slice(0, 4).join('\n') }
      }
    },
  }))

  /* ── 装 ── */
  tool({
    name: 'plugin_install_fast',
    description: [
      '装 DSH 插件（比 `dsh plugin add` 快，并且装完自己验证）。',
      '一次调用完成：解析 pnpm → 批量安装（--prefer-offline）→ 写进 dsh.profile.bundles → 静态查 import 与 peer 依赖 → 报告能不能激活。',
      '已装过且版本匹配的包直接命中缓存（毫秒级）。',
      'spec 支持：dsh-xxx、dsh-xxx@1.2.3、link:/绝对路径、./本地目录、*.tgz。',
    ].join(''),
    parameters: {
      spec: { type: 'string', description: '要装的包；多个用空格或逗号分隔，会在一次 pnpm 里批量装' },
      force: { type: 'boolean', description: '忽略缓存，强制重装（默认 false）' },
      execute: { type: 'boolean', description: '额外在子进程里真的 import 一遍入口（更准但会执行插件顶层代码，默认 false）' },
    },
    async execute(args) {
      const specs = String(args.spec || '')
        .split(/[\s,]+/)
        .map((s) => s.trim())
        .filter(Boolean)
      if (!specs.length) return { ok: false, error: 'spec 是空的' }
      log(`install ${specs.join(' ')}`)
      return installPlugins(specs, { verify: true, execute: !!args.execute, force: !!args.force })
    },
  })

  /* ── 体检 ── */
  tool({
    name: 'plugin_doctor',
    description: '体检本 profile 里登记的所有插件 bundle：版本、缺哪个 import、缺哪个 peer、内置还是缺失。插件"装了没反应"时先跑这个。',
    parameters: {
      only: { type: 'string', description: '只查名字里含这个子串的包（可选）' },
    },
    async execute(args) {
      return doctor({ only: args.only || null })
    },
  })

  /* ── 耗时账本 ── */
  tool({
    name: 'plugin_speed',
    description: '看插件安装的耗时账本：每个包装了什么、花了多久、平均多少，以及本机 pnpm 是从哪儿取到的。',
    parameters: {},
    async execute() {
      return speedReport()
    },
  })
}

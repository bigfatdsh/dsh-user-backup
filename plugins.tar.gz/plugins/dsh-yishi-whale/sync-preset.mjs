// 从 dsh-wechat-media-turbo 的 preset-whale-lean 生成「重述 + 忆时」覆盖层。
// 用法：node sync-preset.mjs [源补丁路径]
// 源补丁的第 4 行缩进块会被原样保留（含注释与 block scalar），只追加 yishi 行。
import { readFileSync, writeFileSync } from 'node:fs'
import { fileURLToPath } from 'node:url'

const here = new URL('.', import.meta.url)
const srcPath = process.argv[2] ?? fileURLToPath(new URL('../../dsh-wechat-media-turbo/cordis.patch.yml', here))
const outPath = fileURLToPath(new URL('./cordis.patch.yml', here))

const lines = readFileSync(srcPath, 'utf8').split('\n')
const start = lines.findIndex((l) => /^ {4}- id: preset-whale-lean\s*$/.test(l))
if (start < 0) throw new Error(`preset-whale-lean not found in ${srcPath}`)
let end = lines.length
for (let i = start + 1; i < lines.length; i += 1) {
  if (/^- /.test(lines[i])) {
    end = i
    break
  }
}
// 顶格注释/空行属于下一个 patch，留在原处（不能跟着 preset 走）
while (end > start + 1 && (/^\s*$/.test(lines[end - 1]) || /^#/.test(lines[end - 1]))) end -= 1
const block = lines.slice(start, end).map((l) => (l.startsWith('    ') ? l.slice(4) : l))
while (block.length > 0 && block[block.length - 1].trim() === '') block.pop()

const yishi = [
  '      - id: yishi',
  '        name: dsh-yishi-whale',
  '        config:',
  '          instructions: lean',
  '          skill: false',
  '          bootstrap: auto'
]

const header = `# dsh-yishi-whale — 大肥鱼（whale-lean）preset 的忆时记忆层。
# 只覆盖 preset-whale-lean 这一行（config 整体重述，保留原 bundle 的全部插件与文案）；
# 不插入任何全局插件行，其他 preset 完全不受影响。
#
# 由 sync-preset.mjs 从 ../../dsh-wechat-media-turbo/cordis.patch.yml 生成；
# 手改会在下次同步时丢失，改完记得重跑：node sync-preset.mjs
`

writeFileSync(outPath, `${header}${[...block, ...yishi].join('\n')}\n`)
console.log(`wrote ${outPath}`)

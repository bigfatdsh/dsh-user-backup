#!/usr/bin/env python3
"""忆时 bge-base-zh-v1.5 模型下载器（幂等，锁防并发，原子写）。

目标：{YISHI_DATA_DIR 或 ~/.local/share/yishi}/models/bge-base-zh-v1.5/
  - onnx/model.onnx（~400MB，bge 768 维，中文语义检索）
  - config.json tokenizer.json special_tokens_map.json tokenizer_config.json vocab.txt

源（按序尝试，可用 YISHI_MODEL_MIRROR 覆盖首发源）：
  1. modelscope.cn（国内，Xenova/bge-base-zh-v1.5，实测可用）
  2. hf-mirror.com（备源）
urllib 内建下载，支持 .part 断点续传（Range），单源失败自动换源。
幂等：model.onnx 已存在且大于 100MB 则跳过；并发：锁文件防重复下载。
"""
import os
import sys
import tempfile
from pathlib import Path

# 2026-08-25 与 memory_core.py 统一：全英文 ~/.local/share/yishi（跨平台，Windows 中文路径易乱码）
DATA_BASE = Path(
    os.environ.get("YISHI_DATA_DIR") or str(Path.home() / ".local" / "share" / "yishi")
)
MODEL_DIR = DATA_BASE / "models" / "bge-base-zh-v1.5"
ONNX_DIR = MODEL_DIR / "onnx"
ONNX_FILE = ONNX_DIR / "model.onnx"
FILES = [
    "config.json",
    "tokenizer.json",
    "special_tokens_map.json",
    "tokenizer_config.json",
    "vocab.txt",
]
MIRRORS = [m for m in [
    os.environ.get("YISHI_MODEL_MIRROR"),
    "https://modelscope.cn/models/Xenova/bge-base-zh-v1.5/resolve/master",
    "https://hf-mirror.com/Xenova/bge-base-zh-v1.5/resolve/main",
] if m]
LOCK = Path(tempfile.gettempdir()) / "yishi-models-install.lock"
# 模型 ~400MB；小于 100MB 判为残缺（错误页/中断），不认可。
MIN_ONNX_BYTES = 100 * 1024 * 1024


def _pid_alive(pid: int) -> bool:
    """探测进程存活（SIGTERM/kill -9 死后锁须可复用）。"""
    try:
        os.kill(pid, 0)
        return True
    except ProcessLookupError:
        return False
    except PermissionError:
        return True


def _lock() -> bool:
    if LOCK.exists():
        try:
            old = int(LOCK.read_text().strip())
        except (ValueError, OSError):
            old = None
        if old is not None and _pid_alive(old):
            return False  # 真在下载（apply spawn / 手动并发）
        # 过期锁（进程已死，SIGTERM 等致 finally 未执行）——清除重获
        try:
            LOCK.unlink()
        except OSError:
            return False
    try:
        LOCK.write_text(str(os.getpid()))
        return True
    except OSError:
        return False


def _unlock() -> None:
    try:
        LOCK.unlink()
    except FileNotFoundError:
        pass


def _fetch(url: str, dest: Path) -> None:
    """urllib 下载，带 .part 断点续传（Range）。

    服务器忽略 Range 返回 200 时从头写；连接中断后下次调用可从已下载处续。
    """
    import urllib.request

    last_err = None
    for attempt in range(3):
        have = dest.stat().st_size if dest.exists() else 0
        req = urllib.request.Request(url)
        if have:
            req.add_header("Range", f"bytes={have}-")
        try:
            with urllib.request.urlopen(req, timeout=60) as resp, open(dest, "ab" if have else "wb") as out:
                if have and getattr(resp, "status", 200) == 200:
                    # 源不支持 Range：丢弃半截，从头写
                    out.seek(0)
                    out.truncate(0)
                while True:
                    chunk = resp.read(1 << 16)
                    if not chunk:
                        break
                    out.write(chunk)
            if dest.stat().st_size > 0:
                return
            last_err = RuntimeError("下载为空")
        except Exception as e:  # noqa: BLE001
            last_err = e
        print(f"  ⚠️ 第 {attempt + 1} 次失败: {last_err}，重试……", file=sys.stderr)
    raise RuntimeError(f"下载失败: {url} ({last_err})")


def _fetch_any(rel: str, dest: Path) -> None:
    """按 MIRRORS 顺序下载；单源失败自动换源，已下部分保留给下一源续传。"""
    errors = []
    for mirror in MIRRORS:
        url = f"{mirror}/{rel}"
        try:
            print(f"↓ {dest.name} ← {url}")
            _fetch(url, dest)
            return
        except Exception as e:  # noqa: BLE001
            errors.append(str(e))
            print(f"  ↪ 换源：{e}", file=sys.stderr)
    raise RuntimeError("所有镜像均失败: " + " | ".join(errors))


def main() -> int:
    if ONNX_FILE.exists() and ONNX_FILE.stat().st_size > MIN_ONNX_BYTES:
        print(f"✅ 模型已在: {ONNX_FILE}")
        return 0
    if not _lock():
        print("⏳ 已有下载进程在跑（锁存在），跳过。", file=sys.stderr)
        return 0
    try:
        ONNX_DIR.mkdir(parents=True, exist_ok=True)
        print(f"下载 bge-base-zh-v1.5（~400MB，{len(MIRRORS)} 个镜像）→ {MODEL_DIR}")
        part = ONNX_DIR / "model.onnx.part"
        _fetch_any("onnx/model.onnx", part)
        if part.stat().st_size < MIN_ONNX_BYTES:
            part.unlink(missing_ok=True)
            raise RuntimeError("model.onnx 过小，下载不完整")
        part.rename(ONNX_FILE)
        for f in FILES:
            _fetch_any(f, MODEL_DIR / f)
        print(f"✅ 模型安装完成: {MODEL_DIR}")
        return 0
    except Exception as e:  # noqa: BLE001
        print(f"❌ 模型下载失败: {e}", file=sys.stderr)
        return 1
    finally:
        _unlock()


if __name__ == "__main__":
    sys.exit(main())
"""
忆时 Memory Core - 记忆胶囊系统核心引擎

功能:
  - 记忆向量化存储 (ChromaDB)
  - 类人检索 (语义 + 近因 + 情绪 + 频率 + 联想)
  - 时间胶囊管理
  - 批量导入导出
  - 关系图谱维护

用法示例:
  python3 memory_core.py init
  python3 memory_core.py store "今天学会了Python装饰器" --type task --emotion high
  python3 memory_core.py recall "Python学习" --limit 5 --expand
  python3 memory_core.py capsule lock --unlock-at "2026-01-01" --summary "年度记忆"
  python3 memory_core.py capsule list
  python3 memory_core.py import-file memories.md --format markdown
  python3 memory_core.py export --format timeline --output "2026回顾.md"
  python3 memory_core.py stats
"""

import argparse
import json
import math
import os
import re
import subprocess
import sys
import tempfile
import time
import uuid
import warnings
import contextlib
from collections import defaultdict
from datetime import datetime, timedelta, timezone
from io import StringIO
from pathlib import Path
try:
    from http.server import HTTPServer, BaseHTTPRequestHandler
    from urllib.parse import urlparse, parse_qs
    _HAS_HTTP = True
except ImportError:
    _HAS_HTTP = False

# 静默 ONNX C++ 层 Schema error 滋扰
os.environ['TF_CPP_MIN_LOG_LEVEL'] = '3'
warnings.filterwarnings('ignore')

def _die_missing_deps(pkg_hint):
    """顶层依赖缺失——给自愈指引，勿裸崩（Windows 无 python3 亦须可读）。"""
    print(
        f"\n❌ 忆时缺少依赖：{pkg_hint}\n"
        "   请先安装（以下任一）：\n"
        "   · 一键自愈: python3 ~/.local/share/yishi/scripts/install.py\n"
        "     （Windows PS: python $env:USERPROFILE\\.local\\share\\yishi\\scripts\\install.py）\n"
        "     （Windows cmd: python %USERPROFILE%\\.local\\share\\yishi\\scripts\\install.py）\n"
        "   · 手动: python3 -m pip install -r ~/.local/share/yishi/scripts/requirements.txt\n"
        "     （Windows PS: python -m pip install -r $env:USERPROFILE\\.local\\share\\yishi\\scripts\\requirements.txt）",
        file=sys.stderr,
    )
    sys.exit(3)

try:
    import jieba  # noqa: E402  须在 filterwarnings 之后 import，压 pkg_resources 弃用警告
except ImportError:
    _die_missing_deps("jieba（BM25 关键词检索）")
jieba.setLogLevel(60)  # 静默建词典日志

@contextlib.contextmanager
def _silent_import():
    """OS 级重定向 stderr，连 C++ std::cerr 一并静默"""
    devnull = os.open(os.devnull, os.O_WRONLY)
    old_fd2 = os.dup(2)          # 备份原 stderr
    os.dup2(devnull, 2)          # fd 2 → /dev/null
    os.close(devnull)
    try:
        yield
    finally:
        os.dup2(old_fd2, 2)      # 恢复原 stderr
        os.close(old_fd2)

try:
    with _silent_import():
        import chromadb
except ImportError:
    _die_missing_deps("chromadb（向量库）")

# 模型和数据统一存到 ~/.local/share/yishi/ 下（全英文目录，跨平台统一，避免中文路径乱码；
# 2026-08-19 迁自 ~/.local/share/opencode/忆时/），不放在技能目录（更新技能会覆盖），
# 也不放在 ~/.cache/（清缓存会被删除）。opencode 与 DSH 双栖共用此目录。
# YISHI_DATA_DIR 可覆盖根目录（与 models-install.py / install.py 同源解析，防路径错位）。
LOCAL_BASE = os.environ.get("YISHI_DATA_DIR") or os.path.join(Path.home(), ".local", "share", "yishi")

DATA_DIR = os.environ.get("MEMO_DIR") or os.path.join(LOCAL_BASE, "data")

if os.environ.get("YISHI_DATA_DIR") and not os.environ.get("MEMO_DIR"):
    print("ℹ️ 已设 YISHI_DATA_DIR（根目录），数据存于其下 data/；如欲指定数据目录请用 MEMO_DIR", file=sys.stderr)

SKILL_MODEL_BASE = os.path.join(LOCAL_BASE, "models")

# 自动备份文件（JSONL 格式），存于 LOCAL_BASE 而非 data/ 中，
# 即使 data/ 被误删也能用 recover 命令重建记忆库。
# 可用环境变量 MEMO_BAK 覆盖（多实例/测试隔离）。
BACKUP_FILE = os.environ.get("MEMO_BAK") or os.environ.get("YISHI_BACKUP_FILE") or os.path.join(LOCAL_BASE, "memories_backup.jsonl")

# 情绪强度：统一用 0.0~1.0 数值表示（数值越大越重要/强烈）。
# 旧版词语（extreme/high/medium/low）自动映射为数值，兼容历史数据。
EMOTION_WORD_MAP = {"extreme": 1.0, "high": 0.8, "medium": 0.5, "low": 0.2}
EMOTION_WEIGHTS = dict(EMOTION_WORD_MAP)

def norm_emotion(val):
    """把任意情绪输入归一为 0.0~1.0 数值：
    - 数字字符串（"0.85"）→ 原值
    - 旧版词语（"high"）→ 映射数值
    - 无效 → 0.5
    """
    if val is None:
        return 0.5
    s = str(val).strip().lower()
    if s in EMOTION_WORD_MAP:
        return EMOTION_WORD_MAP[s]
    try:
        f = float(s)
        return max(0.0, min(1.0, f))
    except (ValueError, TypeError):
        return 0.5

def emotion_emoji(val):
    """按情绪数值映射 emoji：≥0.9 🔴、≥0.7 🟠、≥0.4 🟡、否则 🟢"""
    w = norm_emotion(val)
    if w >= 0.9: return "🔴"
    if w >= 0.7: return "🟠"
    if w >= 0.4: return "🟡"
    return "🟢"

RECALL_DECAY_DAYS = 90.0
VALID_TYPES = {"emotion", "decision", "task", "time", "preference", "context", "skill"}

# ── 混合检索（BM25 关键词路 + 向量路 RRF 融合）─
RRF_K = 60.0                # RRF 融合常数（标准值 60）
BM25_K1 = 1.5               # BM25 词频饱和参数
BM25_B = 0.75               # BM25 文档长度归一参数
BM25_SEM_CAP = 0.7          # BM25 归一化分封顶：关键词命中 ≠ 语义相关，防虚高顶榜
RECALL_SIM_MIN = 0.50       # 检索过滤：综合匹配分（用户所见"匹配%"）低于此值不展示（2026-08-22 哥哥定：>0.5 即看，取最相关3条）
RECALL_LIMIT_MAX = 3        # 检索条数硬上限：最相关 3 条（2026-08-22 哥哥定，--limit 更大亦截断）
MERGE_SIM_CLUSTER = 0.70    # 有机合并：语义相似度≥此值，存时检索候选供 AI 决策
MERGE_SHOW_MAX = 3          # 存时打印候选最多条数（最相关 N 条）
BM25_KEYWORD_WEIGHT = 2     # keywords 分词重复次数（权重×2）
_STOP_WORDS = frozenset(
    "的了是在我有和就都而及与或一个不也这那你们我们他们她他它它们被把让从到对向为以于之乎者也"
    "啊呢吧吗哦嗯好行对没啥啥很最更再又还已经正在将要可以可能应该必须不要没有什么怎么为什么"
    "因为所以但是然而如果那么虽然尽管只是还是或者以及关于对于通过由于根据按照例如比如这个那个"
    "自己这里那里时候时候东西事情问题方法方式情况结果原因目的意义价值作用影响关系问题"
)

_embedding_client = None
_embedding_fn = None


def _model_lock_held() -> bool:
    """探测 models-install 锁：存在且 PID 存活=有下载进程在跑。"""
    lock = Path(os.path.join(tempfile.gettempdir(), "yishi-models-install.lock"))
    if not lock.exists():
        return False
    try:
        pid = int(lock.read_text().strip())
    except (ValueError, OSError):
        return False
    try:
        os.kill(pid, 0)
        return True
    except ProcessLookupError:
        return False
    except PermissionError:
        return True


def _ensure_model():
    """模型缺失时自动下载（调 models-install.py，阻塞等待至成或败）。

    兜底触发：插件 apply 的自动下载若未生效（环境差异/被杀），
    首次 embedding 调用（recall/store 等）时此处兜底，保证模型必下。
    若已有下载进程在跑（apply spawn），则等待其完成，不重复下载。
    """
    installer = os.path.join(os.path.dirname(os.path.abspath(__file__)), "models-install.py")
    if not os.path.exists(installer):
        # 兜底：迁移期/散装脚本可能不在 scripts/ 同层，回退 LOCAL_BASE/scripts/
        fallback = os.path.join(LOCAL_BASE, "scripts", "models-install.py")
        if os.path.exists(fallback):
            installer = fallback
        else:
            print(
                f"❌ bge 模型缺失且无安装脚本：{installer}\n"
                "   请手动下载：见 modules/08-setup.md（hf-mirror Xenova/bge-base-zh-v1.5）。",
                file=sys.stderr,
            )
            sys.exit(1)
    bge_onnx = os.path.join(SKILL_MODEL_BASE, "bge-base-zh-v1.5", "onnx", "model.onnx")
    if os.path.exists(bge_onnx):
        return
    print(
        "⬇️  bge 模型缺失，自动下载中（约 400MB，hf-mirror；首次使用需等待）……",
        file=sys.stderr,
    )
    # 已有下载进程在跑（apply 触发）→ 轮询等待其完成（最长 60 分钟）
    waited = 0
    while _model_lock_held() and not os.path.exists(bge_onnx) and waited < 3600:
        time.sleep(10)
        waited += 10
    if not os.path.exists(bge_onnx):
        r = subprocess.run([sys.executable, installer])
        if r.returncode != 0 or not os.path.exists(bge_onnx):
            print(
                f"❌ 模型下载失败（rc={r.returncode}）。请手动运行：python3 {installer}",
                file=sys.stderr,
            )
            sys.exit(1)


def get_embedding_fn():
    global _embedding_fn
    if _embedding_fn is None:
        # 仅支持 bge-base-zh-v1.5（768 维）。模型目录：
        #   {SKILL_MODEL_BASE}/bge-base-zh-v1.5/{onnx/model.onnx, tokenizer.json, ...}
        # 无回退——MiniLM 384 维与 768 维数据不兼容，曾致维度冲突。
        bge_dir = os.path.join(SKILL_MODEL_BASE, "bge-base-zh-v1.5")
        bge_onnx = os.path.join(bge_dir, "onnx", "model.onnx")
        if not os.path.exists(bge_onnx):
            _ensure_model()
        with _silent_import():
            _embedding_fn = _BGEONNX(bge_dir)
    return _embedding_fn


class _BGEONNX:
    """bge-base-zh-v1.5 ONNX embedding：768 维，CLS pooling，L2 归一化。

    中文语义检索，显著优于英文模型 all-MiniLM-L6-v2。
    模型目录：{SKILL_MODEL_BASE}/bge-base-zh-v1.5/{onnx/model.onnx, tokenizer.json, ...}
    """

    def __init__(self, model_dir):
        try:
            import onnxruntime as ort
            from tokenizers import Tokenizer
        except ImportError as e:
            _die_missing_deps(f"{e.name}（embedding 推理依赖）")

        self._np = __import__("numpy")
        self.session = ort.InferenceSession(
            os.path.join(model_dir, "onnx", "model.onnx"),
            providers=["CPUExecutionProvider"],
        )
        self.tok = Tokenizer.from_file(os.path.join(model_dir, "tokenizer.json"))
        self.tok.enable_truncation(max_length=512)
        self.tok.enable_padding(pad_id=0, pad_token="[PAD]")

    @staticmethod
    def name():
        return "bge-base-zh-v1.5"

    def embed_query(self, input):
        # Chroma 1.5.9 embed_query 为 batch 语义：入 ['q'] 出 [[768]]；直调可能传 str——双兼容
        if isinstance(input, str):
            input = [input]
        return self.__call__(input)

    def embed_documents(self, input):
        return self.__call__(input)

    def __call__(self, input):
        np = self._np
        if isinstance(input, str):
            input = [input]
        enc = self.tok.encode_batch(list(input))
        ids = [e.ids for e in enc]
        attn = [e.attention_mask for e in enc]
        tids = [e.type_ids for e in enc]
        out = self.session.run(None, {
            "input_ids": np.array(ids, dtype=np.int64),
            "attention_mask": np.array(attn, dtype=np.int64),
            "token_type_ids": np.array(tids, dtype=np.int64),
        })[0]
        emb = out[:, 0, :]
        emb = emb / np.linalg.norm(emb, axis=1, keepdims=True)
        return emb.astype(np.float32).tolist()


def get_client():
    global _embedding_client
    if _embedding_client is None:
        os.makedirs(DATA_DIR, exist_ok=True)
        last_err = None
        # 2026-08-14 修复：多会话并发时 chroma 偶发抛
        #   InternalError: (code: 8) attempt to write a readonly database
        # （sqlite delete journal 模式写互斥 + 并发窗口）。库已转 WAL，此处再加重试兜底。
        for _ in range(6):
            try:
                _embedding_client = chromadb.PersistentClient(path=DATA_DIR)
                break
            except chromadb.errors.InternalError as e:
                if "readonly" not in str(e).lower() and "locked" not in str(e).lower():
                    raise
                last_err = e
                time.sleep(0.5)
        else:
            raise last_err
    return _embedding_client


def get_collection(client, name):
    ef = get_embedding_fn()
    try:
        if ef:
            return client.get_or_create_collection(name=name, metadata={"hnsw:space": "cosine"}, embedding_function=ef)
        return client.get_or_create_collection(name=name, metadata={"hnsw:space": "cosine"})
    except ValueError as e:
        if "embedding function" in str(e) and "conflict" in str(e).lower():
            # 存量 collection 由旧 embedding（onnx_mini_lm_l6_v2）创建，与 bge 维度不兼容：
            # 不传 ef，沿用持久化配置读写，保证新旧数据 embedding 一致（不回退即全部不可用）。
            return client.get_or_create_collection(name=name, metadata={"hnsw:space": "cosine"})
        raise


def _update_meta_total(client, field, delta):
    try:
        meta = get_collection(client, "meta")
        if meta.count() == 0:
            return
        s = json.loads(meta.get(ids=["state"])["documents"][0])
        s[field] = s.get(field, 0) + delta
        meta.update(documents=[json.dumps(s)], ids=["state"], metadatas=[{"key": "state"}])
    except Exception:
        pass


def _now():
    return datetime.now()


# ========== 自动备份 ==========
def _append_backup(mem_id, content, metadata):
    """每次存储记忆时追加一条 JSONL 到备份文件，与 data/ 独立存放。"""
    try:
        record = {"id": mem_id, "content": content, "metadata": metadata, "backup_at": _now().isoformat()}
        line = json.dumps(record, ensure_ascii=False)
        with open(BACKUP_FILE, "a", encoding="utf-8") as f:
            f.write(line + "\n")
    except Exception as e:
        print(f"  ⚠️ 备份写入失败: {e}", file=sys.stderr)


def _load_backups():
    """读取全部备份记录，返回列表。"""
    if not os.path.exists(BACKUP_FILE):
        return []
    records = []
    with open(BACKUP_FILE, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            try:
                records.append(json.loads(line))
            except json.JSONDecodeError:
                continue
    return records


# ========== 混合检索（BM25 关键词路）==========
def _tokenize(text):
    """jieba 分词 + 过滤停用词/单字中文/纯符号。keywords 以 BM25_KEYWORD_WEIGHT 倍权重入。"""
    toks = []
    parts = text.split("|||")  # 分隔符：content ||| keywords
    for pi, part in enumerate(parts):
        repeat = BM25_KEYWORD_WEIGHT if pi == 1 else 1
        for w in jieba.lcut(part):
            w = w.strip().lower()
            if not w or w in _STOP_WORDS:
                continue
            if len(w) == 1 and "\u4e00" <= w <= "\u9fff":
                continue
            if not re.search(r"[\w\u4e00-\u9fff]", w):
                continue
            toks.extend([w] * repeat)
    return toks


def _bm25_scores(docs, query_tokens, k1=BM25_K1, b=BM25_B):
    """对全部文档打 BM25 分，返回 {mem_id: score}。"""
    N = len(docs)
    if N == 0 or not query_tokens:
        return {}
    df = {}
    doc_len = {}
    for i, (_, toks) in enumerate(docs):
        seen = set()
        for t in toks:
            if t not in seen:
                df[t] = df.get(t, 0) + 1
                seen.add(t)
        doc_len[i] = len(toks)
    avgdl = sum(doc_len.values()) / N
    scores = {}
    for i, (mid, toks) in enumerate(docs):
        tf = {}
        for t in toks:
            tf[t] = tf.get(t, 0) + 1
        dl = doc_len[i]
        s = 0.0
        for q in query_tokens:
            if q not in tf:
                continue
            idf = math.log(1.0 + (N - df.get(q, 0) + 0.5) / (df.get(q, 0) + 0.5))
            s += idf * tf[q] * (k1 + 1.0) / (tf[q] + k1 * (1.0 - b + b * dl / avgdl))
        scores[mid] = s
    return scores


def _bm25_search(query, limit):
    """BM25 关键词检索：以 JSONL 备份为数据源，返回 [(mem_id, score), ...] 降序。"""
    records = _load_backups()
    if not records:
        return []
    docs = []
    for rec in records:
        mid = rec.get("id", "")
        content = rec.get("content", "") or ""
        meta = rec.get("metadata", {}) or {}
        kw = meta.get("keywords", "") or ""
        if mid and (content or kw):
            docs.append((mid, _tokenize(f"{content}|||{kw}")))
    if not docs:
        return []
    qt = _tokenize(query)
    scores = _bm25_scores(docs, qt)
    ranked = sorted(scores.items(), key=lambda x: -x[1])
    if limit:
        ranked = ranked[:limit]
    return ranked


def _rrf_merge(ranked_lists, limit):
    """Reciprocal Rank Fusion：多路排名融合，返回 [(mem_id, rrf_score), ...] 降序。"""
    rrf = {}
    for lst in ranked_lists:
        for rank, (mid, _) in enumerate(lst):
            rrf[mid] = rrf.get(mid, 0.0) + 1.0 / (RRF_K + rank + 1.0)
    order = sorted(rrf.items(), key=lambda x: -x[1])
    if limit:
        order = order[:limit]
    return order


# ========== init ==========
def cmd_init(args):
    client = get_client()
    mem_col = get_collection(client, "memories")
    rel_col = get_collection(client, "relationships")
    meta_col = get_collection(client, "meta")

    if meta_col.count() == 0:
        state = {
            "version": "1.0.0",
            "created_at": _now().isoformat(),
            "total_memories": 0,
            "total_capsules": 0,
            "total_relationships": 0,
        }
        meta_col.add(documents=[json.dumps(state)], metadatas=[{"key": "state"}], ids=["state"])

    print(f"忆时记忆系统初始化完成")
    print(f"  存储路径: {DATA_DIR}")
    print(f"  记忆集合: {mem_col.count()} 条")
    print(f"  关系集合: {rel_col.count()} 条")
    print(f"  ChromaDB: {chromadb.__version__}")


# ========== store ==========
def _merge_keywords(old_kw, new_kw):
    merged = []
    for kw in (old_kw or "").split(",") + (new_kw or "").split(","):
        k = kw.strip()
        if k and k not in merged:
            merged.append(k)
    return ",".join(merged)


def make_title(content, max_len=None):
    """从内容生成简洁标题（图谱节点用，≤10 字）。

    规则：取首个语义片段（按逗/句/冒/破折/括号切），去掉常见前缀，
    截断至 max_len（默认 10）。供 title 字段（节点标签）。
    """
    import re
    max_len = max_len or 10
    s = (content or "").strip()
    for pfx in ["【前因】", "【梳理】", "【结果】", "【对策】", "【01oj项目", "【项目全貌】", "【工作模式与偏好】"]:
        if s.startswith(pfx):
            s = s[len(pfx):]
    m = re.split(r"[，。！？：；、—\-–\n\(（]", s)
    title = m[0].strip() if m and m[0].strip() else s[:max_len]
    if len(title) > max_len:
        title = title[:max_len]
    return title.strip() or (content or "")[:max_len]


def cmd_store(args):
    client = get_client()
    mem_col = get_collection(client, "memories")
    now = _now()
    emo_val = norm_emotion(args.emotion)
    mem_type = args.type or "context"

    metadata = {
        "type": mem_type,
        "emotion": emo_val,
        "emotion_weight": emo_val,
        "title": getattr(args, "title", None) or make_title(args.content),
        "created_at": now.isoformat(),
        "created_date": now.strftime("%Y-%m-%d"),
        "updated_at": now.isoformat(),
        "keywords": args.keywords or "",
        "source": args.source or "manual",
        "source_session": args.session or "",
        "frequency": 1,
        "recall_count": 0,
    }
    # 场景与活动时间段（段段时间语义，借鉴分层记忆场景块）
    if getattr(args, "scene", None):
        metadata["scene"] = args.scene
    if getattr(args, "activity_start", None):
        metadata["activity_start"] = args.activity_start
    if getattr(args, "activity_end", None):
        metadata["activity_end"] = args.activity_end
    # skill 类型自动追加 "skill" 标签
    if mem_type == "skill":
        if "skill" not in (args.keywords or ""):
            args.keywords = (args.keywords + ",skill") if args.keywords else "skill"
        metadata["keywords"] = args.keywords
    # 任务状态（贾维斯块③）：task 默认 pending；--status 显式指定
    if getattr(args, "status", None):
        if args.status not in TASK_STATUSES:
            print(f"错误: --status 须为 {'/'.join(TASK_STATUSES)}"); sys.exit(1)
        metadata["status"] = args.status
    elif mem_type == "task":
        metadata["status"] = "pending"
    # 传播 --skill-* 参数到 metadata
    for key in ("skill_name", "skill_summary", "skill_strategy", "skill_avoid",
                 "skill_triggers", "skill_input", "skill_output", "skill_version",
                 "skill_path"):
        val = getattr(args, key.replace("-", "_"), None)
        if val is not None:
            metadata[key] = val

    # ── 技能同名查重（贾维斯块④：自动习得之版本化入口）──
    # 同名技能已存 → 打印已有版本，供 AI 决定 --merge-ids 合并升级（宜 --skill-version 递增），
    # 不阻断存储（AI 读完决策）。
    if mem_type == "skill" and (getattr(args, "skill_name", None) or "").strip():
        try:
            dup = mem_col.get(where={"$and": [{"type": "skill"},
                                              {"skill_name": args.skill_name.strip()}]})
            if dup["ids"]:
                print(f"⚠️ 已有同名技能「{args.skill_name}」{len(dup['ids'])} 条（宜合并升级，勿重复造轮）：")
                for i in range(min(len(dup["ids"]), 3)):
                    dm = dup["metadatas"][i] if dup["metadatas"] else {}
                    dd = (dup["documents"][i] if dup["documents"] else "").replace("\n", " ")[:70]
                    dv = dm.get("skill_version", "") or "?"
                    print(f"   {i+1}. 🆔 {dup['ids'][i]}  v{dv}  {dd}")
                print(f"   → 合并升级：store \"<新版全文>\" --type skill --merge-ids \"<上述ID>\" --skill-version <递增版本>")
        except Exception:
            pass

    # ── 语义查簇：检索相似 ≥70% 候选，供 AI 读取决策 ──
    # 2026-08-22 定稿：有机合并=AI 读取候选原文，判断能否综合成一条。
    #   能合并 → --merge-ids "id1,id2" 删旧存新（内容=综合合并版）；
    #   不能 → 机械存储兜底（或 --force 静默）。决策权在 AI，脚本不自动拼不自动删。
    cluster = []
    # 有 --parent（显式挂载）或 --force 时，跳过候选检查（父节点已明确，不合并）
    if not getattr(args, "force", False) and not getattr(args, "parent", None):
        try:
            cq = mem_col.query(query_texts=[args.content], n_results=3)
            if cq["ids"] and cq["ids"][0]:
                for j in range(len(cq["ids"][0])):
                    mid = cq["ids"][0][j]
                    dist = cq["distances"][0][j] if cq["distances"] else 1.0
                    sem = 1.0 - dist
                    if sem >= MERGE_SIM_CLUSTER:
                        cluster.append((mid, sem))
        except Exception:
            cluster = []

    # 候选父节点检索：查相似度稍低（0.45~0.70）的容器类节点，供 AI 决定是否 --parent 挂载
    # 树型存储：新记忆可能属于某主题树（入口/项目/技能），挂为子节点而非平铺
    parent_candidates = []
    if not getattr(args, "force", False) and not getattr(args, "parent", None):
        try:
            pq = mem_col.query(query_texts=[args.content], n_results=8)
            if pq["ids"] and pq["ids"][0]:
                for j in range(len(pq["ids"][0])):
                    pmid = pq["ids"][0][j]
                    pdist = pq["distances"][0][j] if pq["distances"] else 1.0
                    psem = 1.0 - pdist
                    # 容器特征：有子树（first_child）或 type=skill 或关键字含"入口/项目/技能"
                    if 0.40 <= psem < MERGE_SIM_CLUSTER:
                        try:
                            pmm = mem_col.get(ids=[pmid])["metadatas"]
                            if not pmm or pmm[0] is None:
                                continue
                            pmeta = pmm[0]
                            pfc = (pmeta.get("first_child", "") or "")
                            pkws = (pmeta.get("keywords", "") or "")
                            is_container = bool(pfc) or pmeta.get("type") == "skill" or any(
                                k in pkws for k in ("入口", "项目", "技能", "topic", "目录"))
                            if is_container:
                                parent_candidates.append((pmid, psem))
                        except Exception:
                            pass
        except Exception:
            parent_candidates = []

    # AI 决策：合并（--merge-ids）→ 删指定旧记忆（可 0 条=空串），存合并版为新条目
    # 统一路径：选 N 条（0~N）→ 删 N 条 → 并（所选旧内容+新内容，AI 手写综合版）
    if args.merge_ids is not None:
        ids_to_merge = [i.strip() for i in args.merge_ids.split(",") if i.strip()]
        dropped = 0
        inherit_parent = None
        for mid in ids_to_merge:
            try:
                # 合并删节点前：若该节点有子节点（first_child），先迁移子链到其父下，
                # 避免删父后子链悬挂（孤儿节点）
                try:
                    _og = mem_col.get(ids=[mid])
                    if _og["metadatas"] and _og["metadatas"][0]:
                        _om = _og["metadatas"][0]
                        _ofc = (_om.get("first_child", "") or "")
                        _opid = (_om.get("parent_id", "") or "")
                        if _ofc:
                            # 第一个子节点挂到祖父下（或升根）
                            if _opid:
                                _link_as_child(mem_col, _ofc, _opid)
                            else:
                                _mm = mem_col.get(ids=[_ofc])["metadatas"]
                                if _mm and _mm[0] is not None:
                                    _m2 = dict(_mm[0])
                                    _m2["parent_id"] = ""
                                    mem_col.update(ids=[_ofc], metadatas=[_m2])
                                    _append_backup(_ofc, None, _m2)
                            print(f"  ↪ 果链迁移：{_ofc[:12]} 重挂回其因 {_opid[:12]} 下（中间节点 {mid[:12]} 合并删除，因果方向不变）")
                        # 记录被删节点父链：合并产物继承（保持树形层级）
                        if _opid and inherit_parent is None:
                            inherit_parent = _opid
                except Exception:
                    pass
                mem_col.delete(ids=[mid])
                dropped += 1
            except Exception:
                pass
        # 综合版作为新条目存储（选 0 条时=新内容原样存）
        new_mid = str(uuid.uuid4())
        mem_col.add(documents=[args.content], metadatas=[metadata], ids=[new_mid])
        _update_meta_total(client, "total_memories", 1)
        _append_backup(new_mid, args.content, metadata)
        # 合并产物继承被删节点的父（保持树形：产物回到原层级）
        if inherit_parent:
            try:
                _link_as_child(mem_col, new_mid, inherit_parent)
                print(f"  ↪ 合并产物继承因链：{new_mid[:12]} 挂到其因 {inherit_parent[:12]} 下（保持因果方向）")
            except Exception:
                pass
        if dropped:
            print(f"✅ AI 有机合并：已删 {dropped} 条旧记忆，综合版存为新条目")
        else:
            print(f"✅ 机械存储（选 0 条合并，--merge-ids 为空）：已存为新条目")
        return new_mid

    # 有候选 → 先判后存：挂起不落库，打印候选（内容全量，最多 3 条最相关），等 AI 决策
    # 脚本不代决：仅提示。AI 读候选后统一走 --merge-ids（N 可 0=空串）
    if cluster and not getattr(args, "force", False) and not getattr(args, "parent", None):
        cluster.sort(key=lambda x: -x[1])
        shown = cluster[:MERGE_SHOW_MAX]
        print(f"🔎 发现语义相似候选 {len(cluster)} 条（≥{MERGE_SIM_CLUSTER:.0%}），请 AI 读取判断（最相关 {len(shown)} 条）：")
        for mid, sem in shown:
            try:
                og = mem_col.get(ids=[mid])
                oc = og["documents"][0] if og["documents"] else ""
                ok = (og["metadatas"][0].get("keywords", "") or "") if og["metadatas"] else ""
                od = (og["metadatas"][0].get("created_date", "") or "") if og["metadatas"] else ""
            except Exception:
                oc, ok, od = "", "", ""
            print(f"\n  ── 相似 {sem:.0%}  ID: {mid}  创建: {od}  关键字: {ok}")
            print(f"  {oc}")
        print(f"\n  ⚠️ 先判后存：本次未写入。统一路径：")
        print(f"   ① 选：从候选中选出值得合并者（可 0 条）")
        print(f"   ② 删：选 N 条 → --merge-ids \"ID1,ID2,...\"；选 0 条 → --merge-ids \"\"（空串）")
        print(f"   ③ 并：综合版=所选旧内容+新内容，AI 手写合并后存入（选 0 条=新内容原样存）")
        print(f"   示例：store \"<综合合并版>\" --merge-ids \"ID1,ID2\"（选2条）")
        print(f"   示例：store \"<新内容>\" --merge-ids \"\"（选0条）")
        # 候选父节点：树型存储提示
        if parent_candidates:
            parent_candidates.sort(key=lambda x: -x[1])
            print(f"\n  🔗 可选因节点（因果树）：本内容若为下述事件之果（前因），挂其下 --parent 成链：")
            for pmid, psem in parent_candidates[:3]:
                try:
                    pmm = mem_col.get(ids=[pmid])["metadatas"]
                    pmeta = pmm[0] if pmm and pmm[0] else {}
                    ptitle = _tree_label("", pmeta) or pmid[:8]
                    ptype = pmeta.get("type", "")
                except Exception:
                    ptitle, ptype = pmid[:8], ""
                print(f"     └─ [{pmid}] {ptitle}（{ptype}，相似{psem:.0%}）→ 挂载: store \"<内容>\" --parent {pmid}")
        return None

    mem_id = str(uuid.uuid4())

    # ── 链式前向星挂载：--parent <父ID> 把本节点挂到父的子树链 ──
    # 邻接表结构：父节点 metadata.first_child=首子ID；子节点 metadata.next_sibling=下一兄弟ID；
    # 子节点 metadata.parent_id=父ID。遍历：沿 first_child → next_sibling 走链。
    parent_id = getattr(args, "parent", None)
    if parent_id:
        try:
            p_meta = mem_col.get(ids=[parent_id])["metadatas"]
            if p_meta and p_meta[0] is not None:
                parent_meta = dict(p_meta[0])
                fc = parent_meta.get("first_child", "") or ""
                if not fc:
                    # 父无首子 → 本节点为首子
                    parent_meta["first_child"] = mem_id
                    mem_col.update(ids=[parent_id], metadatas=[parent_meta])
                    _append_backup(parent_id, None, parent_meta)
                else:
                    # 沿兄弟链找尾，挂 next_sibling
                    cur_id, cur_meta = fc, None
                    for _ in range(50):
                        cm = mem_col.get(ids=[cur_id])["metadatas"]
                        if not cm or cm[0] is None:
                            break
                        cur_meta = dict(cm[0])
                        ns = cur_meta.get("next_sibling", "") or ""
                        if not ns:
                            cur_meta["next_sibling"] = mem_id
                            mem_col.update(ids=[cur_id], metadatas=[cur_meta])
                            _append_backup(cur_id, None, cur_meta)
                            break
                        cur_id = ns
                metadata["parent_id"] = parent_id
                _ptl = _tree_label("", parent_meta) or parent_id[:8]
                print(f"🔗 因果链挂载：本条为「{_ptl}」之果，挂其下（父=因 {parent_id[:12]}，链式前向星）")
                if fc:
                    print(f"     └─ 父已有果（子树非空）：本条与之并列，同因多果——因果链顺延")
            else:
                print(f"⚠️ 父节点 {parent_id[:12]} 不存在或已删，本节点悬空存储")
        except Exception as e:
            print(f"⚠️ 挂载失败（{e}），本节点独立存储")

    mem_col.add(documents=[args.content], metadatas=[metadata], ids=[mem_id])
    _update_meta_total(client, "total_memories", 1)

    # 自动备份到 JSONL（与 data/ 独立，不怕误删）
    _append_backup(mem_id, args.content, metadata)

    # 自动建语义关联：找相似记忆，写入 relationships 集合
    # 关键词各自保留，不做跨记忆融合（避免关键词雪球式膨胀）
    try:
        rel_col = get_collection(client, "relationships")
        similar = mem_col.query(query_texts=[args.content], n_results=3)
        if similar["ids"] and similar["ids"][0]:
            for j in range(len(similar["ids"][0])):
                sid = similar["ids"][0][j]
                if sid == mem_id:
                    continue
                sdist = similar["distances"][0][j] if similar["distances"] else 1.0
                ssem = 1.0 - sdist
                if ssem >= MERGE_SIM_CLUSTER:
                    rel_col.add(
                        documents=[f"{mem_id}->{sid}"],
                        metadatas=[{"source": mem_id, "target": sid, "score": round(ssem, 3)}],
                        ids=[str(uuid.uuid4())],
                    )
            _update_meta_total(client, "total_relationships", 1)
    except Exception:
        pass

    print(f"记忆已存储")
    print(f"  ID: {mem_id}")
    print(f"  类型: {mem_type}  情绪: {emo_val} {emotion_emoji(emo_val)}")
    if metadata.get("scene"):
        print(f"  场景: {metadata['scene']}")
    if metadata["keywords"]:
        print(f"  关键字: {metadata['keywords']}")
    print(f"  已自动备份到: {BACKUP_FILE}")
    return mem_id


# ========== 记忆树渲染（渐进式披露） ==========
def _tree_label(doc, meta):
    """节点标签：title 优先，无则取内容首段（≤10字）。"""
    t = (meta.get("title", "") or "").strip()
    if t:
        return t[:12]
    d = (doc or "").strip().replace("\n", " ")
    return d[:10] + ("…" if len(d) > 10 else "")


def _tree_lines(mem_col, node_id, prefix, is_last, full, depth, max_depth, seen, out):
    """递归输出子树骨架（默认）/完整（full=True），渐进式披露。
    out: 输出列表。返回子节点数（含孙代）。"""
    g = mem_col.get(ids=[node_id])
    if not g["ids"]:
        return 0
    doc = g["documents"][0] if g["documents"] else ""
    meta = g["metadatas"][0] if g["metadatas"] else {}
    label = _tree_label(doc, meta)
    rc = int(meta.get("recall_count", 0) or 0)
    # 收集子节点
    children = []
    fc = (meta.get("first_child", "") or "")
    cur = fc
    for _ in range(100):
        if not cur or cur in seen:
            break
        cg = mem_col.get(ids=[cur])
        if not cg["ids"]:
            break
        cmeta = cg["metadatas"][0] if cg["metadatas"] else {}
        children.append((cur, cg["documents"][0] if cg["documents"] else "", cmeta))
        cur = (cmeta.get("next_sibling", "") or "")
    branch = "└─" if is_last else "├─"
    if children:
        n_child = len(children)
        suffix = f" ({n_child}子)"
    else:
        suffix = ""
    head = f"{prefix}{branch} [{node_id[:10]}] {label}{suffix} 🔥{rc}" if rc else f"{prefix}{branch} [{node_id[:10]}] {label}{suffix}"
    out.append(head)
    # 完整模式下，展示内容摘要（骨架模式不展示，渐进）
    if full:
        d = (doc or "").strip().replace("\n", " ")
        if d:
            out.append(f"{prefix}{'   ' if is_last else '│  '}   📝 {d[:40]}{'…' if len(d) > 40 else ''}")
    # 递归子节点
    child_prefix = prefix + ("   " if is_last else "│  ")
    total = 0
    if depth < max_depth:
        for i, (cid, cdoc, cmeta) in enumerate(children):
            seen.add(cid)
            total += _tree_lines(mem_col, cid, child_prefix, i == len(children) - 1,
                                 full, depth + 1, max_depth, seen, out) + 1
    else:
        total = len(children)
    return total


def _render_tree(mem_col, root_id, full=False, max_depth=3):
    """渲染某节点子树。返回 (lines, node_count)。"""
    g = mem_col.get(ids=[root_id])
    if not g["ids"]:
        return [], 0
    doc = g["documents"][0] if g["documents"] else ""
    meta = g["metadatas"][0] if g["metadatas"] else {}
    out = []
    out.append(f"🌳 树 [{root_id[:10]}] {_tree_label(doc, meta)}")
    children = []
    fc = (meta.get("first_child", "") or "")
    cur = fc
    for _ in range(100):
        if not cur:
            break
        cg = mem_col.get(ids=[cur])
        if not cg["ids"]:
            break
        cmeta = cg["metadatas"][0] if cg["metadatas"] else {}
        children.append((cur, cg["documents"][0] if cg["documents"] else "", cmeta))
        cur = (cmeta.get("next_sibling", "") or "")
    seen = {root_id}
    total = 0
    if children:
        out.append("    ├── 层级：")
        for i, (cid, cdoc, cmeta) in enumerate(children):
            seen.add(cid)
            total += _tree_lines(mem_col, cid, "    ", i == len(children) - 1,
                                 full, 0, max_depth, seen, out) + 1
    return out, total


# ========== recall ==========
def cmd_recall(args):
    client = get_client()
    mem_col = get_collection(client, "memories")
    rel_col = get_collection(client, "relationships")
    query = args.query
    # 最相关 3 条硬上限（哥哥 2026-08-22 定：'我只要3条'；--limit 传更大亦截断）
    limit = min(args.limit or 3, RECALL_LIMIT_MAX)
    min_weight = args.min_weight or 0.0
    type_filter = args.type_filter or None
    now = _now()

    # ── 混合检索：向量路 + BM25 关键词路，RRF 融合成候选池 ──
    no_embed = getattr(args, "no_embed", False)
    vec_ranked = []
    vec_semantic = {}
    if not no_embed:
        try:
            vec_results = mem_col.query(query_texts=[query], n_results=limit * 6)
            if vec_results["ids"] and vec_results["ids"][0]:
                for j in range(len(vec_results["ids"][0])):
                    mid = vec_results["ids"][0][j]
                    dist = vec_results["distances"][0][j] if vec_results["distances"] else 1.0
                    sem = 1.0 - dist
                    vec_ranked.append((mid, sem))
                    vec_semantic[mid] = sem
        except Exception:
            vec_ranked = []
            vec_semantic = {}

    bm25_ranked = _bm25_search(query, limit * 6)
    bm25_semantic = {}
    if bm25_ranked:
        bmax = max((s for _, s in bm25_ranked), default=0.0)
        if bmax > 0:
            for mid, s in bm25_ranked:
                bm25_semantic[mid] = s / bmax

    fused = _rrf_merge([vec_ranked, bm25_ranked], limit * 3)
    if not fused:
        print("没有找到相关记忆")
        return

    scored = []
    seen = set()
    cand_ids = [mid for mid, _ in fused]
    pool = {}
    try:
        pg = mem_col.get(ids=cand_ids)
        if pg["ids"]:
            for pi in range(len(pg["ids"])):
                pool[pg["ids"][pi]] = (
                    pg["documents"][pi] if pg["documents"] else "",
                    pg["metadatas"][pi] if pg["metadatas"] else {},
                )
    except Exception:
        pass

    for mid in cand_ids:
        if mid in seen or mid not in pool:
            continue
        seen.add(mid)
        doc, meta = pool[mid]
        semantic = max(vec_semantic.get(mid, 0.0), bm25_semantic.get(mid, 0.0) * BM25_SEM_CAP)
        em_w = float(meta.get("emotion_weight", 0.5))
        recall_count = int(meta.get("recall_count", 0))
        freq = int(meta.get("frequency", 1))
        freq_boost = min(math.log2(freq + 1) * 0.1, 0.2) + min(math.log2(recall_count + 1) * 0.02, 0.06)
        created = datetime.fromisoformat(meta.get("created_at", now.isoformat()))
        days_ago = (now - created).total_seconds() / 86400.0
        recency = math.exp(-math.log(2) * days_ago / RECALL_DECAY_DAYS)

        # 语义主导 0.60；情绪/近因/频率仅作微调（合计 0.40）
        score = 0.60 * semantic + 0.08 * em_w + 0.12 * recency + 0.20 * (0.3 + freq_boost)
        # 综合匹配分（用户所见"匹配%"）< 0.70 者不看——覆盖向量与 BM25 两路
        if score < RECALL_SIM_MIN:
            continue
        if score < min_weight:
            continue
        if type_filter and meta.get("type") != type_filter:
            continue

        scored.append({
            "id": mid, "content": doc, "score": round(score, 3),
            "semantic": round(semantic, 3), "emotion": meta.get("emotion", "medium"),
            "emotion_weight": em_w, "type": meta.get("type", "context"),
            "created_at": meta.get("created_at", ""), "created_date": meta.get("created_date", ""),
            "keywords": meta.get("keywords", ""),
            "scene": meta.get("scene", ""),
            "activity_start": meta.get("activity_start", ""),
            "activity_end": meta.get("activity_end", ""),
            "is_capsule": meta.get("is_capsule", "false") == "true",
            "capsule_unlock_at": meta.get("capsule_unlock_at", ""),
            "frequency": freq, "recall_count": recall_count, "is_expanded": False,
        })

    # === Trigger 关键词匹配（针对 type=skill 记忆） ===
    try:
        trigger_results = mem_col.get(where={"type": "skill"})
        if trigger_results["ids"]:
            query_lower = query.lower()
            for i in range(len(trigger_results["ids"])):
                tid = trigger_results["ids"][i]
                if tid in seen:
                    continue
                meta = trigger_results["metadatas"][i] if trigger_results["metadatas"] else {}
                kws = meta.get("keywords", "")
                trig_field = meta.get("skill_triggers", "") or ""
                triggers = [t.strip() for t in trig_field.split(",") if t.strip()]
                if not triggers:
                    triggers = [k.strip().split(":", 1)[1] for k in kws.split(",") if k.strip().startswith("trigger:")]
                if not any(t.lower() in query_lower for t in triggers if t.strip()):
                    continue
                doc = trigger_results["documents"][i] if trigger_results["documents"] else ""
                em_w = float(meta.get("emotion_weight", 0.5))
                freq = int(meta.get("frequency", 1))
                rc = int(meta.get("recall_count", 0))
                created = datetime.fromisoformat(meta.get("created_at", now.isoformat()))
                scored.append({
                    "id": tid, "content": doc, "score": 0.85,
                    "semantic": 0.7, "emotion": meta.get("emotion", "medium"),
                    "emotion_weight": em_w, "type": "skill",
                    "created_at": meta.get("created_at", ""), "created_date": meta.get("created_date", ""),
                    "keywords": kws,
                    "is_capsule": meta.get("is_capsule", "false") == "true",
                    "capsule_unlock_at": meta.get("capsule_unlock_at", ""),
                    "frequency": freq, "recall_count": rc, "is_expanded": True, "is_trigger_match": True,
                })
                seen.add(tid)
    except Exception:
        pass

    # === 联想扩散（两阶段），统一用真实语义值计分 ===
    def _compute_score(semantic, em_w, freq, recall_count, created):
        freq_boost = min(math.log2(freq + 1) * 0.1, 0.2) + min(math.log2(recall_count + 1) * 0.02, 0.06)
        days_ago = (now - created).total_seconds() / 86400.0
        recency = math.exp(-math.log(2) * days_ago / RECALL_DECAY_DAYS)
        # 语义主导 0.60；情绪/近因/频率仅作微调（合计 0.40）
        return 0.60 * semantic + 0.08 * em_w + 0.12 * recency + 0.20 * (0.3 + freq_boost)

    if args.expand and scored:
        expanded = set(s["id"] for s in scored)

        # 阶段一：关系链扩散（relationships 集合，按 metadata 精确查找）
        top_ids = [s["id"] for s in scored[:3]]
        for sid in top_ids:
            try:
                for rel in [rel_col.get(where={"source": sid}), rel_col.get(where={"target": sid})]:
                    if not rel["ids"]:
                        continue
                    for j in range(len(rel["ids"])):
                        rm = rel["metadatas"][j] if rel["metadatas"] else {}
                        partner = rm.get("target") if rm.get("source") == sid else rm.get("source")
                        if not partner or partner in expanded:
                            continue
                        expanded.add(partner)
                        pdoc = mem_col.get(ids=[partner])
                        if pdoc["documents"]:
                            pm = pdoc["metadatas"][0] if pdoc["metadatas"] else {}
                            rsem = float(rm.get("score", 0.40)) * 0.7
                            rew = float(pm.get("emotion_weight", 0.5))
                            rf = int(pm.get("frequency", 1))
                            rr = int(pm.get("recall_count", 0))
                            rc = datetime.fromisoformat(pm.get("created_at", now.isoformat()))
                            scored.append({
                                "id": partner, "content": pdoc["documents"][0],
                                "score": round(_compute_score(rsem, rew, rf, rr, rc), 3),
                                "semantic": round(rsem, 3),
                                "emotion": pm.get("emotion", "medium"),
                                "emotion_weight": rew,
                                "type": pm.get("type", "context"),
                                "created_at": pm.get("created_at", ""),
                                "created_date": pm.get("created_date", ""),
                                "keywords": pm.get("keywords", ""),
                                "is_capsule": pm.get("is_capsule", "false") == "true",
                                "capsule_unlock_at": pm.get("capsule_unlock_at", ""),
                                "frequency": rf,
                                "recall_count": rr,
                                "is_expanded": True,
                            })
            except Exception:
                pass

        # 阶段二：语义二次检索——取 top-2 结果之内容/关键字作新查询
        extra_queries = []
        for s in scored[:2]:
            if s.get("keywords"):
                extra_queries.append(s["keywords"])
            extra_queries.append(s["content"][:150])
        for eq in extra_queries:
            if not eq.strip():
                continue
            try:
                extra = mem_col.query(query_texts=[eq], n_results=4)
                if extra["ids"] and extra["ids"][0]:
                    for j in range(len(extra["ids"][0])):
                        eid = extra["ids"][0][j]
                        if eid in expanded:
                            continue
                        expanded.add(eid)
                        em = extra["metadatas"][0][j] if extra["metadatas"] else {}
                        edist = extra["distances"][0][j] if extra["distances"] else 1.0
                        esem = (1.0 - edist) * 0.7
                        eew = float(em.get("emotion_weight", 0.5))
                        ef = int(em.get("frequency", 1))
                        er = int(em.get("recall_count", 0))
                        ec = datetime.fromisoformat(em.get("created_at", now.isoformat()))
                        scored.append({
                            "id": eid,
                            "content": extra["documents"][0][j] if extra["documents"] else "",
                            "score": round(_compute_score(esem, eew, ef, er, ec), 3),
                            "semantic": round(esem, 3),
                            "emotion": em.get("emotion", "medium"),
                            "emotion_weight": eew,
                            "type": em.get("type", "context"),
                            "created_at": em.get("created_at", ""),
                            "created_date": em.get("created_date", ""),
                            "keywords": em.get("keywords", ""),
                            "is_capsule": em.get("is_capsule", "false") == "true",
                            "capsule_unlock_at": em.get("capsule_unlock_at", ""),
                            "frequency": ef,
                            "recall_count": er,
                            "is_expanded": True,
                        })
            except Exception:
                pass

    scored.sort(key=lambda x: x["score"], reverse=True)
    scored = scored[:limit]

    for item in scored:
        try:
            old = mem_col.get(ids=[item["id"]])
            if old["metadatas"]:
                m = old["metadatas"][0]
                m["recall_count"] = int(m.get("recall_count", 0)) + 1
                m["updated_at"] = now.isoformat()
                mem_col.update(ids=[item["id"]], metadatas=[m])
        except Exception:
            pass

    type_emoji = {"task": "📋", "decision": "⚖️", "preference": "⭐", "emotion": "💜", "time": "⏰", "context": "📌", "imported": "📥", "skill": "🔧"}

    total = len(scored)
    print(f"\n  记忆检索 ── 查询「{query}」 命中 {total} 条\n")

    TRUNC_SUFFIX = "…（已截断）"
    max_per = getattr(args, "max_chars_per_item", 0) or 0
    max_total = getattr(args, "max_total_chars", 0) or 0
    used_chars = 0

    for idx, item in enumerate(scored, 1):
        e_emoji = emotion_emoji(item.get("emotion"))
        emo_val = norm_emotion(item.get("emotion"))
        t_emoji = type_emoji.get(item.get("type", ""), "📄")
        capsule_tag = " 🔒" if item["is_capsule"] else ""
        assoc_tag = " ⟡关联" if item.get("is_expanded") else ""
        trigger_tag = " ⚡触发" if item.get("is_trigger_match") else ""
        scene_tag = f" | {item['scene']}" if item.get("scene") else ""
        type_label = item['type'].upper()
        score_pct = int(item.get("score", 0) * 100)

        kw = item.get("keywords", "")
        kw_display = ""
        if kw:
            kw_list = [k.strip() for k in kw.split(",") if k.strip()]
            if len(kw_list) > 6:
                kw_display = "、".join(kw_list[:6]) + f" 等{len(kw_list)}个"
            else:
                kw_display = "、".join(kw_list)

        content = item['content'].replace('\n', ' ').strip()
        per_limit = max_per if max_per else 0
        if per_limit and len(content) > per_limit:
            content = content[:max(0, per_limit - len(TRUNC_SUFFIX))].rstrip() + TRUNC_SUFFIX

        line_est = len(content) + len(kw_display) + len(item.get("activity_start", "")) + len(item.get("activity_end", "")) + len(item["id"]) + 70
        if max_total and used_chars + line_est > max_total:
            if idx == 1:
                content = content[: max(0, max_total - len(TRUNC_SUFFIX))].rstrip() + TRUNC_SUFFIX
            else:
                print(f"  ……（已达注入预算 {max_total} 字符，余 {total - idx + 1} 条省略）")
                break
        used_chars += line_est

        print(f"  {idx}. {e_emoji} {type_label}{scene_tag}{capsule_tag}{assoc_tag}{trigger_tag}  ──  {item['created_date']}  情绪{emo_val:.2f}  被检索{item['recall_count']}次  匹配{score_pct}%  🆔 {item['id']}")

        if kw_display:
            print(f"     │ 🏷️ {kw_display}")

        activity = ""
        if item.get("activity_start") or item.get("activity_end"):
            a = item.get("activity_start", "") or "?"
            b = item.get("activity_end", "") or "?"
            activity = f" (活动时间: {a} ~ {b})" if item.get("activity_start") and item.get("activity_end") else f" (活动时间: {a or b})"
        print(f"     │ 📝 {content}{activity}")

        # 层级+热度提示（heap 决策依据，供 AI 判断是否 promote/demote）
        try:
            _lm = mem_col.get(ids=[item["id"]])["metadatas"]
            if _lm and _lm[0] is not None:
                _lmd = _lm[0]
                _pid = _lmd.get("parent_id", "") or ""
                _fc = _lmd.get("first_child", "") or ""
                _rc = int(_lmd.get("recall_count", 0) or 0)
                _depth = 0
                _tmp = _pid
                for _ in range(30):
                    if not _tmp:
                        break
                    _pm = mem_col.get(ids=[_tmp])["metadatas"]
                    if not _pm or _pm[0] is None:
                        break
                    _tmp = _pm[0].get("parent_id", "") or ""
                    _depth += 1
                _role = "🌿根" if not _pid else ("🍃叶" if not _fc else "🌲枝")
                _hint = ""
                if _role != "🌿根" and _rc >= 5:
                    _hint = " 🔥热记忆沉在深层，AI 可考虑 promote 上浮"
                elif _role == "🌿根" and _rc < 2 and _fc:
                    _hint = " ❄️根节点少被检索，AI 可考虑 demote 下沉（--parent 指定新父）"
                if _role != "🌿根" or _fc or _hint:
                    print(f"     │ 🏔 层级: {_role} 深度{_depth} 检索{_rc}次{_hint}")
                # 因果链（父子即因果：父=前因，子=后果；果复为因，链式传导）
                if _pid:
                    _chain = []
                    _tmp2 = _pid
                    for _ in range(30):
                        if not _tmp2:
                            break
                        _am = mem_col.get(ids=[_tmp2])["metadatas"]
                        if not _am or _am[0] is None:
                            break
                        _al = _tree_label("", _am[0]) or _tmp2[:8]
                        _chain.append(_al)
                        _tmp2 = _am[0].get("parent_id", "") or ""
                    if _chain:
                        _crumb = " ← ".join(reversed(_chain))
                        print(f"     │ 🔺因链: {_crumb} → 本条为其果")
                if _fc:
                    print(f"     │ 🔻果: 子树非空（本条又为下游之因）→ recall 同主题 --tree 顺果链展开")
        except Exception:
            pass

        # 🔗 关联链（知识图谱，贾维斯块⑤）：手动关系 1 跳提示（双向匹配，不展开内容）
        try:
            _rels = []
            for _r, _dir in ((rel_col.get(where={"source": item["id"]}), "out"),
                             (rel_col.get(where={"target": item["id"]}), "in")):
                if not _r["ids"]:
                    continue
                for _j in range(len(_r["ids"])):
                    _rm = _r["metadatas"][_j] if _r["metadatas"] else {}
                    _partner = _rm.get("target") if _dir == "out" else _rm.get("source")
                    if not _partner:
                        continue
                    _rt = _rm.get("rel_type") or "related"
                    _rn = _rm.get("note", "") or ""
                    _rels.append((_rt, _partner, _dir, _rn, _r["ids"][_j]))
            if _rels:
                _parts = []
                for _rt, _pid, _dir, _rn, _rid in _rels[:3]:
                    _pm2 = mem_col.get(ids=[_pid])["metadatas"]
                    _pt = (_pm2[0].get("title", "") if _pm2 and _pm2[0] else "") or _pid[:8]
                    _arrow = "→" if _dir == "out" else "←"
                    _lbl = REL_TYPE_LABEL.get(_rt, _rt)
                    _parts.append(f"{_lbl}{_arrow}{_pt}" + (f"（{_rn}）" if _rn else ""))
                _more = f" 等{len(_rels)}条" if len(_rels) > 3 else ""
                print(f"     │ 🔗 关联: {' | '.join(_parts)}{_more}")
        except Exception:
            pass

        # 技能卡：type=skill 时展示结构化字段，供 AI 直接按技能执行
        if item.get("type") == "skill":
            try:
                _sm = mem_col.get(ids=[item["id"]])
                if _sm["metadatas"]:
                    _smd = _sm["metadatas"][0]
                    _sn = _smd.get("skill_name", "") or ""
                    _ss = _smd.get("skill_summary", "") or ""
                    _st = _smd.get("skill_strategy", "") or ""
                    _sa = _smd.get("skill_avoid", "") or ""
                    _tri = _smd.get("skill_triggers", "") or ""
                    _inp = _smd.get("skill_input", "") or ""
                    _out = _smd.get("skill_output", "") or ""
                    _ver = _smd.get("skill_version", "") or ""
                    _pa = _smd.get("skill_path", "") or ""
                    if _sn: print(f"     │ 🎯 技能: {_sn}" + (f" v{_ver}" if _ver else ""))
                    if _ss: print(f"     │ 📌 概括: {_ss}")
                    if _tri: print(f"     │ ⚡ 触发: {_tri}")
                    if _pa: print(f"     │ 📍 路径: {_pa}")
                    if _st: print(f"     │ 🛠 步骤: {_st}")
                    if _inp: print(f"     │ 📥 输入: {_inp}")
                    if _out: print(f"     │ 📤 输出: {_out}")
                    if _sa: print(f"     │ ⚠️ 禁忌: {_sa}")
                    print(f"     │ 🔧 遇此类任务，按此技能执行")
            except Exception:
                pass

        # 判定模式（--judge）：值必存第一段用——供 AI 判本内容与旧忆是否同主题
        if getattr(args, "judge", False):
            print(f"     │ 🔍 判定维度：相似度{score_pct}% | 类型{item['type']} | 创建{item['created_date']} | 检索{item['recall_count']}次")
            print(f"     │   判同主题？→ 是(可合并，--merge-ids 删旧存新) | 否(机械存储，--force)")
            print(f"     │   ⚡ 合并用 ID（完整，勿截断）：{item['id']}")

        # 记忆树（渐进式披露）：默认骨架（title 树）；--tree 完整（含内容摘要，--depth 控深度）
        try:
            _hm = mem_col.get(ids=[item["id"]])["metadatas"]
            if _hm and _hm[0] is not None:
                _fc = (_hm[0].get("first_child", "") or "")
                if _fc:
                    _tl, _tn = _render_tree(mem_col, item["id"], full=getattr(args, "tree", False),
                                            max_depth=getattr(args, "depth", 3) or 3)
                    if _tl:
                        print(f"     │ 🌳 {_tl[0]}（共{_tn}子节点，--tree 展开内容）")
                        for _line in _tl[1:]:
                            print(f"     │ {_line}")
        except Exception:
            pass
        print()


# ========== update ==========
def cmd_update(args):
    client = get_client()
    mem_col = get_collection(client, "memories")
    if not args.id:
        print("错误: 请提供记忆 ID (--id)"); sys.exit(1)
    try:
        old = mem_col.get(ids=[args.id])
    except Exception:
        print(f"错误: 未找到记忆 {args.id}"); sys.exit(1)
    if not old["ids"]:
        print(f"错误: 未找到记忆 {args.id}"); sys.exit(1)
    meta = old["metadatas"][0].copy() if old["metadatas"] else {}
    meta["updated_at"] = _now().isoformat()
    content = args.content if args.content is not None else old["documents"][0]
    if args.keywords is not None: meta["keywords"] = args.keywords
    if args.emotion is not None:
        emo = norm_emotion(args.emotion)
        meta["emotion"] = emo
        meta["emotion_weight"] = emo
    if args.type is not None: meta["type"] = args.type
    if args.scene is not None: meta["scene"] = args.scene
    if args.activity_start is not None: meta["activity_start"] = args.activity_start
    if args.activity_end is not None: meta["activity_end"] = args.activity_end
    if getattr(args, "status", None) is not None:
        if args.status not in TASK_STATUSES:
            print(f"错误: --status 须为 {'/'.join(TASK_STATUSES)}"); sys.exit(1)
        meta["status"] = args.status
        print(f"   任务状态 → {STATUS_EMOJI.get(args.status,'')} {args.status}")
    mem_col.update(ids=[args.id], documents=[content], metadatas=[meta])
    _append_backup(args.id, content, meta)
    print(f"记忆已更新: {args.id}")


# ========== promote / demote（heap 式上浮下沉） ==========
def _unlink_from_parent(mem_col, mem_id, parent_id):
    """把 mem_id 从父 parent_id 的子树链（first_child→next_sibling）中摘除。
    返回 True 若成功摘除。"""
    if not parent_id:
        return False
    pm = mem_col.get(ids=[parent_id])["metadatas"]
    if not pm or pm[0] is None:
        return False
    p_meta = dict(pm[0])
    fc = p_meta.get("first_child", "") or ""
    if fc == mem_id:
        # 本节点是首子：父的 first_child 指向下一个兄弟
        cm = mem_col.get(ids=[mem_id])["metadatas"]
        ns = ""
        if cm and cm[0] is not None:
            ns = (cm[0].get("next_sibling", "") or "")
        p_meta["first_child"] = ns or ""
        if not p_meta["first_child"]:
            p_meta["first_child"] = None
        mem_col.update(ids=[parent_id], metadatas=[p_meta])
        _append_backup(parent_id, None, p_meta)
        # 清本节点 next_sibling
        if cm and cm[0] is not None:
            m = dict(cm[0])
            m["next_sibling"] = None
            mem_col.update(ids=[mem_id], metadatas=[m])
            _append_backup(mem_id, None, m)
        return True
    # 非首子：沿链找前驱，改前驱 next_sibling
    cur = fc
    for _ in range(50):
        if not cur:
            return False
        cm = mem_col.get(ids=[cur])["metadatas"]
        if not cm or cm[0] is None:
            return False
        cm_meta = dict(cm[0])
        ns = cm_meta.get("next_sibling", "") or ""
        if ns == mem_id:
            mm = mem_col.get(ids=[mem_id])["metadatas"]
            nns = ""
            if mm and mm[0] is not None:
                nns = (mm[0].get("next_sibling", "") or "")
            cm_meta["next_sibling"] = nns or ""
            if not cm_meta["next_sibling"]:
                cm_meta["next_sibling"] = None
            mem_col.update(ids=[cur], metadatas=[cm_meta])
            _append_backup(cur, None, cm_meta)
            if mm and mm[0] is not None:
                m2 = dict(mm[0])
                m2["next_sibling"] = None
                mem_col.update(ids=[mem_id], metadatas=[m2])
                _append_backup(mem_id, None, m2)
            return True
        cur = ns
    return False


def _link_as_child(mem_col, mem_id, new_parent_id):
    """把 mem_id 挂到 new_parent_id 下：设父 first_child 或追加兄弟链尾。"""
    pm = mem_col.get(ids=[new_parent_id])["metadatas"]
    if not pm or pm[0] is None:
        return False
    p_meta = dict(pm[0])
    fc = p_meta.get("first_child", "") or ""
    if not fc:
        p_meta["first_child"] = mem_id
        mem_col.update(ids=[new_parent_id], metadatas=[p_meta])
        _append_backup(new_parent_id, None, p_meta)
    else:
        cur = fc
        prev = None
        for _ in range(50):
            cm = mem_col.get(ids=[cur])
            if not cm["ids"]:
                # 断链容错：cur 指向的节点不存在（历史删除遗留）
                # 若 prev 存在 → prev.next_sibling = mem_id；否则父 first_child 直接指向 mem_id
                if prev:
                    pm2 = mem_col.get(ids=[prev])["metadatas"]
                    if pm2 and pm2[0] is not None:
                        pm2m = dict(pm2[0])
                        pm2m["next_sibling"] = mem_id
                        mem_col.update(ids=[prev], metadatas=[pm2m])
                        _append_backup(prev, None, pm2m)
                else:
                    p_meta["first_child"] = mem_id
                    mem_col.update(ids=[new_parent_id], metadatas=[p_meta])
                    _append_backup(new_parent_id, None, p_meta)
                break
            cm_meta = dict(cm["metadatas"][0])
            ns = cm_meta.get("next_sibling", "") or ""
            if not ns:
                cm_meta["next_sibling"] = mem_id
                mem_col.update(ids=[cur], metadatas=[cm_meta])
                _append_backup(cur, None, cm_meta)
                break
            prev = cur
            cur = ns
    # 设本节点 parent_id（保留其原 next_sibling 语义：上浮时本节点子链随之，下沉时子链保持）
    mm = mem_col.get(ids=[mem_id])["metadatas"]
    if mm and mm[0] is not None:
        m = dict(mm[0])
        m["parent_id"] = new_parent_id
        mem_col.update(ids=[mem_id], metadatas=[m])
        _append_backup(mem_id, None, m)
    return True


def cmd_promote(args):
    """heap 上浮：mem_id 升到其父的位置（或祖父层）——摘出当前子树，挂到祖父下。"""
    client = get_client()
    mem_col = get_collection(client, "memories")
    mm = mem_col.get(ids=[args.id])["metadatas"]
    if not mm or mm[0] is None:
        print(f"错误: 未找到记忆 {args.id}"); return
    meta = dict(mm[0])
    parent_id = meta.get("parent_id", "") or ""
    if not parent_id:
        print(f"⚠️ {args.id[:12]} 已是根节点（无父），无可上浮"); return
    # 摘除：从父链中移除本节点（子链随之）
    _unlink_from_parent(mem_col, args.id, parent_id)
    # 新父 = 原父的父（祖父）
    pm = mem_col.get(ids=[parent_id])["metadatas"]
    grandparent_id = ""
    if pm and pm[0] is not None:
        grandparent_id = (pm[0].get("parent_id", "") or "")
    if grandparent_id:
        _link_as_child(mem_col, args.id, grandparent_id)
        print(f"⬆️ 因果上浮：{args.id[:12]} 升到 {grandparent_id[:12]} 子级（本条之果随之，因果层级上移一层）")
    else:
        # 原父是根：本节点成为新根
        mm2 = mem_col.get(ids=[args.id])["metadatas"]
        if mm2 and mm2[0] is not None:
            m2 = dict(mm2[0])
            m2["parent_id"] = None
            mem_col.update(ids=[args.id], metadatas=[m2])
            _append_backup(args.id, None, m2)
        print(f"⬆️ 因果上浮为根：{args.id[:12]}（原父 {parent_id[:12]} 之位由本条取代）")


def cmd_demote(args):
    """heap 下沉：mem_id 挂到 --parent 指定节点下成为其子（摘链+重挂）。"""
    client = get_client()
    mem_col = get_collection(client, "memories")
    if not args.parent:
        print("错误: 下沉需指定 --parent <目标父ID>"); return
    if args.parent == args.id:
        print("错误: 不能下沉到自身"); return
    mm = mem_col.get(ids=[args.id])["metadatas"]
    if not mm or mm[0] is None:
        print(f"错误: 未找到记忆 {args.id}"); return
    meta = dict(mm[0])
    old_parent = meta.get("parent_id", "") or ""
    # 防止环：新父不能是本节点自身子树
    if _is_descendant(mem_col, args.parent, args.id):
        print("错误: 目标父是本节点子代，会成环"); return
    if old_parent:
        _unlink_from_parent(mem_col, args.id, old_parent)
    _link_as_child(mem_col, args.id, args.parent)
    print(f"⬇️ 因果下沉：{args.id[:12]} 挂到 {args.parent[:12]} 之下成为其果（本条下游果链随之）")


def _is_descendant(mem_col, node_id, ancestor_id):
    """node_id 是否在 ancestor_id 的子树内（防环）。"""
    cur = node_id
    for _ in range(100):
        mm = mem_col.get(ids=[cur])["metadatas"]
        if not mm or mm[0] is None:
            return False
        pid = (mm[0].get("parent_id", "") or "")
        if pid == ancestor_id:
            return True
        if not pid:
            return False
        cur = pid
    return True


# ========== merge（语义合并） ==========
def cmd_merge(args):
    """语义合并：以某条记忆为锚，用向量语义（非字符串）检索出同主题高相关簇，
    供 AI 逐条人工合并。dry-run 预览 → --content+--apply 真正合并删旧。

    设计（2026-08-22 立）：合并必须靠语义而非字符串。autostore 去重仅在
    相似度≥90% 机械拼接(旧。新)，措辞稍异即分家，多日累积同主题多条且矛盾。
    故合并步骤：
      1) merge --id <主ID>         预览语义相近簇（不走字符串，走向量语义）
      2) AI 逐条读簇内原文，Judge矛盾、写权威合并版
      3) merge --id <主ID> --content "权威版" --apply   覆盖主ID并删除簇内其余
    """
    client = get_client()
    mem_col = get_collection(client, "memories")
    anchor = args.id
    threshold = args.threshold if args.threshold is not None else 0.70

    # 取锚记忆原文
    try:
        old = mem_col.get(ids=[anchor])
    except Exception:
        print(f"错误: 未找到记忆 {anchor}")
        raise SystemExit(1)
    if not old["ids"]:
        print(f"错误: 未找到记忆 {anchor}")
        raise SystemExit(1)
    anchor_content = old["documents"][0]
    anchor_meta = old["metadatas"][0] if old["metadatas"] else {}

    # ── 语义检索相似簇（向量路，不用字符串） ──
    similar_ids = []
    usable_embed = True
    try:
        vq = mem_col.query(query_texts=[anchor_content], n_results=40)
        # 每个候选的记忆也许与锚文案本身相似；再二次核对语义，
        # 这里 threshold 由调用方定，通常远低于 autostore 的 0.90
    except Exception as e:
        usable_embed = False
        vq = {"ids": [], "distances": []}
        print(f"⚠️ 向量检索不可用: {e}")

    if usable_embed:
        ids_list = vq.get("ids", [])
        dis_list = vq.get("distances", [])
        others = []
        if ids_list and ids_list[0]:
            for i in range(len(ids_list[0])):
                mid = ids_list[0][i]
                if mid == anchor:
                    continue
                dist = dis_list[0][i] if dis_list and dis_list[0] else 1.0
                sem = 1.0 - dist
                others.append((mid, sem))
        for mid, sem in others:
            if sem >= threshold:
                similar_ids.append((mid, sem))

    # 可选：关键词补充过滤（严格子串，仅限 keywords 字段；secondary）
    if args.keyword and similar_ids:
        kw = args.keyword.lower()
        kept = []
        for mid, sem in similar_ids:
            try:
                g = mem_col.get(ids=[mid])
                meta = g["metadatas"][0] if g["metadatas"] else {}
                mkw = (meta.get("keywords", "") or "").lower()
            except Exception:
                mkw = ""
            if kw in mkw:
                kept.append((mid, sem))
        similar_ids = kept

    if not similar_ids:
        if not args.apply:
            print(f"未发现与 {anchor[:12]} 语义相似度 ≥ {threshold} 的记忆簇")
        else:
            print(f"无待删记忆，直接写入权威合并版到 {anchor[:12]}")
            merged_content = args.content or anchor_content
            _do_merge_write(mem_col, anchor, merged_content, anchor_meta, args)
        return

    similar_ids.sort(key=lambda x: -x[1])

    if not args.apply:
        # 预览
        print(f"🔍 语义合并预览 —— 锚 {anchor[:12]} 语义相似度 ≥ {threshold} 的记忆簇：")
        for mid, sem in similar_ids[:20]:
            try:
                g = mem_col.get(ids=[mid])
                tc = (g["documents"][0] or "") if g["documents"] else ""
                kw = (g["metadatas"][0].get("keywords", "") or "") if g["metadatas"] else ""
            except Exception:
                tc, kw = "", ""
            print(f"  {sem:.0%}  {mid[:12]} | {(kw or '')[:36]} | {tc[:34]}")
        print(f"\n共 {len(similar_ids)} 条待合并。")
        print("确认合并：加 --content \"AI 手写权威合并版\" --apply")
        return

    # ---- apply：写入权威合并版并删除簇内其余 ----
    if not args.content:
        print("错误: --apply 须提供 --content（AI 手写权威合并版），否则不合并")
        raise SystemExit(1)

    merged_content = args.content
    for mid, sem in similar_ids:
        try:
            mem_col.delete(ids=[mid])
            print(f"  ✗ 已删 {mid[:12]}（相似 {sem:.0%}）")
        except Exception:
            pass
    _do_merge_write(mem_col, anchor, merged_content, anchor_meta, args)
    merged = len(similar_ids) + 1
    print(f"✅ 语义合并完成：{merged} 条并入的权威版存于 {anchor[:12]}")


def _do_merge_write(mem_col, mid, content, meta, args):
    """写权威合并版到锚 ID，保留/增强元数据。"""
    nm = dict(meta) if meta else {}
    nm["content"] = content
    nm["updated_at"] = _now().isoformat()
    if args.keywords:
        nm["keywords"] = _merge_keywords(meta.get("keywords", ""), args.keywords)
    if args.emotion is not None:
        emo = norm_emotion(args.emotion)
        nm["emotion"] = emo
        nm["emotion_weight"] = emo
    if args.type:
        nm["type"] = args.type
    # consolidated 标签，标示此为合并产物
    kw = nm.get("keywords", "") or ""
    if "consolidated" not in kw:
        nm["keywords"] = (kw + ",consolidated").strip(",")
    mem_col.update(ids=[mid], documents=[content], metadatas=[nm])
    _append_backup(mid, content, nm)
    print(f"  ✓ 权威合并版已写 {mid[:12]}")


# ========== delete ==========
def cmd_delete(args):
    client = get_client()
    mem_col = get_collection(client, "memories")
    if not args.id:
        print("错误: 请提供记忆 ID (--id)"); sys.exit(1)
    try:
        old = mem_col.get(ids=[args.id])
    except Exception:
        print(f"错误: 未找到记忆 {args.id}"); sys.exit(1)
    if not old["ids"]:
        print(f"错误: 未找到记忆 {args.id}"); sys.exit(1)
    mem_col.delete(ids=[args.id])
    _update_meta_total(client, "total_memories", -1)
    print(f"记忆已删除: {args.id}")


# ========== link / unlink（知识图谱：手动关系，贾维斯块⑤） ==========
# relationships 集合双用：store 时自动语义关联（score=语义值）+ 手动关系（manual=true）。
# 关系类型：causes（因果）/ references（引用）/ contradicts（矛盾）/ extends（延伸）。
# 查询双向匹配（source 或 target），存一条即双向可见。
REL_TYPES = ("causes", "references", "contradicts", "extends")
REL_TYPE_LABEL = {"causes": "⚡因果", "references": "📎引用", "contradicts": "⚔️矛盾", "extends": "🌱延伸"}


def cmd_link(args):
    client = get_client()
    mem_col = get_collection(client, "memories")
    rel_col = get_collection(client, "relationships")
    src, dst = args.source, args.target
    for nid, label in ((src, "--source"), (dst, "--target")):
        if not nid:
            print(f"错误: 请提供 {label}"); sys.exit(1)
        if not mem_col.get(ids=[nid])["ids"]:
            print(f"错误: {label} 记忆不存在: {nid}"); sys.exit(1)
    if src == dst:
        print("错误: 不能链接记忆自身"); sys.exit(1)
    if args.rel_type not in REL_TYPES:
        print(f"错误: 关系类型须为 {'/'.join(REL_TYPES)}"); sys.exit(1)
    rel_col.add(
        documents=[f"{src}-{args.rel_type}->{dst}"],
        metadatas=[{"source": src, "target": dst, "rel_type": args.rel_type,
                    "note": args.note or "", "score": 1.0, "manual": "true",
                    "created_at": _now().isoformat()}],
        ids=[str(uuid.uuid4())],
    )
    _update_meta_total(client, "total_relationships", 1)
    tag = REL_TYPE_LABEL[args.rel_type]
    print(f"🔗 已建立关系 [{tag}]: {src[:8]}… → {dst[:8]}…")
    if args.note:
        print(f"   注: {args.note}")
    print("   recall 时命中任一端即显示此关联（1 跳提示）")


def cmd_unlink(args):
    client = get_client()
    rel_col = get_collection(client, "relationships")
    removed = 0
    if args.rel_id:
        got = rel_col.get(ids=[args.rel_id])
        if not got["ids"]:
            print(f"错误: 关系不存在: {args.rel_id}"); sys.exit(1)
        rel_col.delete(ids=[args.rel_id]); removed = 1
    else:
        conds = []
        if args.source: conds.append({"source": args.source})
        if args.target: conds.append({"target": args.target})
        if args.rel_type: conds.append({"rel_type": args.rel_type})
        if not conds:
            print("错误: 请提供 --rel-id 或 --source/--target/--rel-type 之组合"); sys.exit(1)
        where = {"$and": conds} if len(conds) > 1 else conds[0]
        got = rel_col.get(where=where)
        if not got["ids"]:
            print("无匹配关系"); return
        rel_col.delete(ids=got["ids"]); removed = len(got["ids"])
    _update_meta_total(client, "total_relationships", -removed)
    print(f"🔗 已删 {removed} 条关系")


# ========== resume（会话桥接：存档/恢复，贾维斯块③） ==========
# 会话存档 type=session；任务状态 metadata.status ∈ pending/in_progress/done/blocked。
# 会话结束时 AI 调 resume --save "总结"；新会话始 AI 调 resume 拉上次存档+未完成任务。
TASK_STATUSES = ("pending", "in_progress", "done", "blocked")
STATUS_EMOJI = {"pending": "🕐", "in_progress": "🔄", "done": "✅", "blocked": "⛔"}


def cmd_resume(args):
    client = get_client()
    mem_col = get_collection(client, "memories")
    now = _now()

    if getattr(args, "save", None):
        sid = str(uuid.uuid4())
        meta = {
            "type": "session", "emotion": 0.3, "emotion_weight": 0.3,
            "title": (args.title or f"会话存档 {now.strftime('%m-%d %H:%M')}"),
            "created_at": now.isoformat(), "created_date": now.strftime("%Y-%m-%d"),
            "updated_at": now.isoformat(),
            "keywords": args.keywords or "会话存档,session",
            "source": args.source or "resume", "source_session": args.session or "",
            "frequency": 1, "recall_count": 0,
        }
        mem_col.add(documents=[args.save], metadatas=[meta], ids=[sid])
        _append_backup(sid, args.save, meta)
        print(f"📂 会话存档已存: {sid}")
        print(f"   {meta['title']}")
        return

    # ── 恢复模式：上次存档 + 未完成任务 ──
    print(f"📂 会话恢复 ── {now.strftime('%Y-%m-%d %H:%M')}")
    # 1. 最近会话存档（type=session，最新在前）
    try:
        arcs = mem_col.get(where={"type": "session"})
        want = min(args.limit or 1, 5)
        if arcs["ids"]:
            rows = []
            for i, aid in enumerate(arcs["ids"]):
                am = arcs["metadatas"][i] if arcs["metadatas"] else {}
                rows.append((am.get("created_at", ""), aid,
                             arcs["documents"][i] if arcs["documents"] else "",
                             am))
            rows.sort(reverse=True)
            print(f"\n  ▸ 上次会话存档（{min(want, len(rows))} 条，新→旧）")
            for ca, aid, doc, am in rows[:want]:
                print(f"  ── {am.get('created_date','')} {am.get('title','')}  🆔 {aid}")
                print(f"     📝 {doc}")
        else:
            print("\n  ▸ 无会话存档（首次会话或从未 --save）")
    except Exception as e:
        print(f"  ⚠️ 存档读取失败: {e}")

    # 2. 未完成任务（type=task 且 status ∉ done）
    try:
        tasks = mem_col.get(where={"type": "task"})
        open_rows = []
        for i, tid in enumerate(tasks["ids"]):
            tm = tasks["metadatas"][i] if tasks["metadatas"] else {}
            st = tm.get("status", "pending")
            if st == "done":
                continue
            doc = (tasks["documents"][i] if tasks["documents"] else "")[:120]
            open_rows.append((tm.get("created_at", ""), st, tid, doc,
                              tm.get("title", "")))
        if open_rows:
            order = {"blocked": 0, "in_progress": 1, "pending": 2}
            open_rows.sort(key=lambda r: (order.get(r[1], 3), r[0]))
            print(f"\n  ▸ 未完成任务（{len(open_rows)} 条，blocked→in_progress→pending）")
            for ca, st, tid, doc, title in open_rows[:10]:
                print(f"  {STATUS_EMOJI.get(st,'•')} [{st}] {(title or doc)[:60]}  🆔 {tid}")
            if len(open_rows) > 10:
                print(f"  ……余 {len(open_rows) - 10} 条省略")
            print(f"  ⚙️ 进展用 update --status 更新")
        else:
            print("\n  ▸ 无未完成任务")
    except Exception as e:
        print(f"  ⚠️ 任务读取失败: {e}")


# ========== stats ==========
def cmd_stats(args):
    client = get_client()
    mem_col = get_collection(client, "memories")
    rel_col = get_collection(client, "relationships")
    total = mem_col.count()
    print(f"忆时 · 记忆统计")
    print(f"{'='*40}")
    print(f"  总记忆数: {total}")
    print(f"  关系数量: {rel_col.count()}")
    if total == 0: return
    type_counts = {}; emo_buckets = {"高(≥0.7)": 0, "中(0.4~0.7)": 0, "低(<0.4)": 0}; capsule_count = 0
    result = mem_col.get()
    if result["metadatas"]:
        for m in result["metadatas"]:
            t = m.get("type", "context"); type_counts[t] = type_counts.get(t, 0) + 1
            w = norm_emotion(m.get("emotion"))
            if w >= 0.7: emo_buckets["高(≥0.7)"] += 1
            elif w >= 0.4: emo_buckets["中(0.4~0.7)"] += 1
            else: emo_buckets["低(<0.4)"] += 1
            if m.get("is_capsule") == "true": capsule_count += 1
    print(f"\n  按类型:")
    for t, c in sorted(type_counts.items()): print(f"    {t}: {c}")
    print(f"\n  按情绪强度(数值):")
    for e, c in emo_buckets.items(): print(f"    {e}: {c}")
    print(f"\n  时间胶囊: {capsule_count}")


# ========== capsule ==========
def cmd_capsule(args):
    action = args.capsule_action
    client = get_client()
    mem_col = get_collection(client, "memories")

    if action == "lock":
        now = _now()
        unlock_at = args.unlock_at or (now + timedelta(days=30)).strftime("%Y-%m-%d")
        metadata = {
            "type": "context", "emotion": 0.5,
            "created_at": now.isoformat(), "created_date": now.strftime("%Y-%m-%d"),
            "updated_at": now.isoformat(), "keywords": args.keywords or "",
            "frequency": 1, "recall_count": 0,
            "is_capsule": "true", "capsule_unlock_at": unlock_at,
        }
        cid = str(uuid.uuid4())
        content = args.content or f"时间胶囊 - 创建于 {now.strftime('%Y-%m-%d')}, 解锁日期: {unlock_at}"
        mem_col.add(documents=[content], metadatas=[metadata], ids=[cid])
        _update_meta_total(client, "total_capsules", 1)
        print(f"时间胶囊已封存")
        print(f"  ID: {cid}")
        print(f"  创建日期: {now.strftime('%Y-%m-%d')}")
        print(f"  解锁日期: {unlock_at}")
        if args.summary: print(f"  摘要: {args.summary}")

    elif action == "unseal":
        if not args.capsule_id:
            print("错误: 请提供胶囊 ID (--capsule-id)"); sys.exit(1)
        try:
            old = mem_col.get(ids=[args.capsule_id])
        except Exception:
            print(f"错误: 未找到胶囊 {args.capsule_id}"); sys.exit(1)
        if not old["ids"]:
            print(f"错误: 未找到胶囊 {args.capsule_id}"); sys.exit(1)
        meta = old["metadatas"][0]
        if meta.get("is_capsule") != "true":
            print("错误: 该记忆不是时间胶囊"); sys.exit(1)
        unlock_at = datetime.fromisoformat(meta["capsule_unlock_at"])
        now = _now()
        if now < unlock_at:
            resp = input(f"警告: 胶囊尚未到期 (解锁: {unlock_at.strftime('%Y-%m-%d')}), 继续? [yes]: ").strip().lower()
            if resp != "yes": print("已取消"); return
        meta["is_capsule"] = "false"
        meta["updated_at"] = now.isoformat()
        mem_col.update(ids=[args.capsule_id], metadatas=[meta])
        print(f"时间胶囊已解封!")
        print(f"  内容: {old['documents'][0]}")
        print(f"  封存: {meta.get('created_date', '')} -> 解锁: {unlock_at.strftime('%Y-%m-%d')}")

    elif action == "list":
        result = mem_col.get()
        capsules = []
        if result["metadatas"]:
            for i, m in enumerate(result["metadatas"]):
                if m.get("is_capsule") == "true":
                    capsules.append({
                        "id": result["ids"][i], "created": m.get("created_date", ""),
                        "unlock_at": m.get("capsule_unlock_at", ""),
                        "content": result["documents"][i] if result["documents"] else "",
                        "keywords": m.get("keywords", ""),
                    })
        if not capsules:
            print("没有封存的时间胶囊"); return
        print(f"时间胶囊 ({len(capsules)} 个)\n{'='*60}")
        now = _now()
        for c in capsules:
            unlock = datetime.fromisoformat(c["unlock_at"])
            status = "已到期" if now >= unlock else f"剩余 {(unlock - now).days} 天"
            print(f"  ID: {c['id']}")
            print(f"  创建: {c['created']} | 解锁: {c['unlock_at']} | 状态: {status}")
            print(f"  内容: {c['content']}")
            if c["keywords"]: print(f"  关键字: {c['keywords']}")
            print()

    elif action == "check-expired":
        result = mem_col.get()
        expired = []; now = _now()
        if result["metadatas"]:
            for i, m in enumerate(result["metadatas"]):
                if m.get("is_capsule") == "true":
                    unlock = datetime.fromisoformat(m["capsule_unlock_at"])
                    if now >= unlock:
                        expired.append({
                            "id": result["ids"][i], "unlock_at": m["capsule_unlock_at"],
                            "content": result["documents"][i] if result["documents"] else "",
                            "created": m.get("created_date", ""),
                        })
        if not expired:
            print("没有到期的时间胶囊"); return
        print(f"发现 {len(expired)} 个已到期的时间胶囊!\n{'='*60}")
        for e in expired:
            print(f"  ID: {e['id']}")
            print(f"  封存: {e['created']}, 解锁: {e['unlock_at']}")
            print(f"  内容: {e['content']}")
            print()


# ========== import ==========
def _parse_markdown(text):
    entries = []
    current = {"content": "", "date": "", "emotion": 0.5, "keywords": ""}
    for line in text.split("\n"):
        line = line.strip()
        if line.startswith("#"):
            if current["content"]: entries.append(dict(current))
            current = {"content": line.lstrip("#"), "date": "", "emotion": 0.5, "keywords": ""}
            try:
                datetime.strptime(line.lstrip("#").strip()[:10], "%Y-%m-%d")
                current["date"] = line.lstrip("#").strip()[:10]
            except (ValueError, IndexError): pass
        elif line.startswith(">"):
            ml = line[1:].strip()
            emo_m = re.search(r"情绪[:：]\s*([0-9.]+|[A-Za-z]+)", ml)
            if emo_m:
                current["emotion"] = norm_emotion(emo_m.group(1))
        elif line:
            current["content"] = (current["content"] + "\n" + line).strip() if current["content"] else line
    if current["content"]: entries.append(dict(current))
    return entries


def _parse_text(text):
    entries = []
    for block in text.split("\n\n"):
        block = block.strip()
        if not block: continue
        lines = block.split("\n"); date = ""; content = block
        try:
            datetime.strptime(lines[0][:10], "%Y-%m-%d")
            date = lines[0][:10]; content = "\n".join(lines[1:]) if len(lines) > 1 else block
        except (ValueError, IndexError): pass
        entries.append({"content": content, "date": date, "emotion": 0.5, "keywords": ""})
    return entries


def cmd_import(args):
    client = get_client()
    mem_col = get_collection(client, "memories")
    fmt = args.format

    if not os.path.exists(args.filepath):
        print(f"错误: 文件不存在: {args.filepath}")
        sys.exit(1)

    if fmt == "json":
        with open(args.filepath, "r", encoding="utf-8") as f:
            data = json.load(f)
        memories = data if isinstance(data, list) else data.get("memories", [data])
        count = 0
        for mem in memories:
            content = mem.get("content", mem.get("text", ""))
            if not content.strip(): continue
            metadata = {
                "type": mem.get("type", "imported"),
                "emotion": norm_emotion(mem.get("emotion")),
                "emotion_weight": norm_emotion(mem.get("emotion")),
                "title": mem.get("title") or make_title(content),
                "created_at": mem.get("created_at", _now().isoformat()),
                "created_date": mem.get("created_date", ""),
                "updated_at": _now().isoformat(),
                "keywords": mem.get("keywords", ""),
                "frequency": 1, "recall_count": 0,
            }
            mid = mem.get("id", str(uuid.uuid4()))
            try:
                mem_col.add(documents=[content], metadatas=[metadata], ids=[mid])
            except Exception:
                mem_col.add(documents=[content], metadatas=[metadata], ids=[str(uuid.uuid4())])
            count += 1
        print(f"已从 JSON 导入 {count} 条记忆")
        return

    with open(args.filepath, "r", encoding="utf-8") as f:
        content = f.read()
    entries = _parse_markdown(content) if fmt == "markdown" else _parse_text(content)
    count = 0
    for entry in entries:
        emo = norm_emotion(entry.get("emotion"))
        metadata = {
            "type": "imported", "emotion": emo,
            "emotion_weight": emo,
            "title": entry.get("title") or make_title(entry.get("content", "")),
            "created_at": entry.get("date", _now().isoformat()),
            "created_date": entry.get("date", "")[:10],
            "updated_at": _now().isoformat(),
            "keywords": entry.get("keywords", ""),
            "source": f"imported_{fmt}",
            "frequency": 1, "recall_count": 0,
        }
        mem_col.add(documents=[entry["content"]], metadatas=[metadata], ids=[str(uuid.uuid4())])
        count += 1
    print(f"已从 {fmt} 导入 {count} 条记忆")


# ========== export ==========
def cmd_export(args):
    client = get_client()
    mem_col = get_collection(client, "memories")
    result = mem_col.get()
    if not result["ids"]:
        print("没有可导出的记忆"); return

    out_dir = os.path.dirname(os.path.abspath(args.output))
    if not os.path.isdir(out_dir):
        print(f"错误: 输出目录不存在: {out_dir}")
        sys.exit(1)

    memories = []
    for i in range(len(result["ids"])):
        meta = result["metadatas"][i] if result["metadatas"] else {}
        memories.append({
            "id": result["ids"][i],
            "content": result["documents"][i] if result["documents"] else "",
            "metadata": meta,
        })
    memories.sort(key=lambda m: m["metadata"].get("created_at", ""))

    if args.format == "json":
        data = {"version": "1.0.0", "export_date": _now().isoformat(), "total": len(memories), "memories": memories}
        with open(args.output, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
        print(f"已导出 {len(memories)} 条记忆到 JSON: {args.output}")
        return

    if args.format == "timeline":
        lines = [f"# 忆时 · 记忆时间线", f"导出日期: {_now().strftime('%Y-%m-%d %H:%M:%S')}", f"总记忆数: {len(memories)}", ""]
        current_date = None
        for m in memories:
            ds = m["metadata"].get("created_date", "")[:10]
            meta = m["metadata"]; mt = meta.get("type", "context")
            ee = emotion_emoji(meta.get("emotion"))
            if ds != current_date:
                current_date = ds; lines.append(f"## {ds}"); lines.append("")
            ct = " 🔒" if meta.get("is_capsule") == "true" else ""
            lines.append(f"### {ee} [{mt.upper()}]{ct}")
            lines.append(f"- 关键字: {meta.get('keywords', '无')}")
            lines.append(f"- 情绪: {norm_emotion(meta.get('emotion')):.2f}")
            lines.append(f"- {m['content']}")
            lines.append("")
        with open(args.output, "w", encoding="utf-8") as f:
            f.write("\n".join(lines))
        print(f"已导出 {len(memories)} 条记忆到时间线: {args.output}")
        return

    lines = ["# 忆时 · 记忆导出", f"导出日期: {_now().strftime('%Y-%m-%d %H:%M:%S')}", f"总记忆数: {len(memories)}", ""]
    for m in memories:
        meta = m["metadata"]; mt = meta.get("type", "context")
        lines.append("---")
        lines.append(f"**类型**: {mt}  |  **情绪**: {norm_emotion(meta.get('emotion')):.2f}  |  **日期**: {meta.get('created_date', '')}")
        if meta.get("keywords"): lines.append(f"**关键字**: {meta['keywords']}")
        lines.append(""); lines.append(m["content"]); lines.append("")
    with open(args.output, "w", encoding="utf-8") as f:
        f.write("\n".join(lines))
    print(f"已导出 {len(memories)} 条记忆到 Markdown: {args.output}")


# ========== forget ==========
def cmd_forget(args):
    client = get_client()
    mem_col = get_collection(client, "memories")
    result = mem_col.get()
    if not result["ids"]:
        print("没有记忆可处理"); return
    now = _now(); candidates = []
    for i in range(len(result["ids"])):
        meta = result["metadatas"][i] if result["metadatas"] else {}
        try: created = datetime.fromisoformat(meta.get("created_at", now.isoformat()))
        except (ValueError, TypeError): continue
        if args.before and created >= datetime.fromisoformat(args.before): continue
        if args.low_freq is not None and (int(meta.get("frequency", 1)) > args.low_freq or int(meta.get("recall_count", 0)) > args.low_freq): continue
        candidates.append({"id": result["ids"][i], "date": created.strftime("%Y-%m-%d"), "meta": meta})
    if not candidates:
        print("没有符合条件的记忆"); return
    print(f"发现 {len(candidates)} 条可处理记忆:")
    for c in candidates: print(f"  {c['id']} (创建: {c['date']})")
    if args.auto:
        for c in candidates:
            m = dict(c["meta"]); m["archived"] = "true"; m["updated_at"] = now.isoformat()
            mem_col.update(ids=[c["id"]], metadatas=[m])
        print(f"\n已将 {len(candidates)} 条记忆标记为已归档")
    else:
        print("\n使用 --auto 自动标记归档")


# ========== recover ==========
def cmd_recover(args):
    """从备份文件恢复所有记忆到 ChromaDB。"""
    records = _load_backups()
    if not records:
        print(f"未找到备份文件: {BACKUP_FILE}")
        print("尚无自动备份，若曾用 export 导出过 JSON，可用 import-file 恢复。")
        return

    client = get_client()
    mem_col = get_collection(client, "memories")
    meta_col = get_collection(client, "meta")
    now = _now()
    restored = 0

    # 同 id 多条时取最后版本（合并/更新会追加同 id 记录）
    latest = {}
    for rec in records:
        mid = rec.get("id")
        if mid:
            latest[mid] = rec
    for mid, rec in latest.items():
        content = rec.get("content", "")
        meta = rec.get("metadata", {})
        # 确保元数据字段完整
        meta.setdefault("frequency", 1)
        meta.setdefault("recall_count", 0)
        meta.setdefault("updated_at", now.isoformat())
        # 跳过已存在的（按 id 去重）
        try:
            existing = mem_col.get(ids=[mid])
            if existing["ids"]:
                continue
        except Exception:
            pass
        try:
            mem_col.add(documents=[content], metadatas=[meta], ids=[mid])
            restored += 1
        except Exception as e:
            print(f"  ⚠️ 恢复失败 ({mid}): {e}", file=sys.stderr)

    # 更新 meta 统计
    total = mem_col.count()
    try:
        if meta_col.count() > 0:
            s = json.loads(meta_col.get(ids=["state"])["documents"][0])
            s["total_memories"] = total
            s["updated_at"] = now.isoformat()
            meta_col.update(documents=[json.dumps(s)], ids=["state"], metadatas=[{"key": "state"}])
    except Exception:
        pass

    print(f"恢复完成: 备份 {len(records)} 条, 恢复 {restored} 条")
    print(f"  当前记忆总数: {total}")
    print(f"  备份文件: {BACKUP_FILE}")
    if restored < len(records):
        print(f"  跳过 {len(records) - restored} 条（已存在）")


# ========== 远程调用（Local/Remote 双模式客户端） ==========
def _remote_argv(argv):
    """把 argv 转发到远程 YISHI_ADDR 的 /run 端点。返回 (exit_code, text) 或 None。"""
    addr = os.environ.get("YISHI_ADDR", "").strip().rstrip("/")
    token = os.environ.get("YISHI_TOKEN", os.environ.get("YISHI_SERVE_TOKEN", ""))
    if not addr:
        return None
    import urllib.request
    import urllib.error
    req = urllib.request.Request(
        f"{addr}/run",
        data=json.dumps({"argv": argv}).encode(),
        headers={"Content-Type": "application/json", **({"Authorization": f"Bearer {token}"} if token else {})},
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=120) as resp:
            body = json.loads(resp.read().decode())
            return (body.get("code", 0), body.get("text", ""))
    except urllib.error.HTTPError as e:
        try:
            err = json.loads(e.read().decode())
        except Exception:
            err = {"error": str(e)}
        return (e.code, str(err))
    except Exception as e:
        return (1, str(e))


# ========== serve（HTTP 服务器，多客户端共享） ==========
def cmd_serve(args):
    if not _HAS_HTTP:
        print("错误: 当前 Python 无 http.server 模块，无法 serve", file=sys.stderr)
        sys.exit(1)
    token = args.token or os.environ.get("YISHI_SERVE_TOKEN", "")
    if not token:
        print("错误: serve 需 --token 或设 YISHI_SERVE_TOKEN", file=sys.stderr)
        sys.exit(1)
    host_port = args.bind.rsplit(":", 1)
    host, port = host_port[0], int(host_port[1])

    # 预打开数据库，验证可用
    try:
        get_client()
    except Exception as e:
        print(f"错误: 打开记忆库失败: {e}", file=sys.stderr)
        sys.exit(1)

    class YishiHandler(BaseHTTPRequestHandler):
        def _auth(self):
            auth = self.headers.get("Authorization", "")
            if not auth.startswith("Bearer "):
                self._json(401, {"error": "unauthorized: missing Bearer token"})
                return False
            got = auth[7:]
            # 常数时间比较
            if len(got) != len(token):
                self._json(401, {"error": "unauthorized: token rejected"})
                return False
            diff = 0
            for a, b in zip(got.encode(), token.encode()):
                diff |= a ^ b
            if diff:
                self._json(401, {"error": "unauthorized: token rejected"})
                return False
            return True

        def _json(self, code, obj):
            data = json.dumps(obj, ensure_ascii=False).encode()
            self.send_response(code)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Content-Length", str(len(data)))
            self.end_headers()
            self.wfile.write(data)

        def _run(self, argv):
            """在进程内执行 argv，捕获 stdout。"""
            old_stdout, old_stderr = sys.stdout, sys.stderr
            buf = StringIO()
            sys.stdout = buf
            sys.stderr = buf
            code = 0
            try:
                _dispatch_with_lock(argv, skip_lock=True)
            except SystemExit as e:
                code = e.code if e.code is not None else 0
            except Exception as e:
                buf.write(f"错误: {e}\n")
                code = 1
            finally:
                sys.stdout = old_stdout
                sys.stderr = old_stderr
            return code, buf.getvalue()

        def do_GET(self):
            if not self._auth():
                return
            parsed = urlparse(self.path)
            path = parsed.path
            if path == "/health":
                return self._json(200, {"ok": True, "service": "yishi-memory", "version": "0.4.25"})
            if path == "/recall":
                qs = parse_qs(parsed.query)
                query = (qs.get("q") or [""])[0]
                limit = int((qs.get("limit") or ["5"])[0])
                code, text = self._run(["recall", query, "--limit", str(limit)])
                return self._json(200, {"code": code, "text": text})
            self._json(404, {"error": f"not found: {path}"})

        def do_POST(self):
            if not self._auth():
                return
            parsed = urlparse(self.path)
            path = parsed.path
            length = int(self.headers.get("Content-Length") or 0)
            raw = self.rfile.read(length) if length else b""
            try:
                body = json.loads(raw.decode()) if raw else {}
            except Exception:
                body = {}
            if path == "/run":
                argv = body.get("argv", [])
                if isinstance(argv, list) and argv:
                    code, text = self._run(argv)
                    return self._json(200, {"code": code, "text": text})
                return self._json(400, {"error": "argv required"})
            if path == "/remember":
                content = body.get("content", "")
                if not content:
                    return self._json(400, {"error": "content required"})
                argv = ["store", content, "--force"]
                t = body.get("type")
                if t:
                    argv += ["--type", str(t)]
                kw = body.get("tags") or body.get("keywords")
                if kw:
                    argv += ["--keywords", str(kw)]
                em = body.get("emotion")
                if em is not None:
                    argv += ["--emotion", str(em)]
                code, text = self._run(argv)
                return self._json(200, {"code": code, "text": text})
            if path == "/forget":
                mid = body.get("id", "")
                if not mid:
                    return self._json(400, {"error": "id required"})
                code, text = self._run(["delete", "--id", str(mid)])
                return self._json(200, {"code": code, "text": text})
            self._json(404, {"error": f"not found: {path}"})

        def log_message(self, fmt, *args):
            pass

    try:
        server = HTTPServer((host, port), YishiHandler)
    except OSError as e:
        print(f"错误: 无法绑定 {args.bind}: {e}", file=sys.stderr)
        sys.exit(1)
    print(f"🟢 忆时 serve 启动: http://{args.bind}", file=sys.stderr)
    print(f"🔑 token: {token[:4]}…{token[-2:]}（同 YISHI_TOKEN 用于本地 CLI 远程模式）", file=sys.stderr)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\n🛑 已停止", file=sys.stderr)
        server.server_close()


def _dispatch_with_lock(argv, skip_lock=False):
    """带进程锁的本地执行（与 main 尾部一致），供 serve 复用。
    skip_lock=True：serve 内部调用，不重复加锁。"""
    lock_fd = None
    if not skip_lock:
        try:
            import fcntl
            os.makedirs(DATA_DIR, exist_ok=True)
            lock_path = os.path.join(DATA_DIR, ".memory.lock")
            lock_fd = os.open(lock_path, os.O_CREAT | os.O_RDWR, 0o644)
            waited = 0
            while True:
                try:
                    fcntl.flock(lock_fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
                    break
                except OSError:
                    if waited >= 8:
                        print("⚠️ 另一忆时进程正在操作（并发写锁），请稍后再试", file=sys.stderr)
                        os.close(lock_fd)
                        sys.exit(1)
                    time.sleep(0.2)
                    waited += 0.2
        except ImportError:
            pass
    try:
        parser = _build_parser()
        args = parser.parse_args(argv)
        if args.command:
            args.func(args)
    finally:
        if lock_fd is not None:
            try:
                import fcntl
                fcntl.flock(lock_fd, fcntl.LOCK_UN)
            except Exception:
                pass
            os.close(lock_fd)


def _build_parser():
    """构建完整参数解析器（供 main 与 serve 复用）。"""
    parser = argparse.ArgumentParser(description="忆时 Memory Core", formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = parser.add_subparsers(dest="command")

    p = sub.add_parser("init"); p.set_defaults(func=cmd_init)

    p = sub.add_parser("store", help="存储新记忆")
    p.add_argument("content", help="记忆内容")
    p.add_argument("--title", help="简洁标题（≤10 字，默认自动从内容首段生成）")
    p.add_argument("--type", choices=VALID_TYPES, help="记忆类型")
    p.add_argument("--emotion", help="情绪强度（0.0~1.0 数值，如 0.9；兼容旧词 high/medium/low）")
    p.add_argument("--keywords", help="关键字")
    p.add_argument("--source", help="来源"); p.add_argument("--session", help="会话ID")
    p.add_argument("--scene", help="场景（如: 教学课后反馈）")
    p.add_argument("--activity-start", help="活动开始时间（如 2025-05-01）")
    p.add_argument("--activity-end", help="活动结束时间（如 2025-05-10）")
    p.add_argument("--force", action="store_true", help="跳过去重合并，强制新增")
    p.add_argument("--merge-ids", help="AI 有机合并：删指定记忆ID(逗号分隔)，本内容(综合合并版)存为新条目")
    p.add_argument("--status", default=None, choices=list(TASK_STATUSES),
                   help="任务状态（task 用）：pending/in_progress/done/blocked，task 默认 pending")
    p.add_argument("--skill-name", help="技能名称")
    p.add_argument("--skill-summary", help="技能一句话概括")
    p.add_argument("--skill-strategy", help="技能策略/步骤")
    p.add_argument("--skill-avoid", help="技能禁忌/注意事项")
    p.add_argument("--skill-triggers", help="技能触发关键词")
    p.add_argument("--skill-input", help="技能输入")
    p.add_argument("--skill-output", help="技能输出")
    p.add_argument("--skill-version", default="1.0.0", help="技能版本")
    p.add_argument("--skill-path", help="技能可执行路径/调用方式（如 python3 /path/to/tool，缺此 AI 无法定位工具）")
    p.add_argument("--parent", help="链式前向星挂载：父节点 ID，本节点挂到父的子树链（first_child/next_sibling）")
    p.set_defaults(func=cmd_store)

    p = sub.add_parser("recall", help="检索记忆")
    p.add_argument("query", help="查询内容")
    p.add_argument("--limit", type=int, default=3, help="返回数量（默认3，最相关三条）")
    p.add_argument("--mode", choices=["all", "recent", "emotion", "semantic"], help="检索模式")
    p.add_argument("--min-weight", type=float, default=0.0, help="最低权重分数")
    p.add_argument("--type-filter", choices=VALID_TYPES, help="按类型过滤")
    p.add_argument("--expand", action="store_true", help="联想扩散")
    p.add_argument("--no-embed", action="store_true", help="仅 BM25 关键词检索（快速，不加载 embedding）")
    p.add_argument("--max-chars-per-item", type=int, default=0, help="单条注入字符上限（0=不限）")
    p.add_argument("--max-total-chars", type=int, default=0, help="总注入字符预算（0=不限）")
    p.add_argument("--judge", action="store_true", help="判定模式：输出每条全文+相似度+类型+关键词+创建日，供 AI 判同主题（值必存第一段用）")
    p.add_argument("--tree", action="store_true", help="记忆树完整模式：递归展示子树含内容摘要（默认仅骨架 title 树，渐进式披露）")
    p.add_argument("--depth", type=int, default=3, help="记忆树展开深度（默认3层，--tree 时有效）")
    p.set_defaults(func=cmd_recall)

    p = sub.add_parser("update", help="更新记忆")
    p.add_argument("--id", required=True, help="记忆ID")
    p.add_argument("--content", help="新内容"); p.add_argument("--keywords", help="新关键字")
    p.add_argument("--emotion", help="新情绪（0.0~1.0 数值，或旧词）"); p.add_argument("--type", choices=VALID_TYPES, help="新类型")
    p.add_argument("--scene", help="新场景")
    p.add_argument("--activity-start", help="新活动开始时间")
    p.add_argument("--activity-end", help="新活动结束时间")
    p.add_argument("--status", default=None, choices=list(TASK_STATUSES),
                   help="任务状态更新：pending/in_progress/done/blocked")
    p.set_defaults(func=cmd_update)

    p = sub.add_parser("delete", help="删除记忆")
    p.add_argument("--id", required=True, help="记忆ID")
    p.set_defaults(func=cmd_delete)

    p = sub.add_parser("promote", help="因果上浮：记忆升到祖父层/根（本条升为更上游之因，果链随之）")
    p.add_argument("--id", required=True, help="记忆ID")
    p.set_defaults(func=cmd_promote)

    p = sub.add_parser("demote", help="因果下沉：记忆挂到 --parent 下成为其果（因果链延一层）")
    p.add_argument("--id", required=True, help="记忆ID")
    p.add_argument("--parent", required=True, help="目标父节点ID（=本条的因）")
    p.set_defaults(func=cmd_demote)

    p = sub.add_parser("merge", help="语义合并高相关记忆（预览→apply）")
    p.add_argument("--id", required=True, help="锚定记忆ID（合并后保留此ID，写入权威版）")
    p.add_argument("--threshold", type=float, default=0.70,
                   help="语义相似度阈值（默认0.70，按向量语义，非字符串）")
    p.add_argument("--keyword", default=None, help="可选：额外按 keywords 字段过滤簇")
    p.add_argument("--content", default=None, help="AI 手写权威合并版（仅 apply 时必填）")
    p.add_argument("--apply", action="store_true", help="真正合并删旧；不加则为 dry-run 预览")
    p.add_argument("--keywords", default=None, help="合并后 keywords 覆盖/合并")
    p.add_argument("--emotion", default=None, help="合并后情绪")
    p.add_argument("--type", default=None, help="合并后类型")
    p.set_defaults(func=cmd_merge)

    p = sub.add_parser("stats", help="统计信息"); p.set_defaults(func=cmd_stats)

    # ── link / unlink（知识图谱：手动关系，贾维斯块⑤）──
    lk = sub.add_parser("link", help="双向链接两条记忆（causes/references/contradicts/extends）")
    lk.add_argument("--source", required=True, help="源记忆 ID")
    lk.add_argument("--target", required=True, help="目标记忆 ID")
    lk.add_argument("--rel-type", default="references", choices=list(REL_TYPES),
                    help="关系类型：causes(因果)/references(引用)/contradicts(矛盾)/extends(延伸)")
    lk.add_argument("--note", default="", help="关系注记（如因果说明）")
    lk.set_defaults(func=cmd_link)
    ul = sub.add_parser("unlink", help="删除关系（--rel-id 或 --source/--target/--rel-type 组合）")
    ul.add_argument("--rel-id", default=None, help="关系记录 ID")
    ul.add_argument("--source", default=None, help="按源过滤")
    ul.add_argument("--target", default=None, help="按目标过滤")
    ul.add_argument("--rel-type", default=None, choices=list(REL_TYPES), help="按类型过滤")
    ul.set_defaults(func=cmd_unlink)

    # ── resume（会话桥接：存档/恢复，贾维斯块③）──
    rs = sub.add_parser("resume", help="会话桥接：无参=恢复（上次存档+未完成任务）；--save=存档")
    rs.add_argument("--save", default=None, help="会话结束存档：传总结全文")
    rs.add_argument("--title", default=None, help="存档标题（默认会话存档+时间）")
    rs.add_argument("--keywords", default=None, help="存档关键字")
    rs.add_argument("--session", default=None, help="会话 ID")
    rs.add_argument("--source", default=None, help="存档来源")
    rs.add_argument("--limit", type=int, default=1, help="恢复时显示最近 N 条存档（默认1，上限5）")
    rs.set_defaults(func=cmd_resume)

    p = sub.add_parser("recover", help="从备份文件恢复记忆库（data/ 被误删时使用）"); p.set_defaults(func=cmd_recover)

    sv = sub.add_parser("serve", help="启动 HTTP 服务器（多客户端共享记忆）")
    sv.add_argument("--bind", default="127.0.0.1:8787", help="监听地址（默认 127.0.0.1:8787）")
    sv.add_argument("--token", help="Bearer token（默认取自 YISHI_SERVE_TOKEN 环境变量）")
    sv.set_defaults(func=cmd_serve)

    p = sub.add_parser("forget", help="遗忘/归档旧记忆")
    p.add_argument("--before", help="归档此日期之前的记忆"); p.add_argument("--low-freq", type=int, help="频率阈值"); p.add_argument("--auto", action="store_true", help="自动标记")
    p.set_defaults(func=cmd_forget)

    cap = sub.add_parser("capsule", help="时间胶囊")
    cap.add_argument("capsule_action", choices=["lock", "unseal", "list", "check-expired"])
    cap.add_argument("--content", help="胶囊内容"); cap.add_argument("--summary", help="摘要")
    cap.add_argument("--keywords", help="关键字"); cap.add_argument("--unlock-at", help="解锁日期")
    cap.add_argument("--capsule-id", help="胶囊ID")
    cap.set_defaults(func=cmd_capsule)

    imp = sub.add_parser("import-file", help="导入")
    imp.add_argument("filepath", help="文件路径")
    imp.add_argument("--format", choices=["markdown", "text", "json"], default="text")
    imp.set_defaults(func=cmd_import)

    exp = sub.add_parser("export", help="导出")
    exp.add_argument("--format", choices=["markdown", "timeline", "json"], default="markdown")
    exp.add_argument("--output", required=True, help="输出文件")
    exp.set_defaults(func=cmd_export)

    return parser


def main():
    parser = _build_parser()
    args = parser.parse_args()
    if not args.command:
        parser.print_help(); sys.exit(0)

    # Local/Remote 双模式：当 YISHI_ADDR 环境变量存在时，把常用命令转发到远程 serve
    remote_addr = os.environ.get("YISHI_ADDR", "").strip()
    remote_cmds = {"store", "recall", "delete", "stats", "forget", "promote", "demote", "update"}
    if remote_addr and args.command in remote_cmds and args.command != "serve":
        result = _remote_argv(sys.argv[1:])
        if result:
            code, text = result
            if text:
                print(text, end="")
            sys.exit(code)
        else:
            print("⚠️ 远程调用失败：无法连接 YISHI_ADDR", file=sys.stderr)
            sys.exit(1)

    # 2026-08-14 修复：忆时为单写者 sqlite 库，多 opencode 会话并发操作会互相踩
    # （曾现 "attempt to write a readonly database"）。此处对整条命令加进程排他锁，
    # 并发时最多等待约 8 秒，超时报友好错误而非让 chroma 抛底层异常。
    lock_fd = None
    try:
        import fcntl
        os.makedirs(DATA_DIR, exist_ok=True)
        lock_path = os.path.join(DATA_DIR, ".memory.lock")
        lock_fd = os.open(lock_path, os.O_CREAT | os.O_RDWR, 0o644)
        waited = 0
        while True:
            try:
                fcntl.flock(lock_fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
                break
            except OSError:
                if waited >= 8:
                    print("⚠️ 另一忆时进程正在操作（并发写锁），请稍后再试", file=sys.stderr)
                    os.close(lock_fd); sys.exit(1)
                time.sleep(0.2)
                waited += 0.2
    except ImportError:
        pass  # 非 POSIX 平台退化：无进程锁，仅靠 WAL + 重试兜底

    try:
        args.func(args)
    finally:
        if lock_fd is not None:
            try:
                import fcntl
                fcntl.flock(lock_fd, fcntl.LOCK_UN)
            except Exception:
                pass
            os.close(lock_fd)


if __name__ == "__main__":
    main()

---
name: memocap
description: "🎋 记忆胶囊系统 - 模拟人类记忆检索 | 自动加载，主动联想记忆"
priority: 900
metadata:
  slug: memocap
  version: "2.4.0"
  trigger: "忆时、记忆检索、时间胶囊、记忆胶囊、回想、回忆、recall、remember、/忆时"
  copaw:
    emoji: "🎋"
    requires: {}
    auto_load: true
---

# 忆时 - 记忆胶囊系统

> 模拟人类的记忆机制，让 AI 拥有会遗忘、会联想、会涌现、会封存的记忆系统。
> **渐进式披露**：本文件为入口总纲。细节皆在 modules/——按「按需读取」表，遇场景才读对应模块，勿一次全读。

## 触发条件

- **自动加载**：每次对话自动激活，AI 主动联想和检索记忆
- **关键字**：忆时、记忆检索、时间胶囊、记忆胶囊、回想、回忆、我说过、我记得
- **命令**：用户输入以 `/忆时` 开头时，自动触发快捷操作模式
- **场景**：用户询问过去的事情、要求回忆、需要上下文关联、触发闪回
- **主动**：定时模式运行时主动扫描到期胶囊和记忆关联

## 核心概念

| 概念 | 说明 |
|------|------|
| **类人检索** | 语义40% + 近因20% + 情绪15% + 频率25%，不像数据库那样精确 |
| **混合检索** | BM25 关键词 + 向量语义双路 RRF 融合（k=60），人名/专名/代码标识符检索更准；embedding 失败自动降级关键词 |
| **去重合并** | 存储时相似>90% 自动合并（内容并入、频率+1），85%~90% 警告提示，--force 强存 |
| **渐进式回忆** | 先抛最相关的1-2条，用户追问再深入，非一次性倒出 |
| **遗忘曲线** | 记忆随时间指数衰减，低频率的记忆会变得"模糊" |
| **情绪锚定** | 高情绪（情绪值 ≥0.7）记忆权重更高，不易遗忘 |
| **记忆涌现** | 话题转换时发现隐藏关联，主动说出"说到这个我突然想到…" |
| **场景分组** | 记忆可标 --scene 归组，事件记忆可标活动时间段（2025-05-01 ~ 05-10） |
| **时间胶囊** | 封存某段记忆，设定解锁日期，到期后自动/手动解封翻阅 |

## 记忆类型

| 类型 | 说明 | 情绪权重倾向 |
|------|------|-------------|
| emotion | 情绪事件（开心、愤怒、悲伤） | |
| decision | 用户做出的决策 | 🟠 |
| task | 任务/待办（含状态 pending/in_progress/done/blocked） | 🟡 |
| time | 时间敏感信息（截止日期） | 🔴 |
| preference | 用户偏好/习惯 | 🟢 |
| context | 上下文/背景信息 | 🟡 |
| skill | 技能——用户教AI的工作流，Gene结构化存储 | 🟠 |
| session | 会话存档（resume --save 生成，会话桥接用） | |

## 按需读取（渐进式披露核心）

**规则：未遇对应场景，不读模块。每模块读一次即可，勿重复加载。**

| 场景 | 读模块 |
|------|--------|
| 对话启始、每言必检、主动存储、检索升级、决策前置、会话桥接(resume)、知识图谱(link)、自动技能习得 | modules/13-retrieval-store.md |
| 用户描述工作流（教AI流程）、skill记忆检索命中 | modules/07-skill-memory.md |
| 对话结束归档、仅输入 `/忆时` 会话整理、每满5轮定期提取 | modules/09-archiving.md |
| 用户输入 `/忆时 ...`（命令构造/回复风格） | modules/11-quick-commands.md |
| 可视化（"看看记了啥"）、人物画像 | modules/12-viz-profile.md |
| 记忆自动梳理（上次梳理过期7日） | modules/10-consolidation.md |
| 模型安装/切换、opencode.json 配置 | modules/08-setup.md |
| 复杂任务规划、上下文压缩后自查、长文索引 | modules/14-behavior.md |
| 需求暧昧、意图不清、先问清再作答 | modules/15-ask-intent.md |
| 首次初始化、Chroma 集合结构 | modules/01-initialize.md |
| 定时主动模式（胶囊检查/遗忘归档） | modules/03-active-mode.md |
| 时间胶囊管理 | modules/04-time-capsule.md |
| 检索算法原理（综合得分公式） | modules/05-retrieval.md |
| 导入导出、备份迁移 | modules/06-import-export.md |
| 被动检索触发场景与渐进式回忆 | modules/02-passive-mode.md |

## 核心命令

```bash
PY=~/.local/share/yishi/scripts/memory_core.py
MEMO_DIR=~/.local/share/yishi/data    # 所有命令必设
# 注意：以下命令使用 $PY 与 $MEMO_DIR 变量，须先执行上方两行定义；或直接写全路径 python3 ~/.local/share/yishi/scripts/memory_core.py
# Windows：PowerShell 用 `$env:USERPROFILE`（接子路径写 `${env:USERPROFILE}\.local\...` 防花括号吞点），cmd 用 `%USERPROFILE%`；python 替 python3

初始化:    python3 $PY init
存储记忆:  python3 $PY store "内容" --type task --emotion 0.8 [--scene 场景] [--activity-start 2025-05-01] [--activity-end 2025-05-10] [--force] [--merge-ids "旧ID1,旧ID2"]
检索记忆:  python3 $PY recall "查询" [--limit 3 --expand] [--no-embed] [--max-total-chars 600]  # 向量语义相似<0.70 者自动过滤不展示
语义合并:  python3 $PY merge --id <锚ID> [--threshold 0.68] [--keyword 过滤] [--content "权威版" --apply]
会话桥接:  python3 $PY resume                     # 会话始：上次存档+未完成任务
会话存档:  python3 $PY resume --save "本轮要点" --title "短标题"   # 会话末必做
任务状态:  python3 $PY update --id <任务ID> --status in_progress   # pending/in_progress/done/blocked
知识图谱:  python3 $PY link --source <ID甲> --target <ID乙> --rel-type causes --note "注记"
           # rel-type: causes⚡因果 / references📎引用 / contradicts⚔️矛盾 / extends🌱延伸；unlink 删
封胶囊:   python3 $PY capsule lock --unlock-at "2026-12-31"
查看胶囊:  python3 $PY capsule list
导入:      python3 $PY import-file file.md --format markdown
导出:      python3 $PY export --format timeline --output output.md
可视化:    python3 ~/.local/share/yishi/scripts/viz/viz.py
专题之书:  python3 ~/.local/share/yishi/scripts/viz/viz.py --topic "系统运维" --label "openKylin"
记忆脑图:  python3 ~/.local/share/yishi/scripts/viz/mindmap.py
统计:      python3 $PY stats
遗忘:      python3 $PY forget --before "2025-01-01" --auto
恢复:      python3 $PY recover
查看备份:  cat memories_backup.jsonl | python3 -m json.tool --lines
```

## 快捷操作一览

`/忆时` 前缀，免记命令行参数。命令构造、解析规则、回复风格见 modules/11-quick-commands.md。

| 输入 | 动作 |
|------|------|
| `/忆时`（无后续） | 会话整理 |
| `/忆时 <内容>` | 默认 recall |
| `/忆时 记住/记忆 <内容> [--type T] [--emotion E]` | store |
| `/忆时 查找/搜索/找 <关键词> [--limit N]` | recall |
| `/忆时 忘记 <关键词>` | forget |
| `/忆时 统计` | stats |
| `/忆时 导出` | export |
| `/忆时 可视化 [--out 路径]` | 记忆全景 HTML |
| `/忆时 脑图 [--out 路径]` | 记忆脑图 |
| `/忆时 画像` | 人物画像 |
| `/忆时 恢复` | recover |
| `/忆时 胶囊 封存/列表/开封` | capsule lock/list/unlock |
| `/忆时 梳理` | 记忆梳理 |

**类型**：task / decision / preference / emotion / time / context / skill
**情绪**：0.0~1.0 数值（默认 0.5），数值越大越重要/强烈；旧词 high=0.8 / medium=0.5 / low=0.2 仍兼容

## 工程实践——关键场景

| 场景 | 指令 |
|------|------|
| 完成任务后 | 按审计三问自查：结果问→过程问→改进问，全过方可言"完" |
| 收到复杂需求 | 先存方案到忆时，再规划步骤，逐条标记完成 |
| 需求暧昧/意图不清 | 先问清再作答，用澄清四问骨架（见 modules/15-ask-intent.md） |
| 发现用户偏好 | 以 `--type preference` 即时存储 |
| 做出关键决策 | 以 `--type decision --emotion 0.9` 存储，附决策理由 |
| 用户交付长文 | 提取metadata，按索引思维存储（见 modules/14） |
| 对话转折话题 | 先 `recall` 新话题的关键词，再谈是否有关联 |
| 疑似走偏 | 暂停，`recall` 原始目标比对进度 |
| 决策或提问之前 | 先 `recall` 查询记忆，确认有无既有决策、偏好、约定可循 |
| 对话开始 | 检索当前项目/文件夹相关记忆（见 modules/13） |
| 对话结束 | 按归档流程，先检索旧忆，再择新增或更新（见 modules/09） |
| 记忆自动梳理 | 对话启始先召回上次梳理时间告知用户，过期7日则触发沉淀（见 modules/10） |
| 完成任务（todo完成/修改变更/输出结果） | 停顿自问"有无值得记忆？"，有则检索旧忆后store或update |
| 用户输入 `/忆时` 开头 | 直入快捷操作模式，解析动作与参数，跳过常规涌现检索 |

## 项目结构

```
忆时/
├── SKILL.md                    # 技能定义 (入口总纲/识别层)
├── yishi-instructions.md       # 外挂提示词 (install.py/插件 apply 自动配置到 opencode.json)
├── modules/                    # 详细流程模块 (执行层，按需读取)
│   ├── 01-initialize.md        # Chroma 初始化
│   ├── 02-passive-mode.md      # 被动模式流程
│   ├── 03-active-mode.md       # 主动模式流程
│   ├── 04-time-capsule.md      # 时间胶囊操作
│   ├── 05-retrieval.md         # 类人检索策略
│   ├── 06-import-export.md     # 导入导出操作
│   ├── 07-skill-memory.md      # 技能即记忆 (Gene)
│   ├── 08-setup.md             # 模型安装与配置
│   ├── 09-archiving.md         # 对话归档与会话整理
│   ├── 10-consolidation.md     # 记忆自动梳理
│   ├── 11-quick-commands.md    # 快捷操作详解
│   ├── 12-viz-profile.md       # 可视化与人物画像
│   ├── 13-retrieval-store.md   # 记忆操作流程 (检索/存储细则)
│   ├── 14-behavior.md          # 认知自知与上下文工程
│   └── 15-ask-intent.md        # 需求澄清——先问清再作答
├── models/                     # （预留，仅 bge 模型不落此——运行时模型在 LOCAL_BASE）
├── scripts/
│   ├── memory_core.py          # 核心引擎 CLI
│   └── viz/                    # 记忆可视化
│       ├── viz.py              # 记忆全景生成器（导出→聚类→注入模板→打开）
│       ├── mindmap.py          # 记忆图谱生成器（关系簇+孤立保留→~300节点网络图）
│       ├── mindmap_template.html # 记忆图谱模板（D3力导向 Canvas，/*__D3_JS__*/ 与 __YISHI_GRAPH_DATA__ 占位）
│       ├── template.html       # 记忆全景模板（孟菲斯风，/*__DATA__*/ 占位）
│       ├── profile.py          # 人物画像助手（素材报告 + 正文注入）
│       └── profile_template.html # 画像模板（<!--DATA-->/<!--CONTENT--> 占位）
└── references/
    ├── chroma-api.md           # ChromaDB API 参考
    ├── asking-techniques.md    # 提问技术参考（卡兹克法提炼，意图澄清）
    └── kazik-12-prompts.md     # 卡兹克《12个最常用Prompt》原文存档
```

## 运行环境

- Python: 3.9+（Windows 用 `python`，Linux/macOS 用 `python3`，脚本不硬编码解释器）
- 依赖: chromadb>=1.5.4、jieba、onnxruntime、tokenizers、numpy（见 `scripts/requirements.txt`）
- 脚本: `scripts/memory_core.py`
- 数据: `data/` (ChromaDB PersistentClient 自动创建)
- 模型: bge-base-zh-v1.5（768维，唯一模型，无回退）。安装见 modules/08-setup.md
- 备份: `~/.local/share/yishi/memories_backup.jsonl`（可用 MEMO_BAK 覆盖，多实例/测试隔离）

### 环境自愈（AI 发现用不起来时自行安装）

脚本报错（缺依赖/未初始化/模型缺失）时，**AI 先自修再问人**，固定流程：

1. 定解释器：`python3 --version` 不通则试 `python --version`（Windows 常见），再试 `py -3 --version`。
2. 一键自愈（幂等）：`python3 ~/.local/share/yishi/scripts/install.py`（Windows PS: `python $env:USERPROFILE\.local\share\yishi\scripts\install.py`；cmd: `python %USERPROFILE%\.local\share\yishi\scripts\install.py`）
3. 分步兜底：`install.py --deps-only` / `--init-only` / `--model-only`（或 `-m pip install -r requirements.txt` / `memory_core.py init` / `models-install.py`）
4. 仍败才报用户，附报错原文与已执行命令痕迹。

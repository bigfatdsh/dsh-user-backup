# 模块 01 - 初始化与 Chroma 管理

## 目标

初始化 ChromaDB 向量数据库，建立必要的集合。

## 执行步骤

1. 检查 Python 3.9+ 是否可用（Windows 用 `python`，Linux/macOS 用 `python3`）
2. 检查依赖是否已装（chromadb/jieba/onnxruntime/tokenizers/numpy，缺则 `python3 -m pip install -r ~/.local/share/yishi/scripts/requirements.txt`）
3. 运行初始化命令:

```bash
# Linux/macOS
python3 ~/.local/share/yishi/scripts/memory_core.py init
# Windows PowerShell（无 python3 时用 python；$env:USERPROFILE 替 ~，花括号防吞点）
python $env:USERPROFILE\.local\share\yishi\scripts\memory_core.py init
# Windows cmd.exe
python %USERPROFILE%\.local\share\yishi\scripts\memory_core.py init
# 推荐一键自愈（依赖+初始化+模型，幂等）
python3 ~/.local/share/yishi/scripts/install.py
```

4. 确认输出包含"忆时记忆系统初始化完成"

## 集合结构

ChromaDB 内会创建以下集合:

| 集合名 | 用途 | 距离度量 |
|--------|------|----------|
| memories | 长期记忆向量存储 | cosine |
| relationships | 记忆间关联关系 | cosine |
| meta | 系统状态元数据 | cosine |

## 记忆元数据结构

每条记忆包含以下元数据:

```json
{
  "type": "context",
  "emotion": "medium",
  "emotion_weight": 0.5,
  "created_at": "2025-01-15T10:30:00",
  "created_date": "2025-01-15",
  "updated_at": "2025-01-15T10:30:00",
  "keywords": "Python,学习,装饰器",
  "source": "manual",
  "source_session": "",
  "frequency": "1",
  "recall_count": "0",
  "is_capsule": "false",
  "capsule_unlock_at": ""
}
```

## 模型安装

本技能使用 **bge-base-zh-v1.5**（BAAI 中文语义模型，768 维），**无回退**。
引擎检测 `~/.local/share/yishi/models/bge-base-zh-v1.5/`，缺失即报错。
安装命令——详见 modules/08-setup.md。

> ⚠️ 模型不会写入 `~/.cache/chroma/`，清缓存不会被删除。

## 环境变量

| 变量 | 默认值 | 说明 |
|------|--------|------|
| MEMO_DIR | ~/.local/share/yishi/data | ChromaDB 存储路径 |

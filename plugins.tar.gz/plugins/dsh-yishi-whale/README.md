# dsh-yishi-whale

把 [@fslong/dsh-yishi](https://www.npmjs.com/package/@fslong/dsh-yishi)（v0.4.26）**只**接进「鲸鱼娘·大肥鱼（微信精简）」预设（`whale-lean`）的适配包：忆时记忆 + 一条覆盖层，除此之外什么都不改。

## 隔离方式

| 位置 | 内容 | 影响范围 |
|---|---|---|
| `cordis.patch.yml` | 按 Loader 行 id 覆盖 `preset-whale-lean`：重述原预设全部插件，末尾追加 `yishi` 行 | 仅 `whale-lean` |
| 包本身 | 没有全局 `insert` 行；`apply` 只在被 preset 行挂载时运行 | 不挂载 = 零影响 |
| 记忆指令 | 只在该 preset 的 agent scope 注入 `systemPrompt.section` | 其他 preset 看不到 |
| memocap 技能 | 本预设默认 `skill: false`（没有 `tool-skill`，注册也无处可用） | 不注册 |

其他预设（standard / computer-use / minimal / ptc）的插件、提示词、技能目录都不变。

## 相对原版的适配

1. **增量同步**：`assets/` 与 `scripts/` 按 mtime/size 复制，未改动不重写；不再每次 apply 全量 `cpSync`。
2. **一次自举**：`.ready`（内容=包版本）+ venv + 模型三件齐备就完全跳过；缺任何一件才后台跑 `lib/bootstrap.sh`。
3. **独立 venv**：优先 `uv` + Python 3.12（本机 uv 已配置清华镜像），装到 `~/.local/share/yishi/venv`，不碰系统 Python。
4. **模型镜像**：`models-install.py` 改为 ModelScope 主源 + hf-mirror 备源，`.part` 断点续传；本机 hf-mirror 会 429，ModelScope 实测可用。
5. **不再写 opencode 配置**：原版每次 apply 都会跑 `install.py --opencode-only`，对 DSH 无用且会改外部配置。
6. **精简指令**：注入 `assets/yishi-instructions-lean.md`（约 1.4KB），只留记忆存取契约；原版 34KB 指令里的「鲁迅式半文半白／自称小妹／称哥哥」会和大肥鱼人设打架，已全部移除。完整原版指令仍在 `~/.local/share/yishi/docs/yishi-instructions.md`，需要时可切回。
7. **启动器**：生成 `~/.local/share/yishi/bin/yishi`，固定解释器与 `MEMO_DIR`，模型里只需写 `$Y ~/.local/share/yishi/bin/yishi recall ...`。

## 配置项（preset 行内）

```yaml
- id: yishi
  name: dsh-yishi-whale
  config:
    instructions: lean   # lean（默认）| full（原版 34KB）| off
    skill: false         # true 时注册 memocap 技能提供者
    bootstrap: auto      # auto（默认，未就绪才自举）| off
    sectionOrder: 50     # systemPrompt 段位；50 = 人设之后、工具说明之前
    dataDir: ~/.local/share/yishi  # 默认，可覆盖
```

## 维护

预设原文改了以后重新生成覆盖层（否则新插件不会带进来）：

```sh
node sync-preset.mjs
```

然后重新安装本 bundle（让 profile 里的副本更新）：

```sh
# 用 DSH 的 plugin_manager：action=install_bundle, target=<本目录绝对路径>
```

## 验证

```sh
Y=~/.local/share/yishi/bin/yishi
$Y resume
$Y store --type preference --keywords "测试" --emotion 0.3 "适配自检"
$Y recall "测试"
```

日志：`~/.local/share/yishi/install.log`；数据：`~/.local/share/yishi/data`。

## 来源与许可

上游：`@fslong/dsh-yishi@0.4.26`（MIT）。本目录只做上述适配，检索/存储逻辑未改。

#!/bin/sh
# 忆时环境自举（幂等）：独立 venv + 依赖 + bge 模型 + 数据初始化。
# 由插件在「未就绪」时后台调用；成功写 .ready（内容为插件版本），失败下次启动再试。
set -eu

BASE="${YISHI_DATA_DIR:-$HOME/.local/share/yishi}"
VERSION="${YISHI_VERSION:-unknown}"
export YISHI_DATA_DIR="$BASE"
export MEMO_DIR="$BASE/data"

mkdir -p "$BASE"
echo "[$(date -u +%Y-%m-%dT%H:%M:%SZ)] bootstrap start (version=$VERSION, base=$BASE)"

UV="$(command -v uv || true)"
if [ -z "$UV" ] && [ -x "$HOME/.local/bin/uv" ]; then
  UV="$HOME/.local/bin/uv"
fi

PY="$BASE/venv/bin/python"
if [ ! -x "$PY" ]; then
  echo "creating venv"
  if [ -n "$UV" ]; then
    UV_CACHE_DIR="$BASE/.uv-cache" "$UV" venv --python 3.12 "$BASE/venv" || python3 -m venv "$BASE/venv"
  else
    python3 -m venv "$BASE/venv"
  fi
fi
if [ ! -x "$PY" ]; then
  echo "ERROR: venv python missing at $PY" >&2
  exit 1
fi

echo "installing requirements"
if [ -n "$UV" ]; then
  UV_CACHE_DIR="$BASE/.uv-cache" "$UV" pip install --python "$PY" -r "$BASE/scripts/requirements.txt"
else
  PIP_INDEX_URL="${PIP_INDEX_URL:-https://pypi.tuna.tsinghua.edu.cn/simple}" \
    "$PY" -m pip install --disable-pip-version-check -r "$BASE/scripts/requirements.txt"
fi

MODEL="$BASE/models/bge-base-zh-v1.5/onnx/model.onnx"
if [ ! -f "$MODEL" ]; then
  echo "downloading bge model"
  "$PY" "$BASE/scripts/models-install.py" || true
fi
if [ ! -f "$MODEL" ]; then
  echo "ERROR: model missing at $MODEL" >&2
  exit 1
fi

echo "initializing data dir"
# 只用 memory_core init：install.py 会顺带写 ~/.config/opencode，DSH 不需要这个副作用
"$PY" "$BASE/scripts/memory_core.py" init

echo "$VERSION" > "$BASE/.ready"
echo "[$(date -u +%Y-%m-%dT%H:%M:%SZ)] bootstrap done"

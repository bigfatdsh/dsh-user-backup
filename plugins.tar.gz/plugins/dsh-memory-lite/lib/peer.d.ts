/**
 * Peer derivation: which memory root a session reads and writes.
 * @module dsh-memory-lite/src/peer
 */
import type { SessionHeader } from '@deepseek-ai/dsh-session';
import type { ResolvedConfig } from './config.js';
/** The peer a session belongs to, derived from its cwd when enabled. */
export declare function peerForHeader(header: SessionHeader | undefined, config: ResolvedConfig): string;
/**
 * Deterministic peer name from a working directory: sanitized basename plus a
 * short hash of the full path, so distinct directories sharing a basename do
 * not silently share a memory root.
 */
export declare function peerFromCwd(cwd: string): string;
/**
 * Human-readable display name for a working directory: the directory's own
 * basename, unmodified (CJK and other non-ASCII spellings survive verbatim).
 * Peer *directory names* stay ASCII (see peerFromCwd); this value only feeds
 * UI annotations and is never used as a path segment.
 */
export declare function displayNameFromCwd(cwd: string): string;
/** Sanitize a configured peer name for use as one directory segment. */
export declare function sanitizePeerName(name: string): string;

/**
 * The on-disk memory tree: containment, atomic writes through a serial queue,
 * L0 index management, and line search. Instances are created per plugin mount
 * and closed over by the tools and the pre-step injector.
 * @module dsh-memory-lite/src/memory-store
 */
import type { IndexEntry } from './types.js';
import type { SharingConfig } from './config.js';
/** Serialize mutations so writers never interleave inside one memory tree. */
export declare class MutationQueue {
    private tail;
    /** Run `op` after every previously queued operation; errors isolate per call. */
    enqueue<T>(op: () => Promise<T>): Promise<T>;
}
/** Cap on retained summary-log lines per peer (bounds the rolling log). */
export declare const MAX_LOG_LINES = 5000;
/** UI-annotation metadata for one peer directory (never a path segment). */
export interface PeerMeta {
    /** Human-readable source directory basename, e.g. "健康分析". */
    readonly displayName: string;
    /** Absolute source working directory the peer was derived from. */
    readonly sourceCwd?: string;
}
/** One existing peer directory as surfaced to the settings UI. */
export interface PeerSummary {
    /** Stable storage name (ASCII, hash-suffixed); used as path/mount identity. */
    readonly name: string;
    /** Human-readable annotation; equals the name when no annotation exists. */
    readonly displayName: string;
}
/** One line-level search hit. */
export interface SearchMatch {
    /** Memory path relative to the peer's memories root. */
    readonly path: string;
    /** The matching line, capped in length. */
    readonly line: string;
}
/** The known sections of a memory file; extra content is preserved verbatim. */
export interface MemoryFileSections {
    /** H1 title text ('' when absent). */
    title: string;
    /** Current-section body ('' when absent). */
    current: string;
    /** History-section body ('' when absent). */
    history: string;
    /** Related-section body ('' when absent). */
    related: string;
    /** Preamble plus any unknown `## section` bodies, preserved. */
    extra: string;
}
/** Parse a memory file into its sections; unknown sections survive in {@link MemoryFileSections.extra}. */
export declare function parseMemoryFile(text: string): MemoryFileSections;
/**
 * Normalize a tool-supplied "new content" value. Models sometimes pass a full
 * rendered memory file (an H1 title line plus `## Current` etc.) instead of
 * the plain new body; detect that shape and extract the Current section body
 * so it is stored as the section's content rather than nested as a literal
 * bullet. Plain text passes through unchanged.
 */
export declare function normalizeContent(content: string): string;
/** Render parsed sections back into a canonical memory file (always ends with one newline). */
export declare function renderMemoryFile(sections: MemoryFileSections): string;
/** One-line summary of content for the L0 index. */
export declare function summaryOf(content: string, maxLength?: number): string;
/** Render the L0 index document for one peer. */
export declare function renderIndex(peer: string, entries: readonly IndexEntry[], now: Date): string;
/** Parse L0 index entries from an index document; malformed lines are ignored (tolerant of human edits). */
export declare function parseIndex(text: string): IndexEntry[];
/**
 * A filesystem-safe slug from a title, used as the memory file basename.
 * Keeps Unicode letters and numbers (Chinese titles yield CJK filenames
 * instead of collapsing to the bare 'memory' fallback, which would collide).
 */
export declare function slugify(title: string): string;
/**
 * Owns the on-disk memory tree for every peer under one root. All mutations
 * run through {@link MutationQueue}; every read/write goes through
 * {@link MemoryStore.resolve} (the containment boundary).
 */
export declare class MemoryStore {
    readonly root: string;
    private readonly queue;
    readonly sharing: SharingConfig;
    constructor(root: string, sharing?: SharingConfig);
    /** Path of the global charter file (SOUL / Identity) directly under root. */
    globalCharterPath(): string;
    /**
     * Read the global charter (AGENTS.md) if present under the memory root.
     * Returns trimmed content or undefined if absent / empty / unreadable.
     */
    readGlobalCharter(): Promise<string | undefined>;
    peersDir(): string;
    /** Absolute path of one peer's UI-annotation metadata file. */
    peerMetaPath(peer: string): string;
    /** Read one peer's annotation metadata, or undefined when absent/unreadable. */
    readPeerMeta(peer: string): Promise<PeerMeta | undefined>;
    /**
     * Remember the human-readable source directory behind a peer. Written once
     * (first time a peer is seen with a cwd); later calls are no-ops so a rename
     * of the source directory never rewrites an established annotation.
     */
    rememberPeerCwd(peer: string, cwd: string): Promise<void>;
    /** One existing peer directory: its storage name plus the UI displayName. */
    listPeers(): Promise<PeerSummary[]>;
    memoriesRoot(peer: string): string;
    sessionsDir(peer: string): string;
    trashDir(): string;
    /**
     * Contain and resolve a tool-supplied relative path inside one peer's memories
     * root. Paths under `shared/<name>/...` are redirected (Phase 3 sharing) to
     * the declared target peer's memories root; the model-facing relative path
     * keeps the `shared/<name>` prefix so tool output stays source-annotated.
     * `opts.write` marks a mutation so read-only mounts are rejected.
     */
    resolve(peer: string, relPath: string, opts?: {
        write?: boolean;
    }): Promise<{
        abs: string;
        rel: string;
    }>;
    /** Resolve a `shared/<name>/...` path against the declared mount, enforcing read-only. */
    private resolveShared;
    fileExists(peer: string, relPath: string): Promise<boolean>;
    readFile(peer: string, relPath: string): Promise<{
        content: string;
        rel: string;
    }>;
    /** Create a new memory file with the canonical skeleton. */
    writeNewMemory(peer: string, relPath: string, title: string, content: string): Promise<void>;
    /**
     * Append content as new Current bullets; creates the section when absent.
     * Identical lines already in Current are skipped (no-op writes are dropped).
     */
    appendCurrent(peer: string, relPath: string, content: string): Promise<void>;
    /**
     * Replace a memory's current content, archiving the previous current into
     * History with a date. The previous content is never destroyed (ADD-only).
     */
    updateCurrent(peer: string, relPath: string, content: string): Promise<void>;
    /**
     * Validate a session id and resolve its checkpoint/audit file under
     * sessionsDir; the id is constrained so it can never escape the directory.
     */
    sessionCheckpointPath(peer: string, sessionId: string): string;
    /** Read a session checkpoint document; a missing file reads as undefined. */
    readSessionCheckpoint(peer: string, sessionId: string): Promise<string | undefined>;
    /** Persist a session checkpoint/audit document through the serial queue. */
    writeSessionCheckpoint(peer: string, sessionId: string, text: string): Promise<void>;
    /** Peer-level rolling run log: peers/{peer}/sessions/extraction.log. */
    summaryLogPath(peer: string): string;
    /** Append one JSON line to the peer's extraction summary log (capped). */
    appendExtractionLog(peer: string, line: string): Promise<void>;
    /**
     * Diagnostic: append one failed extraction answer (the raw model output that
     * parseDecision rejected) to peers/{peer}/sessions/failed-answers.log, capped.
     * Only written when the answer was not salvageable; used to debug parse-error
     * spikes. Not part of the functional path — callers tolerate failures.
     */
    failedAnswerLogPath(peer: string): string;
    appendFailedAnswer(peer: string, entry: object): Promise<void>;
    /** Soft-delete: move the file under root/.trash/<date>/, never overwriting. */
    softDelete(peer: string, relPath: string): Promise<void>;
    /** Parse the L0 index for one peer; a missing index reads as empty. */
    readIndex(peer: string): Promise<IndexEntry[]>;
    /** Rebuild the L0 index from entries, sorted by file mtime (newest first). */
    rebuildIndex(peer: string, entries: readonly IndexEntry[]): Promise<void>;
    /** Add or replace one entry, then rebuild. */
    refreshIndexEntry(peer: string, relPath: string, summary: string): Promise<void>;
    /** Drop one entry, then rebuild. */
    removeIndexEntry(peer: string, relPath: string): Promise<void>;
    /** Line search across a peer's memory files, including enabled shared mounts (index files excluded). */
    search(peer: string, query: string, maxMatches?: number, maxLineLength?: number): Promise<SearchMatch[]>;
    /** Search roots for a peer: its own memories plus each enabled non-self shared mount. */
    private searchRoots;
    private writeNow;
    private writeIndexNow;
    private walkMarkdown;
}

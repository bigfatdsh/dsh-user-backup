/**
 * Configuration contracts for dsh-memory-lite. The schemastery `Config`
 * validates the shape a user writes in cordis.yml (every field optional);
 * `resolveConfig` performs explicit defaulting — the only place defaults
 * are applied.
 * @module dsh-memory-lite/src/config
 */
import z from '@deepseek-ai/schemastery';
/** Default memory root; `~` expands against the user's home. */
export declare const DEFAULT_MEMORY_ROOT = "~/.agent-memory";
/** Default peer used for sessions without a usable cwd. */
export declare const DEFAULT_PEER = "dsh-web";
/** Default cap on catalog size, in approximate tokens. */
export declare const DEFAULT_INDEX_MAX_TOKENS = 2000;
/** Default session-header indicator slot order (ascending; -1 sits left of the built-in "Session log" capsule). */
export declare const DEFAULT_HEADER_ORDER = -1;
/** Per-session peer derivation from `SessionHeader.cwd`. */
export interface WorkspacePeersConfig {
    /** Derive the peer from each session's cwd. Defaults to true. */
    enabled: boolean;
    /** Reserved for Phase 2 extraction; peer derivation ignores it. Defaults to true. */
    excludeSubagents: boolean;
    /** Peer name used when a session has no cwd; the literal `default_peer` selects the default. Defaults to `default_peer`. */
    cwdFallback: string;
}
/** L0 catalog sizing. */
export interface IndexConfig {
    /** Approximate token cap for the catalog; entries past the cap are truncated. Defaults to 2000. */
    maxTokens: number;
    /** Index sort order; `mtime` newest-first is the only supported value. Defaults to `mtime`. */
    sortBy: 'mtime';
}
/** Tool-side switches. */
export interface ToolsConfig {
    /** Reserved; the tool schemas are minimal by construction. Defaults to true. */
    schemaMinimal: boolean;
}
/** Browser-side indicator options. */
export interface UiConfig {
    /** Render order of the memory status indicator in the session-header utilities slot (ascending; smaller = further left, -1 sits left of the built-in "Session log" capsule). Defaults to -1. */
    headerOrder: number;
}
/** One explicit cross-peer share: expose a target peer's memories at shared/<name>/... */
export interface SharingMountConfig {
    /** Path prefix exposed to this peer's sessions: shared/<name>/<file>.md. Must be a plain segment. */
    name: string;
    /** Target peer whose memories root is shared. */
    peer: string;
    /** Subpath inside the target peer's memories root; '' = the whole root. */
    subpath: string;
    /** Read-only mirror; write operations are rejected. Defaults to true. */
    readonly: boolean;
}
/** Cross-peer sharing (Phase 3): explicit, not default. */
export interface SharingConfig {
    /** Master switch; when off, shared/ paths are rejected. Defaults to false. */
    enabled: boolean;
    /** Ordered mount declarations, visible to every peer except the target itself. */
    mounts: SharingMountConfig[];
}
/** Extraction model selection: an explicit route wins; empty = the global default model (agent-default-model). */
export interface ExtractionLlmConfig {
    /** Combined "provider/model" route, e.g. 'deepseek-official/deepseek-v4-flash'. Empty = global default. */
    route?: string;
    /** Adapter-owned reasoning effort id (e.g. 'low'); empty = follow the global default selection. */
    reasoningEffort?: string;
    /** Legacy provider key (kept for compatibility with pre-§17 configs); superseded by route. */
    provider?: string;
    /** Legacy model id (kept for compatibility with pre-§17 configs); superseded by route. */
    model?: string;
}
/** Background implicit extraction (Phase 2, channel B). */
export interface ExtractionConfig {
    /** incremental | explicit_only | off. Defaults to incremental. */
    mode: 'incremental' | 'explicit_only' | 'off';
    /** New in-scope conversation messages >= this count triggers an extraction. Defaults to 50. */
    windowTurns: number;
    /** Idle minutes before the remaining window is extracted. Defaults to 30. */
    idleTimeoutMin: number;
    /** Max messages fed to the extraction LLM per run. Defaults to 20. */
    maxMessages: number;
    /** Which event kinds count toward windowTurns and feed the extraction window.
     * 'user' = real user messages (injections never count), 'assistant' = assistant
     * messages, 'tool_result' = raw tool results. Tool results are excluded by
     * default: their raw output adds token cost and noise while the assistant
     * message already carries the interpretation. Defaults to ['user','assistant']. */
    messageScope: ('user' | 'assistant' | 'tool_result')[];
    /** Per tool/result content truncation before feeding the LLM. Defaults to 2048. */
    toolResultMaxBytes: number;
    /** Carry the rolling session digest. Defaults to true. */
    includeDigest: boolean;
    /** Grep existing memories for dedup/contradiction. Defaults to true. */
    dedup: boolean;
    /** Extraction model selection; empty route = the global default model (agent-default-model). */
    llm: ExtractionLlmConfig;
    /** agent/turn-stopping backstop trigger. Defaults to true. */
    turnStoppingTrigger: boolean;
    /** session/flush last-resort trigger. Defaults to true. */
    flushTrigger: boolean;
    /** Minimum unextracted messages for a turn-boundary run. Defaults to 5. */
    minTurnExtract: number;
    /** Debounce window for turn-boundary extraction, ms. Defaults to 30000. */
    turnDebounceMs: number;
    /** Write audit entries to peers/{peer}/sessions/{id}.json. Defaults to true. */
    auditLog: boolean;
    /** Global cap on concurrent extraction LLM requests. Defaults to 1. */
    maxConcurrentRequests: number;
    /** On a failed JSON parse, one cheap repair call re-asks the model for valid JSON. Defaults to true. */
    parseRetry: boolean;
}
/** Raw plugin configuration as written in cordis.yml; every field optional. */
export interface MemoryConfig {
    root?: string;
    defaultPeer?: string;
    workspacePeers?: Partial<WorkspacePeersConfig>;
    index?: Partial<IndexConfig>;
    tools?: Partial<ToolsConfig>;
    extraction?: Partial<ExtractionConfig>;
    sharing?: Partial<SharingConfig>;
    ui?: Partial<UiConfig>;
}
/** Fully defaulted configuration after {@link resolveConfig}. */
export interface ResolvedConfig {
    /** Absolute, `~`-expanded memory root. */
    root: string;
    defaultPeer: string;
    workspacePeers: WorkspacePeersConfig;
    index: IndexConfig;
    tools: ToolsConfig;
    extraction: ExtractionConfig;
    sharing: SharingConfig;
    ui: UiConfig;
}
/** Validate the plugin configuration shape. Unknown keys are tolerated for forward compatibility. */
export declare const Config: z<MemoryConfig>;
/**
 * Recursively unwrap Schemastery / Cosmokit `.volatile()` reference objects
 * ({ get(): T }). A volatile field evaluates to a stable reference holder
 * whose .get() yields the current value (or undefined when unconfigured).
 * This unwraps them so resolveConfig and all internal code deal strictly with
 * plain values.
 */
export declare function unwrapConfig<T>(obj: T): T;
/** Normalize and default a raw configuration; throws on invalid values. */
export declare function resolveConfig(rawConfig?: MemoryConfig): ResolvedConfig;

/**
 * Path canonicalization and containment — the plugin's single path-safety
 * boundary. Every file access resolves through `containWithin`.
 * @module dsh-memory-lite/src/path
 */
/** A memory path that is malformed or escapes its root; the model-facing rejection reason. */
export declare class MemoryPathError extends Error {
    readonly name = "MemoryPathError";
}
/** Resolve symlinks through the deepest existing ancestor, appending the rest lexically. */
export declare function realpathSafe(path: string): Promise<string>;
/** Create a directory and its parents; existing directories pass through. */
export declare function ensureDir(dir: string): Promise<void>;
/**
 * Contain a relative candidate inside `root`: normalize, resolve symlinks in
 * the deepest existing ancestor, and require the result to stay inside the
 * canonical root. Absolute paths, `..` escapes, and symlink escapes all throw
 * {@link MemoryPathError}. This is the enforcement point — tool descriptions
 * alone never gate file access.
 * @param root - canonical containment root (must exist or be creatable).
 * @param candidate - relative path, as supplied by the model.
 * @returns the canonical absolute path inside `root`.
 */
export declare function containWithin(root: string, candidate: string): Promise<string>;

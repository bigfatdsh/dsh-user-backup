/**
 * L0 catalog injection: an `agent/pre-step` waterfall listener that publishes
 * the peer's memory catalog as a durable user message, tracking visibility
 * and digest exactly like `@deepseek-ai/dsh-tool-skill`.
 * @module dsh-memory-lite/src/inject
 */
import type { Context } from '@deepseek-ai/cordis';
import type { PreStepDecision } from '@deepseek-ai/dsh-agent';
import type { UserMessage } from '@deepseek-ai/dsh-session';
import type { ToolDefinition } from '@deepseek-ai/dsh-tools';
import type { MemoryDeps } from './tool-utils.js';
import type { IndexEntry } from './types.js';
import { type SharedMountNotice } from './catalog.js';
/** Inputs to the catalog decision; all derived state is resolved by the caller. */
export interface CatalogDecisionParams {
    readonly decision: PreStepDecision;
    readonly history: {
        readonly published: boolean;
        readonly visibleText?: string;
    };
    readonly existing: {
        readonly message: UserMessage;
        readonly text: string;
    } | undefined;
    readonly entries: readonly IndexEntry[];
    /** Shared mounts to advertise (Phase 3); drives the empty-index exception. */
    readonly sharedMounts: readonly SharedMountNotice[];
    readonly peer: string;
    /** Global charter content from ~/.agent-memory/AGENTS.md (SOUL/Identity) if present. */
    readonly globalCharter?: string;
}
/**
 * Cap the injected catalog entries so the rendered catalog stays within
 * `index.maxTokens` (recency-first: entries arrive newest-first, oldest are
 * dropped from the injection only — the index file keeps them all and
 * search_memory still finds them). This is the design's bounded L0 window.
 */
export declare function capCatalogEntries(entries: readonly IndexEntry[], maxTokens: number): readonly IndexEntry[];
/**
 * Decide how the entering batch should carry the memory catalog. The branches
 * mirror `@deepseek-ai/dsh-tool-skill`: publish on first sight, replace or
 * drop a stale in-batch catalog, republish after compaction, and publish
 * nothing for a fresh empty index.
 */
export declare function applyCatalogDecision(params: CatalogDecisionParams): PreStepDecision;
/** Register the pre-step catalog injector for the lifetime of `ctx`. */
export declare function applyMemoryCatalogInjection(ctx: Context, deps: MemoryDeps, readTool: ToolDefinition): void;

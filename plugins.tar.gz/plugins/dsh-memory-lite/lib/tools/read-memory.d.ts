/**
 * The `read_memory` tool: loads the full text of one memory file.
 * @module dsh-memory-lite/src/tools/read-memory
 */
import type { Context } from '@deepseek-ai/cordis';
import type { MemoryDeps } from '../tool-utils.js';
/** Register read_memory and return its definition (the injector's visibility anchor). */
export declare function applyReadMemoryTool(ctx: Context, deps: MemoryDeps): import("@deepseek-ai/dsh-tools").ToolDefinition;

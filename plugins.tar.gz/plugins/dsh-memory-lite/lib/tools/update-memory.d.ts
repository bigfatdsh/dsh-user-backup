/**
 * The `update_memory` tool: replaces a memory's current content, archiving
 * the previous current into its History section (ADD-only).
 * @module dsh-memory-lite/src/tools/update-memory
 */
import type { Context } from '@deepseek-ai/cordis';
import type { MemoryDeps } from '../tool-utils.js';
/** Register update_memory. */
export declare function applyUpdateMemoryTool(ctx: Context, deps: MemoryDeps): void;

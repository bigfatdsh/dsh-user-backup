/**
 * The `remember` tool: explicit memory capture — creates a new memory file
 * or appends to an existing one with the same slug.
 * @module dsh-memory-lite/src/tools/remember
 */
import type { Context } from '@deepseek-ai/cordis';
import type { MemoryDeps } from '../tool-utils.js';
/** Register remember. */
export declare function applyRememberTool(ctx: Context, deps: MemoryDeps): void;

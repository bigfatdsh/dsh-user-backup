/**
 * The `forget_memory` tool: soft-deletes a memory into the trash directory
 * (never overwrites; approval wiring lands in Phase 3).
 * @module dsh-memory-lite/src/tools/forget-memory
 */
import type { Context } from '@deepseek-ai/cordis';
import type { MemoryDeps } from '../tool-utils.js';
/** Register forget_memory. */
export declare function applyForgetMemoryTool(ctx: Context, deps: MemoryDeps): void;

/**
 * The `search_memory` tool: line search across a peer's memory files.
 * @module dsh-memory-lite/src/tools/search-memory
 */
import type { Context } from '@deepseek-ai/cordis';
import type { MemoryDeps } from '../tool-utils.js';
/** Register search_memory. */
export declare function applySearchMemoryTool(ctx: Context, deps: MemoryDeps): void;

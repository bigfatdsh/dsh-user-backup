/**
 * Extraction prompt assembly. The model receives the rolling digest, the new
 * window, and any grep-matched existing memories, and must answer with one
 * JSON decision (create/merge/update/skip). Kept schema-minimal per the
 * design's cost discipline — this is one background request per run.
 * @module dsh-memory-lite/src/extract/prompt
 */
export interface GrepHitLike {
    readonly path: string;
    readonly line: string;
}
/** The system instruction given to the extraction model. */
export declare function extractionSystem(): string;
/** One line of the memory index: path plus one-line summary. */
export interface IndexEntryLike {
    readonly path: string;
    readonly summary: string;
}
/** The user turn: digest + window + memory index + existing hits. */
export declare function buildExtractionUser(digest: string | undefined, windowText: string, indexEntries: readonly IndexEntryLike[], grepHits: readonly GrepHitLike[]): string;

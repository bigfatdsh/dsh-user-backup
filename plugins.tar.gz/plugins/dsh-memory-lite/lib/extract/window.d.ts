/**
 * Extraction windowing: which session-log events feed an extraction run, how
 * the window is cropped, and how each event is rendered into text. Pure
 * functions over a minimal structural event shape (structurally satisfied by
 * DSH SessionEvent) so they are unit-testable without a live runtime.
 * @module dsh-memory-lite/src/extract/window
 */
/** The three surface event types (v6 定死, confirmed in dsh-session source). */
export declare const SURFACE_TYPES: readonly ["user/message", "assistant/message", "tool/result"];
export type SurfaceEventType = (typeof SURFACE_TYPES)[number];
/** One entry of extraction.messageScope: which event kinds feed the window and the trigger counter. */
export type MessageScope = 'user' | 'assistant' | 'tool_result';
/** The default scope: real conversation only. Tool results are excluded (their raw
 * output adds token cost and noise; the assistant message already carries the
 * interpretation — see IMPLEMENTATION.md). */
export declare const DEFAULT_MESSAGE_SCOPE: readonly MessageScope[];
/** Map a surface event type to its messageScope key (undefined = not mappable). */
export declare function scopeOfType(type: string): MessageScope | undefined;
/** Whether a messageScope list admits a surface event type. */
export declare function inScope(type: string, scope: readonly MessageScope[]): boolean;
/** Minimal structural view of a session-log event; DSH SessionEvent satisfies it. */
export interface SurfaceEventLike {
    readonly type: string;
    readonly seq: number;
    readonly data: unknown;
}
/** Whether an event type belongs to the message-producing surface set. */
export declare function isSurfaceType(type: string): type is SurfaceEventType;
/** Keep at most the trailing `max` items (most recent first by position). */
export declare function takeTail<T>(items: readonly T[], max: number): T[];
/**
 * Whether a surface event is real conversation content rather than a
 * system-injected message. Real user input is stamped `source.kind === 'user'`;
 * injections (runtime context, skill catalog, memory catalog, agent
 * instructions, goals) carry their own kinds and are excluded so boilerplate
 * never reaches the extraction model or inflates its cost. Assistant messages
 * and tool results are always conversation content.
 */
export declare function isConversationEvent(event: SurfaceEventLike): boolean;
/**
 * Whether one event belongs to extraction at all: a surface type admitted by
 * scope and, for user messages, real conversation input rather than a system
 * injection. This is the single predicate shared by the pending trigger
 * counter and the window selector, so an injection can never inflate the
 * trigger count while being excluded from the window it would schedule.
 */
export declare function countsTowardExtraction(event: SurfaceEventLike, scope: readonly MessageScope[]): boolean;
/**
 * Select the extraction window: conversation events admitted by scope with
 * seq strictly after `fromSeqExclusive`, capped to the trailing
 * `maxMessages`. Tool results are only admitted when 'tool_result' is in
 * scope (default: excluded — see DEFAULT_MESSAGE_SCOPE). Injection-origin
 * user messages (runtime context, catalogs, …) never enter the window
 * regardless of scope.
 */
export declare function selectWindow(events: readonly SurfaceEventLike[], fromSeqExclusive: number, maxMessages: number, scope?: readonly MessageScope[]): SurfaceEventLike[];
/**
 * Byte-aware truncation that never splits a UTF-8 sequence: the boundary is
 * walked back to a clean continuation start, so CJK and other multibyte text
 * stays valid (no replacement chars introduced).
 */
export declare function truncateBytes(text: string, maxBytes: number): string;
/** The message-content block list carried by an event, tolerant of both shapes. */
export declare function messageBlocksOf(data: unknown): unknown[];
/** Render one content block to its text contribution. */
export declare function blockText(block: unknown, toolResultMaxBytes: number): string | undefined;
/** Concatenate block texts, truncating per `toolResultMaxBytes`. */
export declare function renderBlocks(blocks: readonly unknown[], toolResultMaxBytes: number): string;
/** One rendered line for an event, prefixed by its role. */
export declare function renderEventText(event: SurfaceEventLike, toolResultMaxBytes: number): string;

/**
 * Rolling session digest: a bounded ~100-token summary carried between
 * extraction runs so later windows can resolve cross-window references.
 * Token length is approximated as bytes/3 (CJK 1 token, ASCII ~4 chars).
 * @module dsh-memory-lite/src/extract/digest
 */
/** Rough token-length estimate for mixed CJK/ASCII text. */
export declare function digestApproxTokens(text: string): number;
/** Shrink the digest until it fits `maxTokens` (progressive halving). */
export declare function truncateDigest(text: string, maxTokens: number): string;
/** Roll the digest forward: previous digest + this window, re-truncated. */
export declare function rollDigest(prev: string, windowText: string, maxTokens: number): string;

/**
 * Implicit extraction (Phase 2, channel B): trigger wiring and the background
 * extraction job. Event handlers only count and schedule; the LLM work runs
 * inside a ctx.jobs task, never awaited inside serial event callbacks (the
 * agent/turn-stopping contract, verified in dsh-agent-loop source).
 *
 * Model resolution: config.extraction.llm wins when set; otherwise the
 * session's current model (session.requestHeader().config) is reused.
 * @module dsh-memory-lite/src/extract
 */
import type { Context } from '@deepseek-ai/cordis';
import type { MemoryStore } from '../memory-store.js';
import type { MemoryDeps } from '../tool-utils.js';
import type { StatusTracker } from '../status.js';
import { type ExtractionDecision } from './decision.js';
import { type CheckpointFile } from './checkpoint.js';
interface ExtractionState {
    pending: number;
    lastExtractAt: number | null;
    inFlight: boolean;
    checkpoint: CheckpointFile;
    idleDispose: (() => void) | null;
    cancel: (() => void) | null;
}
/** Minimal structural view of a session the extractor reads; real Sessions satisfy it. */
export interface ExtractionSessionLike {
    readonly id: string;
    readonly header: {
        readonly cwd?: string;
        readonly origin?: 'subagent';
    };
    /** dsh-session <= 0.1.1 exposed the full log as `events`; >= 0.1.2 uses snapshotEvents(). */
    readonly events?: readonly {
        readonly type: string;
        readonly seq: number;
        readonly data: unknown;
    }[];
    snapshotEvents?(fromSeq?: number, toSeqExclusive?: number): readonly {
        readonly type: string;
        readonly seq: number;
        readonly data: unknown;
    }[];
    requestHeader(): {
        readonly config?: {
            readonly provider?: string;
            readonly model?: string;
        };
    } | undefined;
}
/** Register the extraction channel for the lifetime of `ctx`. */
export declare function applyExtraction(ctx: Context, deps: MemoryDeps, tracker: StatusTracker): void;
/** One extraction run: window -> grep -> LLM -> write -> checkpoint. */
export declare function extractOnce(session: ExtractionSessionLike, state: ExtractionState, ctx: Context, deps: MemoryDeps, signal: AbortSignal, tracker: StatusTracker): Promise<void>;
/** Apply one decision through the store (all writes go through the queue). */
export declare function applyDecision(store: MemoryStore, peer: string, decision: ExtractionDecision): Promise<string | undefined>;
/** Light keyword heuristic: frequent Latin words and CJK characters. */
export declare function extractKeywords(text: string, max: number): string[];
export {};

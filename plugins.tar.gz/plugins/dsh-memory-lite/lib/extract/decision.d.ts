/**
 * Parse the extraction LLM's structured output into a concrete memory
 * mutation decision. The model answers in JSON; the parser is tolerant of
 * code fences and prose, normalizes full-width braces/quotes, salvages
 * broken-brace JSON from key:value pairs, and rejects anything outside the
 * closed vocabulary.
 * @module dsh-memory-lite/src/extract/decision
 */
export type ExtractionDecisionKind = 'create' | 'merge' | 'update' | 'skip';
export interface CreateDecision {
    readonly kind: 'create';
    readonly category: string;
    readonly title: string;
    readonly content: string;
}
export interface PathDecision {
    readonly kind: 'merge' | 'update';
    readonly path: string;
    readonly content: string;
}
export interface SkipDecision {
    readonly kind: 'skip';
    readonly reason?: string;
}
export type ExtractionDecision = CreateDecision | PathDecision | SkipDecision;
export declare const DECISION_KINDS: readonly ExtractionDecisionKind[];
/** Extraction decisions never delete; `forget` stays a user-only tool. */
export declare const DECISION_ALLOWED: Set<string>;
/** Locate and parse the JSON object in the model's answer. */
export declare function parseDecision(text: string): ExtractionDecision;
/**
 * The first balanced `{...}` region in the answer (fence-free). When the
 * braces are broken (truncated or unbalanced output), falls back to rebuilding
 * a JSON object from `"key": "value"` pairs; throws only when neither works.
 */
export declare function extractJsonObject(text: string): string;

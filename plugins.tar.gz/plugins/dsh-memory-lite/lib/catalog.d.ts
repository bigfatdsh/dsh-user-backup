/**
 * L0 catalog rendering and session-history tracking.
 *
 * The injected message uses the OFFICIAL `plugin` source kind with the
 * `catalog` form, so a released session-format migration can classify and
 * carry it (the private `memory-catalog` kind written before 0.2.3 is still read
 * back for old sessions). The official source form carries no payload, so the
 * published state is recovered by comparing the message text itself.
 * @module dsh-memory-lite/src/catalog
 */
import type { Agent } from '@deepseek-ai/dsh-agent';
import type { UserMessage } from '@deepseek-ai/dsh-session';
import type { IndexEntry } from './types.js';
/**
 * The plugin name and source kind stamped on the catalog source:
 * `plugin:dsh-memory-lite` satisfies dsh 0.1.7 v4 producer-owned source admission
 * while remaining fully valid in dsh 0.1.5.
 */
export declare const MEMORY_CATALOG_PLUGIN = "dsh-memory-lite";
export declare const MEMORY_CATALOG_SOURCE_KIND: "plugin:dsh-memory-lite";
/** One shared-mount notice rendered into the catalog; not an index entry. */
export interface SharedMountNotice {
    readonly name: string;
    readonly peer: string;
    readonly readonly: boolean;
}
/**
 * Whether one message source is a memory catalog this plugin published.
 * Recognizes all three historical representations:
 * 1. Pre-0.2.3: { kind: 'memory-catalog' }
 * 2. 0.2.3 - 0.3.0 (v3 format): { kind: 'plugin', plugin: 'dsh-memory-lite', form: 'catalog' }
 * 3. 0.1.7+ (v4 format & v3->v4 migrated): { kind: 'plugin:dsh-memory-lite', form: 'catalog' }
 */
export declare function isMemoryCatalogSource(source: unknown): boolean;
/** The catalog message for this session's first publication. */
export declare function renderCatalogMessage(entries: readonly IndexEntry[], peer: string, sharedMounts?: readonly SharedMountNotice[], globalCharter?: string): UserMessage;
/** The catalog message when the index changed and an older catalog is still visible. */
export declare function renderCatalogUpdate(entries: readonly IndexEntry[], peer: string, sharedMounts?: readonly SharedMountNotice[], globalCharter?: string): UserMessage;
/**
 * Whether a published catalog text is still this plugin's current rendering.
 * An unchanged catalog matches whichever framing it was published with, so a
 * first publication and an update that carry the same entries and mounts both
 * count as current.
 */
export declare function isCurrentCatalogText(text: string, entries: readonly IndexEntry[], peer: string, sharedMounts?: readonly SharedMountNotice[], globalCharter?: string): boolean;
/**
 * The latest catalog message this session published, plus the text it
 * published while that message is still on the visible surface (compaction may
 * have moved it off).
 */
export declare function catalogHistory(agent: Agent): {
    published: boolean;
    visibleText?: string;
};
/** The catalog message already in the entering batch, if any. */
export declare function catalogMessage(messages: readonly UserMessage[]): {
    message: UserMessage;
    text: string;
} | undefined;

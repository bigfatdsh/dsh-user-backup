/**
 * dsh-memory-lite: lightweight Markdown-file memory for DeepSeek Harness.
 *
 * - Five model-facing tools: read_memory, search_memory, remember,
 *   update_memory, forget_memory (explicit capture only — the implicit
 *   extraction channel is Phase 2).
 * - L0 catalog injection (`agent/pre-step` waterfall): the peer's memory
 *   index is published as a durable user message and re-published when the
 *   index changes or compaction moves it off the visible surface.
 * - Peer isolation: each session's cwd derives its own memory root.
 * - All file access goes through a containment boundary; subagent sessions
 *   get no catalog and no tool access.
 *
 * Model Experience: the 5 tool schemas are injected every step; the L0
 * catalog is one durable surface message resident for the session (re-sent
 * after compaction or index changes). See README.md and IMPLEMENTATION.md.
 * @module dsh-memory-lite
 */
import type { Context } from '@deepseek-ai/cordis';
import { Config } from './config.js';
import type { MemoryConfig } from './config.js';
/** Cordis plugin name used by loader diagnostics. */
export declare const name = "dsh-memory-lite";
/** Services this plugin requires to activate: the tool registry, the agent registry,
 * the LLM stream, and the timer service (ctx.timeout for the extraction idle
 * backstop). `connection` is a web-app service and is injected optionally below, so
 * a headless profile loads the plugin (tools + extraction) without browser surfaces. */
export declare const inject: string[];
export { Config };
/** Register the memory capability for the lifetime of `ctx`. */
export declare function apply(ctx: Context, config?: MemoryConfig): void;

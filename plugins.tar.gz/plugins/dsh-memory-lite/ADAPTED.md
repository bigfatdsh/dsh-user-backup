# 本地适配说明（dsh-memory-lite 0.4.1-adapted.1）

上游：`@alanzhao/dsh-memory-lite@0.4.1`（npm）。本目录是 fork，只做最小改动，便于日后对照上游升级。

## 改了什么

1. **修复 `- -` 重复项目符号**（`lib/memory-store.js`）
   上游 `writeNewMemory` / `appendCurrent` 把模型返回的每一行无条件加 `- ` 前缀。
   模型常自带 Markdown 列表，于是记忆文件里出现 `- - 已写入…`、空行变成 `- `、
   重复行还会被当成新内容追加。
   现改为 `toCurrentBullets()`：去掉已有列表标记、丢弃空行与标题行、完全相同行去重；
   新建记忆时若整段没有可用行，回退为一行纯文本，避免写出空 `## Current`。

2. **目录摘要跟随存储格式**（`lib/memory-store.js` → `summaryOf`）
   摘要原本直接压缩模型原文，于是 L0 目录里会出现 `# 小标题`、重复行这类噪声。
   现改为用同一套 `toCurrentBullets` 归一化后再截断，目录行只含正文要点。

3. 版本号改为 `0.4.1-adapted.1`，便于和上游区分。

## 没改什么

- 工具名与参数、L0 目录注入、提取流程、设置页、schema 默认值全部保持上游行为。
- 成本相关参数（`index.maxTokens`、`extraction.llm.reasoningEffort`）不写死在代码里，
  统一在 profile 的 `cordis.patch.yml` 里覆盖 `memory-lite` 行，设置页仍可随时改。

## 生效验证

- `read_memory` / `remember` 写入的 `## Current` 只出现单层 `- ` 项目符号。
- 升级上游时：拉新版本 → 重新套用第 1 条的改动 → 改版本号 → 重新 `install_bundle`。

## 本机运行前提：依赖解析

本插件在 profile 里是以 `link:` 方式安装的（profile/node_modules/@alanzhao/dsh-memory-lite
指向本目录），Node 解析 bare import 时用的是本目录的真实路径，看不到 profile 的 node_modules。

- `@deepseek-ai/dsh-*`、`cordis` 这类 peer 由宿主注入，不用管。
- 普通依赖（如 `@deepseek-ai/schemastery`）必须在本目录可解析，否则启动时报
  `Cannot find package '@deepseek-ai/schemastery'`，表现为「1 entry did not activate」、
  记忆工具和 L0 目录全部消失。

现有做法：`node_modules/@deepseek-ai/schemastery` → 软链到
`~/.dsh/profiles/desktop/node_modules/@deepseek-ai/schemastery`（由 dsh-oil-ui 作为真实依赖带来）。
若哪天 profile 里这份被 pnpm 剪掉，重建同样的软链即可。


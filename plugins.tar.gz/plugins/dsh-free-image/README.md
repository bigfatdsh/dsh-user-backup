# dsh-free-image

AI image generation for DeepSeek Harness with no API key and no settings page. Install it, ask for a picture, get one.

## What it adds

One model-facing tool, `image_generate`:

| Parameter | Meaning |
|---|---|
| `prompt` | What to draw. A concrete visual brief works best. |
| `aspect` | `1:1` (default), `4:3`, `3:4`, `3:2`, `2:3`, `16:9`, `9:16` |
| `count` | 1–4 variations per call |
| `seed` | Reuse for closely related variations |
| `model` | `flux` / `turbo`, public backend only |

Each result is stored as a Harness attachment (so it renders in the conversation) and copied to `<workspace>/generated-images/<date>/`.

## Backends

1. **Local Stable Diffusion WebUI** — probed on `127.0.0.1:7860` once per call. Free, offline, no watermark. Uses `--api` `POST /sdapi/v1/txt2img` with 24 steps, CFG 6.5, `DPM++ 2M Karras`, and 512-class canvases. Roughly 3 minutes per 512x768 image on an 8 GB M1.
2. **Public Pollinations endpoint** — used only when no local server answers. As of October 2026 new renders there return `HTTP 402 Payment Required`; the tool reports that and points at the local backend instead of hanging.

Start the local backend with:

```bash
cd ~/stable-diffusion-webui && ./webui.sh --api --port 7860
```

## Layout

```
package.json        bundle manifest (dsh.bundle.patch)
cordis.patch.yml    inserts the free-image row
index.js            host plugin: backend detection, rendering, attachment + workspace save
locale/en.json      plugin title and description (en)
locale/zh.json      plugin title and description (zh)
icon.svg            original icon
```

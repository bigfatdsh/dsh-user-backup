/**
 * dsh-free-image — keyless AI image generation for DeepSeek Harness.
 *
 * Registers one model-facing tool, `image_generate`, and renders with whichever
 * free backend this machine actually has:
 *
 *   1. a local Stable Diffusion WebUI on 127.0.0.1:7860 (probed once per call),
 *   2. the public Pollinations endpoint as a fallback.
 *
 * Results are stored as Harness attachments so they render inside the
 * conversation, and copied into the session workspace.
 */

import { mkdir, writeFile } from 'node:fs/promises'
import { join, relative, sep } from 'node:path'

export const name = 'free-image'
export const inject = ['tools', 'attachments']

const KIND = 'dsh-free-image'
const TOOL_NAME = 'image_generate'
const ENDPOINT = 'https://image.pollinations.ai/prompt/'
const REQUEST_TIMEOUT_MS = 120_000
const MAX_PROMPT_CHARS = 1_500
const MAX_IMAGES_PER_CALL = 4
const WORKSPACE_FOLDER = 'generated-images'
const MODELS = ['flux', 'turbo']

// Local Stable Diffusion WebUI, the same contract as --api.
const SD_ENDPOINT = 'http://127.0.0.1:7860'
const SD_PROBE_TIMEOUT_MS = 1_500
const SD_TIMEOUT_MS = 900_000
const SD_STEPS = 24
const SD_CFG = 6.5
const SD_SAMPLER = 'DPM++ 2M Karras'
const SD_STYLE_SUFFIX = ', masterpiece, best quality, very aesthetic, detailed'
const SD_NEGATIVE =
  'lowres, bad anatomy, bad hands, extra fingers, fused fingers, missing arm, cropped, out of frame, worst quality, low quality, jpeg artifacts, watermark, signature, text, logo, blurry, multiple views, extra limbs'

const ASPECTS = {
  '1:1': { width: 1024, height: 1024 },
  '4:3': { width: 1152, height: 864 },
  '3:4': { width: 864, height: 1152 },
  '3:2': { width: 1216, height: 832 },
  '2:3': { width: 832, height: 1216 },
  '16:9': { width: 1280, height: 720 },
  '9:16': { width: 720, height: 1280 },
}

// A diffusion model trained at 512 needs smaller canvases than a hosted API.
const SD_SIZES = {
  '1:1': { width: 512, height: 512 },
  '4:3': { width: 640, height: 512 },
  '3:4': { width: 512, height: 640 },
  '3:2': { width: 768, height: 512 },
  '2:3': { width: 512, height: 768 },
  '16:9': { width: 912, height: 512 },
  '9:16': { width: 512, height: 912 },
}

const EXTENSIONS = {
  'image/png': 'png',
  'image/jpeg': 'jpg',
  'image/webp': 'webp',
  'image/gif': 'gif',
}

const RETRYABLE_STATUS = new Set([408, 425, 429, 500, 502, 503, 504])

const PARAMETERS = {
  type: 'object',
  additionalProperties: false,
  required: ['prompt'],
  properties: {
    prompt: {
      type: 'string',
      description:
        'What to draw. Write a concrete visual brief: subject, setting, style, lighting, colors, camera or medium. The local model answers English tags best.',
    },
    aspect: {
      type: 'string',
      enum: Object.keys(ASPECTS),
      default: '1:1',
      description: 'Aspect ratio of the result; default 1:1. Use 2:3 or 9:16 for full-body character art.',
    },
    count: {
      type: 'integer',
      enum: [1, 2, 3, 4],
      default: 1,
      description: 'How many variations to render in one call; default 1. On the local backend each variation takes minutes, so keep it at 1 unless the user asks for options.',
    },
    seed: {
      type: 'integer',
      description: 'Optional random seed. Reuse the same seed with a tweaked prompt for a closely related image; omit for a fresh roll.',
    },
    model: {
      type: 'string',
      enum: MODELS,
      default: 'flux',
      description: 'Model for the public fallback backend; ignored when the local Stable Diffusion WebUI is running.',
    },
  },
}

const OUTPUT_SCHEMA = {
  type: 'object',
  additionalProperties: true,
  required: ['prompt', 'aspect', 'backend', 'images'],
  properties: {
    prompt: { type: 'string' },
    backend: { type: 'string' },
    model: { type: 'string' },
    aspect: { type: 'string' },
    images: {
      type: 'array',
      items: {
        type: 'object',
        additionalProperties: true,
        required: ['attachment', 'mediaType', 'width', 'height', 'bytes'],
        properties: {
          attachment: { type: 'object', additionalProperties: true },
          path: { type: 'string' },
          mediaType: { type: 'string' },
          width: { type: 'number' },
          height: { type: 'number' },
          bytes: { type: 'number' },
          seed: { type: 'number' },
          saveError: { type: 'string' },
        },
      },
    },
  },
}

function resolveLayout(raw) {
  const key = typeof raw === 'string' && ASPECTS[raw] !== undefined ? raw : '1:1'
  return { aspect: key, ...ASPECTS[key], sd: SD_SIZES[key] }
}

function clampCount(raw) {
  const value = Number(raw)
  if (!Number.isInteger(value)) return 1
  return Math.min(MAX_IMAGES_PER_CALL, Math.max(1, value))
}

/** Magic-byte sniffing: a service's content type is only a hint. */
function detectMediaType(bytes) {
  if (
    bytes.length >= 8 &&
    bytes[0] === 0x89 && bytes[1] === 0x50 && bytes[2] === 0x4e && bytes[3] === 0x47 &&
    bytes[4] === 0x0d && bytes[5] === 0x0a && bytes[6] === 0x1a && bytes[7] === 0x0a
  ) {
    return 'image/png'
  }
  if (bytes.length >= 3 && bytes[0] === 0xff && bytes[1] === 0xd8 && bytes[2] === 0xff) {
    return 'image/jpeg'
  }
  if (
    bytes.length >= 12 &&
    bytes[0] === 0x52 && bytes[1] === 0x49 && bytes[2] === 0x46 && bytes[3] === 0x46 &&
    bytes[8] === 0x57 && bytes[9] === 0x45 && bytes[10] === 0x42 && bytes[11] === 0x50
  ) {
    return 'image/webp'
  }
  if (
    bytes.length >= 6 &&
    bytes[0] === 0x47 && bytes[1] === 0x49 && bytes[2] === 0x46 && bytes[3] === 0x38 &&
    (bytes[4] === 0x37 || bytes[4] === 0x39) && bytes[5] === 0x61
  ) {
    return 'image/gif'
  }
  return undefined
}

function buildUrl({ prompt, width, height, model, seed }) {
  const url = new URL(ENDPOINT + encodeURIComponent(prompt))
  url.searchParams.set('width', String(width))
  url.searchParams.set('height', String(height))
  url.searchParams.set('model', model)
  url.searchParams.set('nologo', 'true')
  url.searchParams.set('referrer', 'dsh-free-image')
  if (seed !== undefined) url.searchParams.set('seed', String(seed))
  return url
}

function delay(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms))
}

/** Is a local Stable Diffusion WebUI answering on its default port? */
async function detectLocal(signal) {
  try {
    const response = await fetch(`${SD_ENDPOINT}/sdapi/v1/options`, {
      signal: AbortSignal.any([signal, AbortSignal.timeout(SD_PROBE_TIMEOUT_MS)]),
    })
    if (!response.ok) return undefined
    const options = await response.json().catch(() => ({}))
    const model = typeof options?.sd_model_checkpoint === 'string' ? options.sd_model_checkpoint : 'local checkpoint'
    return { endpoint: SD_ENDPOINT, model }
  } catch {
    return undefined
  }
}

function abortable(outerSignal, timeoutMs) {
  return AbortSignal.any([outerSignal, AbortSignal.timeout(timeoutMs)])
}

/** Render one image on the local Stable Diffusion WebUI. */
async function renderLocal({ prompt, layout, seed, signal, local }) {
  const size = layout.sd
  const body = {
    prompt: prompt + SD_STYLE_SUFFIX,
    negative_prompt: SD_NEGATIVE,
    steps: SD_STEPS,
    cfg_scale: SD_CFG,
    sampler_name: SD_SAMPLER,
    width: size.width,
    height: size.height,
    batch_size: 1,
    n_iter: 1,
    ...(seed === undefined ? {} : { seed }),
  }

  let payload
  try {
    const response = await fetch(`${local.endpoint}/sdapi/v1/txt2img`, {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify(body),
      signal: abortable(signal, SD_TIMEOUT_MS),
    })
    if (!response.ok) {
      const detail = (await response.text().catch(() => '')).slice(0, 300).trim()
      throw new Error(`local Stable Diffusion answered HTTP ${String(response.status)}${detail === '' ? '' : `: ${detail}`}`)
    }
    payload = await response.json()
  } catch (error) {
    if (signal.aborted) throw new Error('image generation was cancelled')
    const name = error instanceof Error ? error.name : ''
    if (name === 'TimeoutError' || name === 'AbortError') {
      throw new Error(`local Stable Diffusion did not finish within ${String(Math.round(SD_TIMEOUT_MS / 60_000))} minutes`)
    }
    throw error instanceof Error ? error : new Error(String(error))
  }

  const encoded = Array.isArray(payload?.images) ? payload.images[0] : undefined
  if (typeof encoded !== 'string' || encoded.length === 0) {
    throw new Error('local Stable Diffusion returned no image')
  }
  const base64 = encoded.includes(',') ? encoded.slice(encoded.indexOf(',') + 1) : encoded
  return {
    data: new Uint8Array(Buffer.from(base64, 'base64')),
    mediaType: 'image/png',
    width: size.width,
    height: size.height,
    backend: 'local-stable-diffusion',
    model: local.model,
  }
}

/** Render one image on the public anonymous endpoint. */
async function renderPublic(options, signal) {
  const url = buildUrl(options)
  let lastError

  for (let attempt = 1; attempt <= 3; attempt += 1) {
    try {
      const response = await fetch(url, {
        signal: abortable(signal, REQUEST_TIMEOUT_MS),
        headers: { accept: 'image/*' },
      })

      if (response.status === 402) {
        throw new Error(
          'the free public image service now requires payment (HTTP 402). Start the local Stable Diffusion WebUI and retry: the tool detects it on 127.0.0.1:7860 automatically',
        )
      }

      if (!response.ok) {
        const detail = (await response.text().catch(() => '')).slice(0, 300).trim()
        const failure = new Error(
          `image service returned HTTP ${String(response.status)}${detail === '' ? '' : `: ${detail}`}`,
        )
        if (RETRYABLE_STATUS.has(response.status) && attempt < 3) {
          lastError = failure
          await delay(1_200 * attempt)
          continue
        }
        throw failure
      }

      const contentType = (response.headers.get('content-type') ?? '').toLowerCase()
      if (contentType.startsWith('text/') || contentType.includes('json')) {
        const detail = (await response.text().catch(() => '')).slice(0, 300).trim()
        throw new Error(
          `image service answered with ${contentType === '' ? 'text' : contentType} instead of an image${detail === '' ? '' : `: ${detail}`}`,
        )
      }

      const bytes = new Uint8Array(await response.arrayBuffer())
      if (bytes.byteLength === 0) throw new Error('image service returned an empty response')
      return {
        data: bytes,
        mediaType: detectMediaType(bytes),
        width: options.width,
        height: options.height,
        backend: 'public',
        model: options.model,
      }
    } catch (error) {
      if (signal.aborted) throw new Error('image generation was cancelled')
      if (error instanceof Error && /HTTP 402/.test(error.message)) throw error
      const name = error instanceof Error ? error.name : ''
      if (name === 'TimeoutError' || name === 'AbortError') {
        throw new Error(`image generation timed out after ${String(Math.round(REQUEST_TIMEOUT_MS / 1000))}s; the public service may be busy`)
      }
      lastError = error
      if (attempt === 3) break
      await delay(1_200 * attempt)
    }
  }

  const reason = lastError instanceof Error ? lastError.message : String(lastError)
  throw new Error(`image generation failed: ${reason}`)
}

function slugify(prompt) {
  const slug = prompt
    .toLowerCase()
    .slice(0, 40)
    .replace(/[^\p{L}\p{N}]+/gu, '-')
    .replace(/^-+|-+$/g, '')
  return slug === '' ? 'image' : slug
}

function stamp() {
  const now = new Date()
  const pad = (value) => String(value).padStart(2, '0')
  return {
    date: `${String(now.getFullYear())}-${pad(now.getMonth() + 1)}-${pad(now.getDate())}`,
    time: `${pad(now.getHours())}${pad(now.getMinutes())}${pad(now.getSeconds())}`,
  }
}

/** Copy the rendered bytes into the session workspace so they outlive the chat. */
async function saveToWorkspace({ cwd, data, mediaType, prompt, index, unique }) {
  const at = stamp()
  const directory = join(cwd, WORKSPACE_FOLDER, at.date)
  await mkdir(directory, { recursive: true })
  const suffix = EXTENSIONS[mediaType] ?? 'png'
  const file = join(directory, `${slugify(prompt)}-${at.time}-${String(index + 1)}-${unique}.${suffix}`)
  await writeFile(file, data)
  return relative(cwd, file).split(sep).join('/')
}

function attachmentMeta(ref) {
  return {
    attachmentId: String(ref.attachmentId),
    mediaType: ref.mediaType,
    bytes: ref.bytes,
    width: ref.width,
    height: ref.height,
    ...(ref.name === undefined ? {} : { name: ref.name }),
  }
}

export function apply(ctx, _config) {
  const dispose = ctx.tools.register({
    name: TOOL_NAME,
    description:
      'Draw a new picture with AI and show it to the user. Use it whenever the user asks for an image, illustration, poster, icon, photo, artwork, wallpaper or character art to be created rather than described. Needs no API key. With the local Stable Diffusion backend one picture takes a few minutes; say so before calling it when the user expects a fast answer. The tool displays each result in the conversation and saves a copy under generated-images/ in the workspace.',
    parameters: PARAMETERS,
    timeoutMs: SD_TIMEOUT_MS + 60_000,
    output: {
      schema: OUTPUT_SCHEMA,
      render: (_args, value) => {
        const lines = value.images.map((image, index) => {
          const location = image.path === undefined ? 'not saved to the workspace' : `saved as ${image.path}`
          return `Variation ${String(index + 1)}: ${String(image.width)}x${String(image.height)} ${image.mediaType}, ${location}.`
        })
        return [
          {
            type: 'text',
            text: [
              `Rendered ${String(value.images.length)} image(s) with ${value.model} (${value.backend}) at ${value.aspect}.`,
              ...lines,
              'The images are already attached to the conversation and visible to the user. Do not re-read, describe, or re-create them; refer to the saved path if the user needs the file.',
            ].join('\n'),
          },
        ]
      },
      presentationMeta: (_args, value) => ({
        kind: KIND,
        prompt: value.prompt,
        model: value.model,
        backend: value.backend,
        images: value.images.map((image) => ({
          ...attachmentMeta(image.attachment),
          ...(image.path === undefined ? {} : { path: image.path }),
        })),
      }),
    },
    presentResult: (_args, result) => {
      const meta = result.meta
      if (typeof meta !== 'object' || meta === null || Array.isArray(meta)) return undefined
      if (meta.kind !== KIND || !Array.isArray(meta.images)) return undefined
      const content = meta.images.flatMap((image) =>
        typeof image === 'object' && image !== null && typeof image.attachmentId === 'string'
          ? [{
              type: 'image',
              attachment: {
                attachmentId: image.attachmentId,
                mediaType: image.mediaType,
                bytes: image.bytes,
                width: image.width,
                height: image.height,
                ...(typeof image.name === 'string' ? { name: image.name } : {}),
              },
            }]
          : [],
      )
      if (content.length === 0) return undefined
      return { card: 'generic', title: 'AI image', content }
    },
    async execute(args, exec) {
      const prompt = typeof args?.prompt === 'string' ? args.prompt.trim() : ''
      if (prompt === '') throw new Error('image_generate needs a non-empty prompt')
      if (prompt.length > MAX_PROMPT_CHARS) {
        throw new Error(`prompt is too long (${String(prompt.length)} characters, limit ${String(MAX_PROMPT_CHARS)})`)
      }

      const count = clampCount(args?.count)
      const layout = resolveLayout(args?.aspect)
      const publicModel = MODELS.includes(args?.model) ? args.model : 'flux'
      // Variations must not collide on the public service's prompt cache, so a
      // multi-image call gets its own random base seed unless the caller pinned one.
      const baseSeed = Number.isInteger(args?.seed)
        ? args.seed
        : count > 1
          ? Math.floor(Math.random() * 1_000_000_000)
          : undefined
      const mediaTypes = ctx.attachments.imageLimits.mediaTypes
      const workspace = exec.agent?.session.header.cwd
      const unique = Math.random().toString(36).slice(2, 8)
      const local = await detectLocal(exec.signal)
      const images = []

      for (let index = 0; index < count; index += 1) {
        exec.signal.throwIfAborted()
        const seed = baseSeed === undefined ? undefined : baseSeed + index
        const rendered = local === undefined
          ? await renderPublic(
              { prompt, width: layout.width, height: layout.height, model: publicModel, seed },
              exec.signal,
            )
          : await renderLocal({ prompt, layout, seed, signal: exec.signal, local })

        const mediaType = rendered.mediaType ?? detectMediaType(rendered.data)
        if (mediaType === undefined) throw new Error('image backend returned an unrecognized image format')
        if (!mediaTypes.includes(mediaType)) {
          throw new Error(`this DeepSeek Harness deployment does not accept ${mediaType} images`)
        }
        if (rendered.data.byteLength > ctx.attachments.imageLimits.maxImageBytes) {
          throw new Error(`rendered image is larger than the deployment limit of ${String(ctx.attachments.imageLimits.maxImageBytes)} bytes`)
        }

        const attachment = await ctx.attachments.saveImage({
          data: rendered.data,
          mediaType,
          name: `${slugify(prompt)}-${String(index + 1)}`,
        })

        const image = {
          attachment,
          mediaType,
          width: attachment.width,
          height: attachment.height,
          bytes: attachment.bytes,
          ...(seed === undefined ? {} : { seed }),
        }

        if (workspace !== undefined) {
          try {
            image.path = await saveToWorkspace({
              cwd: workspace,
              data: rendered.data,
              mediaType,
              prompt,
              index,
              unique,
            })
          } catch (error) {
            image.saveError = error instanceof Error ? error.message : String(error)
            ctx.logger?.warn(`free-image: could not save to workspace: ${image.saveError}`)
          }
        }

        images.push(image)
      }

      return {
        prompt,
        backend: local === undefined ? 'public' : 'local-stable-diffusion',
        model: local === undefined ? publicModel : local.model,
        aspect: layout.aspect,
        width: images[0]?.width ?? layout.width,
        height: images[0]?.height ?? layout.height,
        images,
      }
    },
  })

  return dispose
}

# dsh-wechat-media-turbo

> 给 `dsh-wechat-media` 的微信聊天层：**鲸鱼娘·大肥鱼**人设 + 接梗规则 + 精简工具集 + 短回复约定。

这个包本身不含运行时代码，只提供一个 Cordis 组合层（bundle）：

1. 注册 agent preset `whale-lean`（基于标准 preset 改造）；
2. 把 `wechat-media` 行挂到 `whale-lean` 上。

## 改了什么

| 项目 | 标准 preset | whale-lean |
|---|---|---|
| 人设 | `You are a coding agent...` | 鲸鱼娘·大肥鱼（语气 + 接梗 + 心声 + 硬规则） |
| 工具行 | 22 | 14 |
| 技能目录 / skill 工具 | 有 | 移除（微信闲聊用不上，省掉大段 catalog） |
| 子 agent / workflow | 有 | 移除（schema 大，微信场景少用） |
| goal 工具 | 有 | 移除 |
| present（GUI 专用） | 有 | 移除 |
| 回复约定 | 无 | 先结论后吐槽；闲聊 ≤60 字；闲聊不调工具；不输出标题/表格 |

保留：文件读写与搜索、bash/pwsh、后台任务、定时任务、web 搜索、todo、ask_user、计划模式、上下文压缩。微信桥自己的发送文件 / 发图工具不受影响。

## 安装

已在 `desktop` profile 上安装为 bundle。重新安装：

```
plugin_manager install_bundle target=file:<abs>/dsh-wechat-media-turbo-0.1.0.tgz
```

安装后 **重启 DSH**（或让桥开新会话）才会用新 preset：preset 在 agent 创建时挂载，已存在的微信会话保持原来的 `standard`。

## 回退

`plugin_manager remove_bundle target=dsh-wechat-media-turbo`，重启即可。这个包不改 `dsh-wechat-media` 的任何文件，只覆盖它的组合层配置。

## 限制

- 覆盖 `wechat-media` 行 config 时整段替换，因此这里显式保留了 `baseUrl` / `botType`；升级 `dsh-wechat-media` 若新增 config 字段，需要同步加进 `cordis.patch.yml`。
- 人设/接梗质量取决于所配模型；实测数据见仓库外的 `REPORT.md`（本机 `dsh-wechat-media-turbo/REPORT.md`）。

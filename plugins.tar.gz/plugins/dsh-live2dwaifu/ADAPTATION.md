# dsh-live2dwaifu 适配记录（desktop profile）

上游：`dsh-live2dwaifu@2.3.0`（作者 FujiwaraReisen，MIT）。
本目录是**改过的源码**，以 `link:` 方式装进 `~/.dsh/profiles/desktop`，
所以 `~/.dsh/profiles/desktop/node_modules/dsh-live2dwaifu` 是软链，改这里即刻生效。

## 装法

```bash
# 已安装完成，记录备查：
plugin_manager install_bundle target="link:/Users/yangletian/Documents/deepseek-harness/default-workspace/adapted/dsh-live2dwaifu"
```

宿主代码改动后不用重启 App：`plugin_manager set_bundle(dsh-live2dwaifu, enabled=false)` 再 `true`
会重新加载模块（实测路由随开关出现/消失）。**客户端半区（`lib/client.js`、`assets/`）要刷新页面**才会换新。

## 改了什么

### 1. 路径不再写死（`lib/index.js` 顶部）

| 之前 | 现在 |
|---|---|
| `~/.dsh/dsh-live2d` | `$DSH_HOME/dsh-live2d`（`DSH_HOME` 缺省才回到 `~/.dsh`） |
| `~/.dsh/profiles/desktop/node_modules/dsh-meme/memes` | `$DSH_PROFILE_DIR/...`，可用 `DSH_MEMES_ROOT` 覆盖 |

原来是硬编码 `desktop`，换 profile（web / bili-duty）或换 DSH_HOME 就找不到图库。

### 2. 静态资源：缓存 / ETag / 304 / 预压缩（`sendFile`）

之前**所有**文件都是 `cache-control: no-store`，连 1.9MB 的 `viewer.js`、1.7MB 的贴图都每次重下。

现在：

| 资源 | cache-control |
|---|---|
| `/assets/*`（引擎、页面） | `no-cache` + ETag 复核（304 只要几百字节），改完刷新即生效 |
| `/model/*`（贴图、moc3、动作） | `no-cache` + ETag，重新导入模型立刻可见 |
| `/ownmeme` `/media`（表情包） | `public, max-age=86400, stale-while-revalidate=604800` |
| 页面（`/viewer` `/chat` `/corpus` `/persona` `/tone`） | `no-cache` + ETag 复核，改版立刻生效 |

`viewer.html` 里的两处引擎引用还带了 `?v=2.3.0-3` 版本号；改 `assets/viewer.js` 后
**把 `viewer.html` 和 `lib/client.js` 里的 `?v=` 一起 +1** 就能绕过任何中间缓存。

- 每个响应带 `ETag`（size + mtime），`If-None-Match` 命中回 `304`（贴图不再重传）。
- 每个响应带 `Content-Length`（之前没有，浏览器只能靠分块猜）。
- `Accept-Encoding: gzip` 且存在同名 `.gz` 且不比源文件旧 → 直接发 `.gz`，**零运行时压缩开销**：
  `viewer.js 1865KB → 383KB`，`live2dcubismcore.min.js 202KB → 60KB`。

`.gz` 由 `node tools/precompress.mjs` 生成（已随包附带）。上游升级覆盖 `assets/` 后要重跑一次。

### 3. 请求体与写盘

- `readBody` 上限 `512MB → 64MB`（导入贴图最大也就几 MB，512MB 只是给自己挖坑）。
- `writeConfig` / `writeChat` / `writeCorpus` / `meta.json` 改成 `writeAtomic()`：先写 `.tmp-<pid>-<ts>` 再 `rename`，进程被杀不会留下半截 JSON 把整只桌宠读崩。

### 4. 客户端（`lib/client.js`）

- **轮询改成自适应**：原来固定 `setInterval(2500)` 一直打 `/api/poll`。
  现在收到消息后 30 秒内 2.5s 一次，之后 15s 一次；页面隐藏时 60s 一次，切回来立刻补一次。
- **Live2D 引擎延后挂载**：卡片先出，`requestIdleCallback`（上限 1.2s）后才插 `iframe`，
  不再和 DSH 首屏抢带宽/主线程。
- 卡片定位与层级改成 CSS 变量：`--dsh-l2d-right` / `--dsh-l2d-bottom` / `--dsh-l2d-z`（默认 18px/18px/9000），
  需要给别的悬浮物让位时不用改代码。

### 5. 渲染器（`assets/viewer.js`）

- **取景改成「整只模型装进卡片」**（原来的 `fit()` 是 `h*0.98/(h0*0.36)`：只把 36% 高的上半身塞满卡片，
  全身模型会被裁掉），并且按**实际绘制范围**（遍历 drawable 顶点、跳过透明度 0 的部件、求包围盒）取景，
  画布上下留白不会让人物变小；量不到范围（比如顶点还没算出来）就退回整张画布，400ms 后再量一次。
- **修掉 `app.renderer.width/height` 的 DPR 坑**：那是设备像素（`screen × resolution`），
  拿来算布局会让模型按 2 倍放大并整体偏右——就是「错位、只剩半个身子」的元凶。现在统一用
  `app.screen.width/height`（CSS 逻辑像素）。点击分区（戳头/腰/腿）的判定同样改成 `app.screen.height`。
- `resolution: min(devicePixelRatio, 2)` + `autoDensity` —— 之前按 1 渲染，Retina 上发虚。
- `app.ticker.maxFPS = 30` —— 聊天框大小的卡片，30fps 看不出差别，CPU 直接减半。
- `visibilitychange` 时 `app.stop()/start()` —— 页面在后台不再空转。浏览器自己也会节流，这是兜底。

### 6. 清理

- 删掉 0 字节且无人引用的 `assets/_em_module.wasm`（Cubism 的 em 模块残留）。
- `viewer.html` 给两个脚本加 `preload`，并行下载而不是排队。

## 模型

插件本身**不带模型**（上游设计如此）。这里放进了生态里已有的 **DS鲸鱼娘**（Cubism 4，moc3 v4）：

```
~/.dsh/dsh-live2d/models/ds-whale-girl/   # 8 动作 / 44 表情
~/.dsh/dsh-live2d/config.json             # {"selected":"ds-whale-girl"}
```

- 许可：**CC BY-NC-SA 4.0**（署名 · 非商业 · 相同方式共享）。
  角色原作 上善无形，DeepSeek 女仆二创 ZipZipPipe，模型 氵六青。`LICENSE` / `README.md` 原样保留。
- `meta.json` 里写了名字、模型入口、44 个表情和一段人设（可在卡片「✎ 人设卡」里改）。

## 验证

```bash
# 服务活着
curl -s http://127.0.0.1:51302/dsh-live2d/api/models

# 缓存头 / 304 / gzip
curl -sI -H 'accept-encoding: gzip' http://127.0.0.1:51302/dsh-live2d/assets/viewer.js
curl -s -o /dev/null -w '%{http_code}\n' -H 'if-none-match: "<上面的 etag>"' http://127.0.0.1:51302/dsh-live2d/assets/viewer.js   # 304

# 端到端：她会不会说话（花一次模型额度）
curl -s -X POST -H 'content-type: application/json' -d '{"id":"ds-whale-girl","text":"在吗"}' \
  http://127.0.0.1:51302/dsh-live2d/api/chat
```

实测：`/api/models` 200、`viewer.js` gzip 392165B、`If-None-Match` 回 304、
`/api/chat` 1.1s 回 `"在。你说。"`、`/api/push` → `/api/poll` 能收到。

脱离主进程的静态服务测试：`node test/server.mjs`（127.0.0.1:51999）。

## 已知边界

- 客户端半区改动要刷新页面；宿主半区用 `set_bundle` 开关即可重载。
- 这是桌面 profile 里第四个「右下角悬浮物」（`dsh-pet` / `dsh-whale-widget` / `dsh-orb` / 本插件），
  位置会互相压。卡片本身可拖动并记位置，`⌄` 可收起成一条；再不行用 CSS 变量挪。
- `/dsh-live2d/*` 走 webServer 的裸路由，不带 DSH 页面那层鉴权（与上游一致），
  仅绑定 127.0.0.1 时可接受；若将来对外暴露端口，需要自行加一层。
- 主动开口默认 30 分钟一次（`proactiveInterval`），会在后台花模型额度；不想花钱在 ⚙ 里关掉或设 0。

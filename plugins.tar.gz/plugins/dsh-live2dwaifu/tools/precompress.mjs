#!/usr/bin/env node
/**
 * 给 assets/ 里的文本资源生成同名 .gz。
 * 运行时 sendFile() 看到兄弟 .gz 且不比源文件旧，就直接发 gzip 版本：
 * 首屏少传一个 MB，且每次请求零压缩开销。
 *
 * 用法：node tools/precompress.mjs
 * 升级插件后（npm 包覆盖了 assets/）需要重跑一次。
 */
import { readdirSync, statSync, createReadStream, createWriteStream } from 'node:fs';
import { join, extname, resolve, dirname } from 'node:path';
import { createGzip } from 'node:zlib';
import { pipeline } from 'node:stream/promises';
import { fileURLToPath } from 'node:url';

const HERE = dirname(fileURLToPath(import.meta.url));
const ASSETS = resolve(HERE, '..', 'assets');
const WANT = new Set(['.js', '.mjs', '.json', '.html', '.css', '.svg', '.txt']);
const MIN_BYTES = 1024;

async function walk(dir, depth = 0) {
  let count = 0;
  for (const e of readdirSync(dir, { withFileTypes: true })) {
    const p = join(dir, e.name);
    if (e.isDirectory()) {
      if (depth < 2) count += await walk(p, depth + 1);
      continue;
    }
    if (!WANT.has(extname(e.name).toLowerCase())) continue;
    const st = statSync(p);
    if (!st.isFile() || st.size < MIN_BYTES) continue;
    const out = p + '.gz';
    await pipeline(createReadStream(p), createGzip({ level: 9 }), createWriteStream(out));
    const gz = statSync(out);
    console.log(`${p.replace(ASSETS + '/', '')}  ${(st.size / 1024).toFixed(0)}KB -> ${(gz.size / 1024).toFixed(0)}KB`);
    count += 1;
  }
  return count;
}

console.log(`precompressing ${ASSETS}`);
const n = await walk(ASSETS);
console.log(`done: ${n} files`);

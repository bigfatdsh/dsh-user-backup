/**
 * 脱离 DSH 主进程，把插件的 webServer handler 挂到一个裸 http 服务器上，
 * 用来验证静态资源缓存/压缩/304 行为。
 *
 *   node test/server.mjs            # 监听 127.0.0.1:51999
 */
import http from 'node:http';
import { apply } from '../lib/index.js';

let handler = null;
const ctx = {
  effect(fn) {
    return fn();
  },
  get() {
    return null;
  },
  logger: { warn() {}, info() {}, debug() {} },
  webServer: {
    register(opts) {
      handler = opts.handler;
      return () => {};
    },
  },
};

apply(ctx);
if (!handler) throw new Error('handler not registered');

const server = http.createServer((req, res) => {
  Promise.resolve(handler(req, res)).catch((e) => {
    if (!res.headersSent) {
      res.writeHead(500, { 'content-type': 'text/plain' });
    }
    res.end(String(e));
  });
});
server.listen(51999, '127.0.0.1', () => console.log('test server on http://127.0.0.1:51999'));

/**
 * 测试用假 A1111：只实现桥真正用到的 /sdapi/v1 端点。
 * 返回固定 PNG，不跑模型，用来验证协议、落盘、参数拼装。
 */
import http from 'node:http'
import zlib from 'node:zlib'
import crypto from 'node:crypto'

function crc32(buffer) {
  let crc = 0xffffffff
  for (const byte of buffer) {
    crc ^= byte
    for (let i = 0; i < 8; i += 1) crc = (crc >>> 1) ^ (0xedb88320 & -(crc & 1))
  }
  return (crc ^ 0xffffffff) >>> 0
}

function chunk(type, data) {
  const length = Buffer.alloc(4)
  length.writeUInt32BE(data.length)
  const body = Buffer.concat([Buffer.from(type, 'latin1'), data])
  const crc = Buffer.alloc(4)
  crc.writeUInt32BE(crc32(body))
  return Buffer.concat([length, body, crc])
}

export function makePng(width = 64, height = 64, rgb = [90, 140, 220]) {
  const raw = Buffer.alloc((width * 3 + 1) * height)
  for (let y = 0; y < height; y += 1) {
    const row = y * (width * 3 + 1)
    for (let x = 0; x < width; x += 1) {
      const at = row + 1 + x * 3
      raw[at] = rgb[0]
      raw[at + 1] = rgb[1]
      raw[at + 2] = rgb[2]
    }
  }
  const ihdr = Buffer.alloc(13)
  ihdr.writeUInt32BE(width, 0)
  ihdr.writeUInt32BE(height, 4)
  ihdr[8] = 8
  ihdr[9] = 2
  return Buffer.concat([
    Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]),
    chunk('IHDR', ihdr),
    chunk('IDAT', zlib.deflateSync(raw)),
    chunk('IEND', Buffer.alloc(0)),
  ])
}

const PNG_BASE64 = makePng().toString('base64')

function readBody(req) {
  return new Promise((resolve, reject) => {
    const chunks = []
    req.on('data', (d) => chunks.push(d))
    req.on('end', () => resolve(Buffer.concat(chunks)))
    req.on('error', reject)
  })
}

export async function createMockSd({ width = 64, height = 64, fail = false } = {}) {
  const calls = { txt2img: 0, img2img: 0, models: 0, options: 0, progress: 0 }
  const lastPayload = {}
  const server = http.createServer(async (req, res) => {
    const url = new URL(req.url, 'http://127.0.0.1')
    const json = (status, payload) => {
      res.writeHead(status, { 'Content-Type': 'application/json' })
      res.end(JSON.stringify(payload))
    }
    if (url.pathname === '/sdapi/v1/options') {
      calls.options += 1
      return json(200, { sd_model_checkpoint: 'mock-model.safetensors [abc123]' })
    }
    if (url.pathname === '/sdapi/v1/memory') return json(200, { devices: [{ name: 'mps' }] })
    if (url.pathname === '/sdapi/v1/progress') {
      calls.progress += 1
      return json(200, { progress: 0, eta_relative: 0 })
    }
    if (url.pathname === '/sdapi/v1/sd-models') {
      calls.models += 1
      return json(200, [{ title: 'mock-model.safetensors [abc123]', model_name: 'mock-model' }])
    }
    if (url.pathname === '/sdapi/v1/loras') return json(200, [{ name: 'lcm-lora-sdv1-5', alias: 'lcm' }])
    if (url.pathname === '/sdapi/v1/samplers') return json(200, [{ name: 'DPM++ 2M Karras' }, { name: 'LCM' }])
    if (url.pathname === '/sdapi/v1/sd-vae') return json(200, [{ model_name: 'vae-ft-mse' }])
    if (url.pathname === '/sdapi/v1/txt2img' || url.pathname === '/sdapi/v1/img2img') {
      const body = JSON.parse((await readBody(req)).toString('utf8') || '{}')
      if (url.pathname.endsWith('txt2img')) calls.txt2img += 1
      else calls.img2img += 1
      lastPayload[url.pathname.endsWith('txt2img') ? 'txt2img' : 'img2img'] = body
      if (fail) return json(500, { error: 'mock failure', detail: 'boom' })
      const count = Math.max(1, Math.min(4, Number(body.n_iter) || 1))
      return json(200, {
        images: Array.from({ length: count }, () => PNG_BASE64),
        info: JSON.stringify({ sd_model_name: 'mock-model', seed: body.seed, steps: body.steps }),
      })
    }
    return json(404, { detail: `mock: ${url.pathname}` })
  })
  await new Promise((resolve) => server.listen(0, '127.0.0.1', resolve))
  const { port } = server.address()
  return {
    url: `http://127.0.0.1:${port}`,
    calls,
    lastPayload,
    close: () => new Promise((resolve) => {
      server.closeAllConnections?.()
      server.close(() => resolve())
    }),
  }
}

/**
 * dsh-sd-bridge-mac 自测（不依赖真实 SD）：
 *   node test/run.mjs          # 单元 + 假 A1111
 *   node test/run.mjs --real   # 额外打真实 127.0.0.1:7860（慢，约 1 分钟）
 */
import assert from 'node:assert/strict'
import { mkdtemp, rm, writeFile } from 'node:fs/promises'
import { existsSync } from 'node:fs'
import os from 'node:os'
import path from 'node:path'

import { apply, __internal } from '../index.js'
import { buildPositive, buildNegative, normalizeLoras, loraTags } from '../lib/prompt.js'
import { maskFromBox } from '../lib/mask.js'
import { imageInfo, calcSize } from '../lib/util.js'
import { assertLocalUrl } from '../lib/sdclient.js'
import { createMockSd, makePng } from './mock-sd.mjs'

const results = []
const dirs = []
const real = process.argv.includes('--real')

async function tempDir() {
  const dir = await mkdtemp(path.join(os.tmpdir(), 'sd-bridge-'))
  dirs.push(dir)
  return dir
}

async function test(name, fn, timeoutMs = 30000) {
  const started = Date.now()
  let timer = null
  try {
    await Promise.race([
      fn(),
      new Promise((_, reject) => {
        timer = setTimeout(() => reject(new Error(`超时（${timeoutMs}ms）`)), timeoutMs)
      }),
    ])
    results.push({ name, ok: true })
    console.log(`✔ ${name} (${Date.now() - started}ms)`)
  } catch (error) {
    results.push({ name, ok: false, error })
    console.log(`✖ ${name} (${Date.now() - started}ms)`)
    console.log(`  ${error?.message ?? error}`)
  } finally {
    if (timer !== null) clearTimeout(timer)
  }
}

function makeCtx() {
  const tools = new Map()
  const sections = []
  return {
    tools: {
      register(definition) {
        if (tools.has(definition.name)) throw new Error(`重复工具 ${definition.name}`)
        tools.set(definition.name, definition)
        return () => tools.delete(definition.name)
      },
      get: (name) => tools.get(name),
    },
    get(name) {
      if (name === 'systemPrompt') return { section: (section) => sections.push(section) }
      return undefined
    },
    effect: (fn) => {
      fn()
    },
    toolsMap: tools,
    sections,
  }
}

// ── 单元 ─────────────────────────────────────────────────────────────
await test('尺寸/画幅：64 对齐，比例正确', () => {
  assert.deepEqual(calcSize('1:1', 512), { width: 512, height: 512 })
  const wide = calcSize('16:9', 512)
  assert.ok(wide.width > wide.height)
  assert.equal(wide.width % 64, 0)
  assert.equal(wide.height % 64, 0)
})

await test('提示词：画风/画质/负面拼接', () => {
  const positive = buildPositive('a whale', 'anime')
  assert.match(positive, /anime illustration/)
  assert.match(positive, /masterpiece/)
  const negative = buildNegative('', 'anime')
  assert.match(negative, /lowres/)
  assert.deepEqual(normalizeLoras(['a', { name: 'b', weight: 0.7 }]), [{ name: 'a', weight: 1 }, { name: 'b', weight: 0.7 }])
  assert.equal(loraTags([{ name: 'b', weight: 0.7 }]), '<lora:b:0.7>')
})

await test('蒙版：矩形 PNG 尺寸正确', () => {
  const png = maskFromBox(512, 512, { x: 100, y: 120, w: 200, h: 150, feather: 8 })
  const info = imageInfo(png)
  assert.equal(info.width, 512)
  assert.equal(info.height, 512)
})

await test('回环校验：拒绝外网地址', () => {
  assert.throws(() => assertLocalUrl('http://example.com:7860'), /只允许本机/)
  assert.equal(assertLocalUrl('http://127.0.0.1:7860').port, '7860')
})

// ── 假 A1111 集成 ────────────────────────────────────────────────────
await test('桥接：注册 7 个工具；txt2img 落盘、参数正确', async () => {
  const mock = await createMockSd()
  const out = await tempDir()
  const ctx = makeCtx()
  apply(ctx, { sdUrl: mock.url, outputDir: out, autoStart: false, systemPrompt: true, steps: 8, width: 512, height: 512 })
  try {
    assert.deepEqual([...ctx.toolsMap.keys()].sort(), ['sd_draw', 'sd_img2img', 'sd_inpaint', 'sd_models', 'sd_prompt', 'sd_server', 'sd_status'])
    assert.equal(ctx.sections.length, 1)
    const result = await ctx.toolsMap.get('sd_draw').execute({ prompt: 'a whale', style: 'anime', seed: 42, count: 2 }, {})
    assert.equal(result.files.length, 2)
    assert.ok(existsSync(result.path))
    assert.equal(result.seed, 42)
    assert.equal(mock.lastPayload.txt2img.seed, 42)
    assert.equal(mock.lastPayload.txt2img.n_iter, 2)
    assert.match(mock.lastPayload.txt2img.prompt, /masterpiece/)
    assert.equal(result.width, 64)
  } finally {
    await mock.close()
  }
})

await test('桥接：img2img 传 base64、inpaint 用 maskBox 生成蒙版', async () => {
  const mock = await createMockSd()
  const out = await tempDir()
  const ctx = makeCtx()
  apply(ctx, { sdUrl: mock.url, outputDir: out, autoStart: false, systemPrompt: false, steps: 6 })
  try {
    const file = path.join(out, 'init.png')
    await writeFile(file, makePng(96, 96))
    const img2img = await ctx.toolsMap.get('sd_img2img').execute({ prompt: 'repaint', initImage: file, denoise: 0.4, seed: 7 }, {})
    assert.ok(existsSync(img2img.path))
    assert.equal(mock.lastPayload.img2img.init_images[0].length > 100, true)
    assert.equal(mock.lastPayload.img2img.denoising_strength, 0.4)

    const inpaint = await ctx.toolsMap.get('sd_inpaint').execute({
      prompt: 'a star', initImage: file, maskBox: { x: 10, y: 10, w: 40, h: 40, feather: 4 }, seed: 8,
    }, {})
    assert.ok(existsSync(inpaint.path))
    assert.equal(mock.lastPayload.img2img.mask.length > 100, true)
    assert.equal(mock.lastPayload.img2img.inpainting_fill, 1)
  } finally {
    await mock.close()
  }
})

await test('桥接：模型清单 / 状态 / 提示词增强', async () => {
  const mock = await createMockSd()
  const out = await tempDir()
  const ctx = makeCtx()
  apply(ctx, { sdUrl: mock.url, outputDir: out, autoStart: false, systemPrompt: false })
  try {
    const models = await ctx.toolsMap.get('sd_models').execute({}, {})
    assert.equal(models.online, true)
    assert.equal(models.checkpoints.length, 1)
    assert.equal(models.loras.length, 1)
    assert.match(models.current, /mock-model/)
    const status = await ctx.toolsMap.get('sd_status').execute({}, {})
    assert.equal(status.ok, true)
    assert.match(status.summary, /SD 在线/)
    const prompt = await ctx.toolsMap.get('sd_prompt').execute({ idea: '一只鲸鱼', style: 'anime' }, {})
    assert.equal(prompt.hasCjk, true)
    assert.match(prompt.positive, /anime illustration/)
  } finally {
    await mock.close()
  }
})

await test('桥接：SD 返回 500 时给出可读错误', async () => {
  const mock = await createMockSd({ fail: true })
  const out = await tempDir()
  const ctx = makeCtx()
  apply(ctx, { sdUrl: mock.url, outputDir: out, autoStart: false, systemPrompt: false })
  try {
    await assert.rejects(ctx.toolsMap.get('sd_draw').execute({ prompt: 'x', seed: 1 }, {}), /SD HTTP 500/)
  } finally {
    await mock.close()
  }
})

// ── 真机（可选） ─────────────────────────────────────────────────────
if (real) {
  await test('真机：sd_models + 6 步出图 + img2img', async () => {
    const out = await tempDir()
    const ctx = makeCtx()
    apply(ctx, { sdUrl: 'http://127.0.0.1:7860', outputDir: out, autoStart: false, systemPrompt: false, steps: 6, timeoutMs: 300000 })
    const online = await ctx.toolsMap.get('sd_status').execute({}, {})
    assert.equal(online.online, true, 'A1111 不在 7860')
    const draw = await ctx.toolsMap.get('sd_draw').execute({ prompt: 'a cute blue whale girl, chibi, seaside sunset', style: 'anime', seed: 20261026, steps: 6 }, {})
    assert.ok(existsSync(draw.path))
    assert.equal(draw.width, 512)
    const again = await ctx.toolsMap.get('sd_img2img').execute({ prompt: 'night city neon', initImage: draw.path, denoise: 0.4, steps: 4, seed: 20261027 }, {})
    assert.ok(existsSync(again.path))
  }, 240000)
}

for (const dir of dirs) await rm(dir, { recursive: true, force: true }).catch(() => {})
const failed = results.filter((item) => !item.ok)
console.log('')
console.log(`通过 ${results.length - failed.length}/${results.length}`)
process.exit(failed.length === 0 ? 0 : 1)

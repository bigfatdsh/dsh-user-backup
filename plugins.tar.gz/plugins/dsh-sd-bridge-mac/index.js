/**
 * dsh-sd-bridge-mac —— Stable Diffusion（A1111 / Forge）的原生 macOS 桥。
 *
 * 与 savinglighting/dsh-sd-bridge-guard 的关系：
 *   · 工具面（文生图 / 图生图 / 蒙版重绘 / 模型清单 / 服务管理）对齐；
 *   · 实现换成**纯 Node + /sdapi/v1**，不再调 PowerShell / .ps1；
 *   · 启动用 `webui.sh`（macOS/Linux），自动探测目录，MPS 环境变量默认开启；
 *   · 去掉了原版的「违禁词注入 / 绕过」那一档，只保留正常的生图与提示词增强。
 */
import { promises as fsp } from 'node:fs'
import path from 'node:path'

import { createSdClient, assertLocalUrl } from './lib/sdclient.js'
import { createServerManager, detectSdDir } from './lib/server.js'
import { maskFromBox } from './lib/mask.js'
import {
  STYLE_PRESETS, buildPositive, buildNegative, normalizeLoras, loraTags, expandPrompt,
} from './lib/prompt.js'
import {
  ASPECTS, calcSize, imageInfo, stamp, uniquePath, makeLogger, abortError,
} from './lib/util.js'

export const name = 'sd-bridge-mac'
export const inject = ['tools']

const DEFAULTS = {
  sdUrl: 'http://127.0.0.1:7860',
  sdDir: '',
  pythonPath: '',
  outputDir: '',
  launchArgs: ['--api', '--skip-torch-cuda-test', '--no-half-vae', '--upcast-sampling', '--opt-split-attention'],
  autoStart: true,
  startTimeoutMs: 240000,
  timeoutMs: 900000,
  width: 512,
  height: 512,
  steps: 8,
  cfgScale: 7,
  sampler: 'DPM++ 2M Karras',
  systemPrompt: true,
  verbose: false,
}

function normalizeConfig(raw) {
  const input = raw && typeof raw === 'object' ? raw : {}
  const config = { ...DEFAULTS }
  for (const key of Object.keys(DEFAULTS)) {
    if (input[key] !== undefined) config[key] = input[key]
  }
  config.sdUrl = String(config.sdUrl || DEFAULTS.sdUrl).replace(/\/+$/, '')
  config.autoStart = config.autoStart !== false
  config.systemPrompt = config.systemPrompt !== false
  config.verbose = config.verbose === true
  config.width = Math.max(256, Math.trunc(Number(config.width) || 512))
  config.height = Math.max(256, Math.trunc(Number(config.height) || 512))
  config.steps = Math.max(1, Math.min(80, Math.trunc(Number(config.steps) || 8)))
  config.cfgScale = Math.max(1, Math.min(30, Number(config.cfgScale) || 7))
  config.startTimeoutMs = Math.max(10000, Math.trunc(Number(config.startTimeoutMs) || 240000))
  config.timeoutMs = Math.max(10000, Math.trunc(Number(config.timeoutMs) || 900000))
  if (!Array.isArray(config.launchArgs)) config.launchArgs = [...DEFAULTS.launchArgs]
  return config
}

function safeInfo(raw) {
  if (typeof raw !== 'string' || raw === '') return null
  try {
    return JSON.parse(raw)
  } catch {
    return null
  }
}

function align64(value) {
  return Math.max(64, Math.round(Number(value) / 64) * 64)
}

export function apply(ctx, rawConfig) {
  const config = normalizeConfig(rawConfig)
  const log = makeLogger(config.verbose)
  const client = createSdClient({ baseUrl: config.sdUrl, timeoutMs: config.timeoutMs, log: log.warn })
  const manager = createServerManager({ config, client, log })
  const state = {
    startedAt: Date.now(),
    draws: 0,
    failures: 0,
    coldStarts: 0,
    lastRuns: [],
  }
  let disposed = false

  function record(run) {
    state.lastRuns.unshift(run)
    if (state.lastRuns.length > 10) state.lastRuns.pop()
  }

  async function ensureOnline(signal) {
    if (signal?.aborted) throw abortError(signal)
    if (await client.ping(signal)) return { cold: false }
    if (!config.autoStart) throw new Error('SD 没在运行，且配置 autoStart=false。先手动启动 WebUI（--api），或把 autoStart 打开。')
    state.coldStarts += 1
    await manager.start({ signal })
    return { cold: true }
  }

  function outputDir() {
    return config.outputDir || path.join(process.cwd(), 'SD-Picture')
  }

  async function saveImages(images, { seed, requested }) {
    const dir = outputDir()
    await fsp.mkdir(dir, { recursive: true })
    const files = []
    let width = 0
    let height = 0
    let index = 0
    for (const base64 of images) {
      index += 1
      if (typeof base64 !== 'string' || base64.length < 100) continue
      const buffer = Buffer.from(base64, 'base64')
      const info = imageInfo(buffer)
      if (info === null) throw new Error('SD 返回的图片无法识别（不是 PNG/JPEG/WEBP）')
      if (info.width > 0) {
        width = info.width
        height = info.height
      }
      const target = uniquePath(dir, `sd-${stamp()}-${seed}-${String(index).padStart(2, '0')}`, info.ext)
      await fsp.writeFile(target, buffer)
      files.push(target)
    }
    if (files.length === 0) throw new Error('SD 说完成了，但没有返回任何图片')
    if (width === 0) width = requested.width
    if (height === 0) height = requested.height
    return { files, width, height }
  }

  function resolveSize(args) {
    if (Number.isFinite(args?.width) && Number.isFinite(args?.height)) {
      return { width: align64(args.width), height: align64(args.height) }
    }
    if (typeof args?.size === 'string' && ASPECTS[args.size] !== undefined) {
      return calcSize(args.size, Number.isFinite(args?.longEdge) ? args.longEdge : config.width)
    }
    return { width: align64(config.width), height: align64(config.height) }
  }

  function resolveSampler(args) {
    return typeof args?.sampler === 'string' && args.sampler.trim() !== '' ? args.sampler.trim() : config.sampler
  }

  function resolveSeed(args) {
    if (Number.isFinite(args?.seed)) return Math.trunc(args.seed)
    return Math.floor(Math.random() * 2 ** 31)
  }

  async function readImage(filePath) {
    const resolved = path.resolve(String(filePath))
    const info = await fsp.stat(resolved).catch(() => null)
    if (info === null || !info.isFile()) throw new Error(`图片不存在：${resolved}`)
    if (info.size > 40 * 1024 * 1024) throw new Error(`图片太大（${Math.round(info.size / 1048576)}MB，上限 40MB）`)
    return { buffer: await fsp.readFile(resolved), info }
  }

  async function txt2img(args, signal) {
    const started = Date.now()
    const prompt = buildPositive(args?.prompt, args?.style)
    const negative = buildNegative(args?.negative, args?.style)
    const loras = normalizeLoras(args?.lora)
    const tags = loraTags(loras)
    const fullPrompt = tags === '' ? prompt : `${prompt}, ${tags}`
    const { width, height } = resolveSize(args)
    const steps = Number.isFinite(args?.steps) ? Math.max(1, Math.min(80, Math.trunc(args.steps))) : config.steps
    const cfg = Number.isFinite(args?.cfgScale) ? args.cfgScale : config.cfgScale
    const seed = resolveSeed(args)
    const count = Number.isFinite(args?.count) ? Math.max(1, Math.min(4, Math.trunc(args.count))) : 1
    const sampler = resolveSampler(args)
    const cold = (await ensureOnline(signal)).cold

    const payload = {
      prompt: fullPrompt,
      negative_prompt: negative,
      steps,
      cfg_scale: cfg,
      width,
      height,
      sampler_name: sampler,
      seed,
      batch_size: 1,
      n_iter: count,
      save_images: false,
      send_images: true,
    }
    if (typeof args?.model === 'string' && args.model.trim() !== '') {
      payload.override_settings = { sd_model_checkpoint: args.model.trim() }
      payload.override_settings_restore_afterwards = true
    }
    if (args?.hires === true) {
      payload.enable_hr = true
      payload.hr_scale = Number.isFinite(args?.hiresScale) ? args.hiresScale : 1.5
      payload.hr_upscaler = 'Latent'
      payload.hr_second_pass_steps = Math.max(4, Math.round(steps / 2))
      payload.denoising_strength = Number.isFinite(args?.hiresDenoise) ? args.hiresDenoise : 0.45
    }
    const result = await client.txt2img(payload, { signal, timeoutMs: config.timeoutMs })
    const saved = await saveImages(result?.images ?? [], { seed, requested: { width, height } })
    return {
      path: saved.files[0],
      files: saved.files,
      width: saved.width,
      height: saved.height,
      seed,
      seconds: Number(((Date.now() - started) / 1000).toFixed(1)),
      model: safeInfo(result?.info)?.sd_model_name ?? '',
      steps,
      cfg,
      sampler,
      style: args?.style ?? 'none',
      count: saved.files.length,
      cold,
    }
  }

  async function img2img(args, signal) {
    const started = Date.now()
    const { buffer, info } = await readImage(args?.initImage)
    const prompt = buildPositive(args?.prompt, args?.style)
    const negative = buildNegative(args?.negative, args?.style)
    const loras = normalizeLoras(args?.lora)
    const fullPrompt = loras.length === 0 ? prompt : `${prompt}, ${loraTags(loras)}`
    const size = resolveSize(args)
    const width = Number.isFinite(args?.width) ? size.width : (info.width || size.width)
    const height = Number.isFinite(args?.height) ? size.height : (info.height || size.height)
    const steps = Number.isFinite(args?.steps) ? Math.max(1, Math.min(80, Math.trunc(args.steps))) : config.steps
    const cfg = Number.isFinite(args?.cfgScale) ? args.cfgScale : config.cfgScale
    const denoise = Number.isFinite(args?.denoise) ? Math.max(0.05, Math.min(1, args.denoise)) : 0.6
    const seed = resolveSeed(args)
    const count = Number.isFinite(args?.count) ? Math.max(1, Math.min(4, Math.trunc(args.count))) : 1
    const cold = (await ensureOnline(signal)).cold
    const payload = {
      prompt: fullPrompt,
      negative_prompt: negative,
      init_images: [buffer.toString('base64')],
      steps,
      cfg_scale: cfg,
      width,
      height,
      sampler_name: resolveSampler(args),
      seed,
      denoising_strength: denoise,
      batch_size: 1,
      n_iter: count,
      resize_mode: 0,
      save_images: false,
    }
    if (typeof args?.model === 'string' && args.model.trim() !== '') {
      payload.override_settings = { sd_model_checkpoint: args.model.trim() }
      payload.override_settings_restore_afterwards = true
    }
    const result = await client.img2img(payload, { signal, timeoutMs: config.timeoutMs })
    const saved = await saveImages(result?.images ?? [], { seed, requested: { width, height } })
    return {
      path: saved.files[0],
      files: saved.files,
      width: saved.width,
      height: saved.height,
      seed,
      seconds: Number(((Date.now() - started) / 1000).toFixed(1)),
      model: '',
      steps,
      cfg,
      sampler: resolveSampler(args),
      style: args?.style ?? 'none',
      count: saved.files.length,
      denoise,
      cold,
    }
  }

  async function inpaint(args, signal) {
    const started = Date.now()
    const { buffer, info } = await readImage(args?.initImage)
    const width = info.width || config.width
    const height = info.height || config.height
    let maskBuffer
    if (typeof args?.mask === 'string' && args.mask.trim() !== '') {
      maskBuffer = (await readImage(args.mask)).buffer
    } else if (args?.maskBox && typeof args.maskBox === 'object') {
      maskBuffer = maskFromBox(width, height, args.maskBox)
    } else {
      throw new Error('inpaint 需要 mask（蒙版图路径）或 maskBox（{x,y,w,h}）')
    }
    const prompt = buildPositive(args?.prompt, args?.style ?? 'none')
    const negative = buildNegative(args?.negative, args?.style ?? 'none')
    const steps = Number.isFinite(args?.steps) ? Math.max(1, Math.min(80, Math.trunc(args.steps))) : config.steps
    const cfg = Number.isFinite(args?.cfgScale) ? args.cfgScale : config.cfgScale
    const denoise = Number.isFinite(args?.denoise) ? Math.max(0.1, Math.min(1, args.denoise)) : 0.65
    const seed = resolveSeed(args)
    const cold = (await ensureOnline(signal)).cold
    const payload = {
      prompt,
      negative_prompt: negative,
      init_images: [buffer.toString('base64')],
      mask: maskBuffer.toString('base64'),
      steps,
      cfg_scale: cfg,
      width,
      height,
      sampler_name: resolveSampler(args),
      seed,
      denoising_strength: denoise,
      batch_size: 1,
      n_iter: 1,
      resize_mode: 0,
      inpainting_fill: 1,
      inpaint_full_res: false,
      inpaint_full_res_padding: 32,
      inpainting_mask_invert: false,
      mask_blur: Number.isFinite(args?.maskBlur) ? args.maskBlur : 4,
      save_images: false,
    }
    const result = await client.img2img(payload, { signal, timeoutMs: config.timeoutMs })
    const saved = await saveImages(result?.images ?? [], { seed, requested: { width, height } })
    return {
      path: saved.files[0],
      files: saved.files,
      width: saved.width,
      height: saved.height,
      seed,
      seconds: Number(((Date.now() - started) / 1000).toFixed(1)),
      model: '',
      steps,
      cfg,
      sampler: resolveSampler(args),
      style: args?.style ?? 'none',
      count: 1,
      denoise,
      cold,
    }
  }

  // ── 工具定义 ─────────────────────────────────────────────────────────
  const RESULT_SCHEMA = {
    type: 'object',
    additionalProperties: true,
    properties: {
      path: { type: 'string', description: '第一张图的绝对路径。' },
      files: { type: 'array', items: { type: 'string' } },
      width: { type: 'integer' },
      height: { type: 'integer' },
      seed: { type: 'integer' },
      seconds: { type: 'number' },
      model: { type: 'string' },
      steps: { type: 'integer' },
      cfg: { type: 'number' },
      sampler: { type: 'string' },
      style: { type: 'string' },
      count: { type: 'integer' },
      denoise: { type: 'number' },
      cold: { type: 'boolean' },
    },
    required: ['path', 'files', 'width', 'height', 'seed', 'seconds'],
  }

  const renderResult = (_args, value) => [{
    type: 'text',
    text: `已出图${value.files.length > 1 ? ` ${value.files.length} 张` : ''}：${value.path}`
      + `（${value.width}x${value.height}，seed ${value.seed}，用时 ${value.seconds}s）`,
  }]

  const styleEnum = { type: 'string', enum: Object.keys(STYLE_PRESETS), description: '画风预设：anime / illustration / photo / wallpaper / chibi / none。' }
  const loraSchema = {
    description: 'LoRA 列表，如 ["add_detail"] 或 [{name:"add_detail",weight:0.8}]。',
    anyOf: [
      { type: 'string' },
      { type: 'array', items: { anyOf: [{ type: 'string' }, { type: 'object' }] } },
    ],
  }

  const drawTool = {
    name: 'sd_draw',
    description:
      '用本机 Stable Diffusion（A1111 / Forge）文生图。提示词用**英文**（SD 1.5 不认识中文）。'
      + '返回图片绝对路径，正文里必须用 Markdown 内联展示。本机 8GB：默认 512² / 8 步，约 30 秒一张；'
      + '要更快可用 steps:4 + lora:["lcm-lora-sdv1-5"] + sampler:"LCM" + cfgScale:1（约 17 秒）。',
    parameters: {
      type: 'object',
      additionalProperties: false,
      properties: {
        prompt: { type: 'string', description: '英文画面描述：主体 + 细节 + 环境 + 光线 + 画风。' },
        negative: { type: 'string', description: '负面提示词（可选，已内置常用负面）。' },
        style: styleEnum,
        size: { type: 'string', enum: Object.keys(ASPECTS), description: '画幅比例，默认 1:1。' },
        width: { type: 'integer', description: '显式宽度（64 对齐），与 size 二选一。' },
        height: { type: 'integer' },
        longEdge: { type: 'integer', description: '长边像素，默认 512。' },
        steps: { type: 'integer', description: '采样步数，默认 8（8 步已能看；质量优先可 20）。' },
        cfgScale: { type: 'number', description: 'CFG，默认 7；LCM 用 1。' },
        seed: { type: 'integer', description: '固定种子可复现；不填随机。' },
        sampler: { type: 'string', description: '采样器，默认 DPM++ 2M Karras。' },
        count: { type: 'integer', description: '一次几张（1-4），同一模型只加载一次。' },
        model: { type: 'string', description: '临时切换 checkpoint（文件名）。' },
        lora: loraSchema,
        hires: { type: 'boolean', description: '开 hires fix（更清晰但慢一倍），默认关。' },
        hiresScale: { type: 'number', description: 'hires 放大倍数，默认 1.5。' },
        hiresDenoise: { type: 'number' },
      },
      required: ['prompt'],
    },
    timeoutMs: config.timeoutMs,
    output: { schema: RESULT_SCHEMA, render: renderResult },
    isConcurrencySafe: () => false,
    async execute(args, exec) {
      try {
        const result = await txt2img(args, exec?.signal)
        state.draws += 1
        record({ at: Date.now(), kind: 'sd_draw', ms: result.seconds * 1000, seed: result.seed, prompt: String(args?.prompt ?? '').slice(0, 60) })
        return result
      } catch (error) {
        state.failures += 1
        throw error instanceof Error ? error : new Error(String(error))
      }
    },
  }

  const img2imgTool = {
    name: 'sd_img2img',
    description: '用 Stable Diffusion 按参考图重画（img2img）。给本地图片路径和英文提示词，denoise 越低越像原图（0.3-0.7 常用）。',
    parameters: {
      type: 'object',
      additionalProperties: false,
      properties: {
        prompt: { type: 'string' },
        negative: { type: 'string' },
        initImage: { type: 'string', description: '参考图绝对路径（PNG/JPG/WEBP）。' },
        style: styleEnum,
        denoise: { type: 'number', description: '重绘幅度 0.05-1，默认 0.6。' },
        steps: { type: 'integer' },
        cfgScale: { type: 'number' },
        seed: { type: 'integer' },
        sampler: { type: 'string' },
        count: { type: 'integer' },
        width: { type: 'integer' },
        height: { type: 'integer' },
        model: { type: 'string' },
        lora: loraSchema,
      },
      required: ['prompt', 'initImage'],
    },
    timeoutMs: config.timeoutMs,
    output: { schema: RESULT_SCHEMA, render: renderResult },
    isConcurrencySafe: () => false,
    async execute(args, exec) {
      try {
        const result = await img2img(args, exec?.signal)
        state.draws += 1
        record({ at: Date.now(), kind: 'sd_img2img', ms: result.seconds * 1000, seed: result.seed })
        return result
      } catch (error) {
        state.failures += 1
        throw error instanceof Error ? error : new Error(String(error))
      }
    },
  }

  const inpaintTool = {
    name: 'sd_inpaint',
    description:
      '局部重绘：给原图 + 蒙版（白色区域重绘），或给 maskBox（{x,y,w,h}）由插件生成矩形蒙版。'
      + '适合改衣服、换背景、修手。denoise 默认 0.65。',
    parameters: {
      type: 'object',
      additionalProperties: false,
      properties: {
        prompt: { type: 'string', description: '重绘区域要画成什么（英文）。' },
        negative: { type: 'string' },
        initImage: { type: 'string' },
        mask: { type: 'string', description: '蒙版图路径（白=重绘，黑=保留）。与 maskBox 二选一。' },
        maskBox: {
          type: 'object',
          description: '矩形蒙版（像素坐标）。',
          additionalProperties: false,
          properties: {
            x: { type: 'integer' }, y: { type: 'integer' }, w: { type: 'integer' }, h: { type: 'integer' },
            feather: { type: 'integer', description: '羽化像素，默认 0。' },
          },
          required: ['x', 'y', 'w', 'h'],
        },
        maskBlur: { type: 'integer', description: '蒙版模糊像素，默认 4。' },
        denoise: { type: 'number' },
        steps: { type: 'integer' },
        cfgScale: { type: 'number' },
        seed: { type: 'integer' },
        sampler: { type: 'string' },
        style: styleEnum,
      },
      required: ['prompt', 'initImage'],
    },
    timeoutMs: config.timeoutMs,
    output: { schema: RESULT_SCHEMA, render: renderResult },
    isConcurrencySafe: () => false,
    async execute(args, exec) {
      try {
        const result = await inpaint(args, exec?.signal)
        state.draws += 1
        record({ at: Date.now(), kind: 'sd_inpaint', ms: result.seconds * 1000, seed: result.seed })
        return result
      } catch (error) {
        state.failures += 1
        throw error instanceof Error ? error : new Error(String(error))
      }
    },
  }

  const modelsTool = {
    name: 'sd_models',
    description: '列出本机 SD 的 checkpoint、LoRA、采样器、VAE 和当前模型。看有哪些模型可用时用它。',
    parameters: {
      type: 'object',
      additionalProperties: false,
      properties: {
        include: {
          type: 'array',
          items: { type: 'string', enum: ['checkpoints', 'loras', 'samplers', 'vaes'] },
          description: '默认全列。',
        },
      },
    },
    timeoutMs: 60000,
    output: {
      schema: {
        type: 'object',
        additionalProperties: true,
        properties: {
          online: { type: 'boolean' },
          current: { type: 'string' },
          checkpoints: { type: 'array', items: { type: 'object', additionalProperties: true } },
          loras: { type: 'array', items: { type: 'object', additionalProperties: true } },
          samplers: { type: 'array', items: { type: 'object', additionalProperties: true } },
          vaes: { type: 'array', items: { type: 'object', additionalProperties: true } },
        },
        required: ['online'],
      },
      render: (_args, value) => [{
        type: 'text',
        text: value.online
          ? `SD 在线，当前模型：${value.current || '(未知)'}；checkpoint ${value.checkpoints?.length ?? 0} 个，LoRA ${value.loras?.length ?? 0} 个。`
          : 'SD 不在线（先调用 sd_server action=start）。',
      }],
    },
    async execute(args, exec) {
      const online = await client.ping(exec?.signal)
      if (!online) return { online: false }
      const include = Array.isArray(args?.include) && args.include.length > 0 ? args.include : ['checkpoints', 'loras', 'samplers', 'vaes']
      const result = { online: true, current: '', checkpoints: [], loras: [], samplers: [], vaes: [] }
      if (include.includes('checkpoints')) {
        const options = await client.options({ signal: exec?.signal }).catch(() => null)
        result.current = String(options?.sd_model_checkpoint ?? '')
        result.checkpoints = (await client.models({ signal: exec?.signal }).catch(() => [])) ?? []
      }
      if (include.includes('loras')) result.loras = (await client.loras({ signal: exec?.signal }).catch(() => [])) ?? []
      if (include.includes('samplers')) result.samplers = (await client.samplers({ signal: exec?.signal }).catch(() => [])) ?? []
      if (include.includes('vaes')) result.vaes = (await client.vaes({ signal: exec?.signal }).catch(() => [])) ?? []
      return result
    },
  }

  const serverTool = {
    name: 'sd_server',
    description: '管理本机 SD WebUI：status（默认）、start、stop、restart。start 会等 API 就绪（首次约 30-60 秒）。',
    parameters: {
      type: 'object',
      additionalProperties: false,
      properties: {
        action: { type: 'string', enum: ['status', 'start', 'stop', 'restart'], description: '默认 status。' },
      },
    },
    timeoutMs: 300000,
    output: {
      schema: {
        type: 'object',
        additionalProperties: true,
        properties: {
          ok: { type: 'boolean' },
          summary: { type: 'string' },
          online: { type: 'boolean' },
          url: { type: 'string' },
          dir: { type: 'string' },
          managed: { type: 'boolean' },
          pid: { type: 'integer' },
          device: { type: 'string' },
          model: { type: 'string' },
        },
        required: ['ok', 'summary'],
      },
      render: (_args, value) => [{ type: 'text', text: value.summary }],
    },
    async execute(args, exec) {
      const action = typeof args?.action === 'string' ? args.action : 'status'
      const signal = exec?.signal
      if (action === 'start') {
        if (await client.ping(signal)) return { ok: true, online: true, summary: 'SD 本来就在线。' }
        const started = await manager.start({ signal })
        const status = await manager.status()
        return { ok: true, online: true, ...status, summary: `SD 已启动（${started.dir || status.dir}，首次加载模型可能要一会儿）。` }
      }
      if (action === 'stop') {
        const stopped = await manager.stop()
        return { ok: true, online: false, summary: stopped.wasOnline ? 'SD 已停止。' : 'SD 本来就没在运行。' }
      }
      if (action === 'restart') {
        await manager.stop()
        const started = await manager.start({ signal })
        return { ok: true, online: true, summary: `SD 已重启（${started.dir}）。` }
      }
      const status = await manager.status()
      const summary = status.online
        ? `SD 在线：${status.url}，模型 ${status.model || '(未知)'}${status.device ? `，设备 ${status.device}` : ''}。`
        : `SD 不在线（${status.dir || '没找到安装目录'}）。可用 sd_server action=start 启动。`
      return { ok: status.online, ...status, summary }
    },
  }

  const statusTool = {
    name: 'sd_status',
    description: '查看 SD 是否在线、当前模型、设备，以及正在生成时的进度。',
    parameters: {
      type: 'object',
      additionalProperties: false,
      properties: { verbose: { type: 'boolean', description: '附带最近 5 次调用记录。' } },
    },
    timeoutMs: 30000,
    output: {
      schema: {
        type: 'object',
        additionalProperties: true,
        properties: {
          ok: { type: 'boolean' },
          summary: { type: 'string' },
          online: { type: 'boolean' },
          model: { type: 'string' },
          device: { type: 'string' },
          progress: { type: 'object', additionalProperties: true },
          counters: { type: 'object', additionalProperties: true },
          lastRuns: { type: 'array', items: { type: 'object', additionalProperties: true } },
        },
        required: ['ok', 'summary'],
      },
      render: (_args, value) => [{ type: 'text', text: value.summary }],
    },
    async execute(args, exec) {
      const status = await manager.status()
      let progress = null
      if (status.online) progress = await client.progress({ signal: exec?.signal }).catch(() => null)
      const busy = Number(progress?.progress ?? 0) > 0 && Number(progress?.progress ?? 0) < 1
      const summary = status.online
        ? `SD 在线${busy ? `，正在生成 ${(Number(progress.progress) * 100).toFixed(0)}%` : '，空闲'}`
          + `（${status.model || '未知模型'}）。累计 ${state.draws} 张，失败 ${state.failures}。`
        : 'SD 不在线。'
      const value = {
        ok: status.online,
        summary,
        online: status.online,
        model: status.model,
        device: status.device,
        counters: { draws: state.draws, failures: state.failures, coldStarts: state.coldStarts },
        lastRuns: args?.verbose === true ? state.lastRuns.slice(0, 5) : [],
      }
      if (progress !== null) value.progress = { progress: progress.progress, eta: progress.eta_relative }
      return value
    },
  }

  const promptTool = {
    name: 'sd_prompt',
    description: '把一句画面想法整理成 SD 用的英文正向/负向提示词（本地规则，不联网、不调模型）。中文想法会被标注需要翻译。',
    parameters: {
      type: 'object',
      additionalProperties: false,
      properties: {
        idea: { type: 'string', description: '画面想法（英文最好，中文会提示翻译）。' },
        style: styleEnum,
        extra: { type: 'string', description: '额外标签（可选）。' },
      },
      required: ['idea'],
    },
    timeoutMs: 10000,
    output: {
      schema: {
        type: 'object',
        additionalProperties: false,
        properties: {
          positive: { type: 'string' },
          negative: { type: 'string' },
          hasCjk: { type: 'boolean' },
          note: { type: 'string' },
        },
        required: ['positive', 'negative', 'hasCjk', 'note'],
      },
      render: (_args, value) => [{ type: 'text', text: `正向：${value.positive}\n负向：${value.negative}\n${value.note}` }],
    },
    async execute(args) {
      return expandPrompt({ idea: args?.idea, style: args?.style, extra: args?.extra })
    },
  }

  const tools = [drawTool, img2imgTool, inpaintTool, modelsTool, serverTool, statusTool, promptTool]
  for (const tool of tools) {
    try {
      ctx.tools.register(tool)
    } catch (error) {
      log.error(`注册 ${tool.name} 失败：${error?.message ?? error}`)
    }
  }

  if (config.systemPrompt) {
    try {
      const systemPrompt = ctx.get?.('systemPrompt')
      if (systemPrompt && typeof systemPrompt.section === 'function') {
        systemPrompt.section({
          name: 'sd-bridge-mac:sd-on-request',
          order: 9103,
          text: '【SD 桥】只有用户明确要求用 Stable Diffusion / A1111 / SD 模型 / 二次元模型出图，或说「用 SD 画」时，才调用 `sd_draw`；'
            + '普通出图仍用当前默认的生图工具。SD 的提示词要用英文；本机 8GB，默认 512²/8 步，约 30 秒一张，'
            + '更快可用 steps 4 + LCM LoRA（`sd_turbo` 的 fast 档会自动加）。'
            + 'sd_draw 返回图片绝对路径，必须在回复正文里用 ![画面简述](<路径>) 内联展示，不要只给路径。',
        })
      }
    } catch (error) {
      log.warn(`注册 systemPrompt 失败：${error?.message ?? error}`)
    }
  }

  // 本地补丁（FISH_SD_NO_BOOT_PREWARM）：开机不要自动拉起 SD。
  // 8GB 机器上 SD 的 python 一开就吃几百 MB，而开机后大多数对话并不画图。
  // autoStart 保留——第一次真正出图时 sd_draw 会自己拉起（多花 10–20 秒）。
  // 想要老的「开机预热」行为，配置 bootPrewarm: true。
  if (config.bootPrewarm === true && config.autoStart) {
    setTimeout(() => {
      if (disposed) return
      ensureOnline().catch((error) => log.warn(`预热 SD 失败（首次出图会再试）：${error?.message ?? error}`))
    }, 3000).unref?.()
  }

  try {
    ctx.effect(() => () => {
      disposed = true
    })
  } catch {
    /* 裁剪版宿主 */
  }

  log.info(`SD 桥已加载：${config.sdUrl}，默认 ${config.width}x${config.height}/${config.steps} 步`)
}

export const __internal = {
  normalizeConfig,
  resolveSize: (args, config) => {
    const cfg = config ?? DEFAULTS
    if (Number.isFinite(args?.width) && Number.isFinite(args?.height)) {
      return { width: align64(args.width), height: align64(args.height) }
    }
    if (typeof args?.size === 'string' && ASPECTS[args.size] !== undefined) {
      return calcSize(args.size, Number.isFinite(args?.longEdge) ? args.longEdge : cfg.width)
    }
    return { width: align64(cfg.width), height: align64(cfg.height) }
  },
  align64,
  detectSdDir: (dir) => detectSdDir(dir),
  assertLocalUrl,
  buildPositive,
  buildNegative,
}

# 测评：dsh-sd-bridge-mac + dsh-sd-turbo

机器：Apple M1 / 8 GB / macOS 26.6.2 · SD：AUTOMATIC1111 1.10.1 + AWPainting_v1.2（SD1.5）
后端：`--api --upcast-sampling --no-half-vae --opt-split-attention`

## 为什么要有这个插件

原版 `dsh-sd-bridge-guard` 是 Windows 插件：出图靠 `sd-direct.ps1`，安装靠 `install-sd.ps1`。
macOS 没有 `powershell.exe`，所以它在 Mac 上装上也跑不起来。本插件把同一条链路改成纯 Node 调 `/sdapi/v1`，
工具面对齐（文生图/图生图/蒙版重绘/模型清单/服务管理），并补了提示词整理、MPS 启动参数和自动探测。

## 测试

| 套件 | 结果 |
|---|---|
| `dsh-sd-bridge-mac/test/run.mjs` | **8/8**（画幅、提示词、蒙版 PNG、回环校验、txt2img、img2img、inpaint、模型/状态/提示词、HTTP 500 错误） |
| `dsh-sd-turbo/test/run.mjs` | **4/4**（档位注入、auto 档位、缓存+并发+状态、失败重试） |
| 真机联调 | 通过：`sd_draw` 512²、`sd_img2img`、`sd_inpaint`（maskBox）均落盘 |
| 当前 DSH 进程内 | `sd_draw` 31.4 秒出图；同参数第二次 0 秒（缓存命中，同一路径） |

## 性能（512²，SD1.5，M1 8GB）

| 场景 | 耗时 |
|---|---|
| 20 步（quality） | 62–113 秒（随内存压力浮动） |
| 8 步（balanced，默认） | 28–36 秒 |
| 4 步 + LCM（fast） | 17–19 秒 |
| 缓存命中 | 0.003–0.03 秒 |
| 两个相同请求并发 | 只提交 1 次 |
| img2img / inpaint | 12–17 秒 |

`--opt-split-attention`（Doggettx）比 MPS 默认的 sub-quadratic 快约 20%：
8 步 29→24 秒；20 步 80→62 秒。LCM 档因为步数少，两者接近（17.5 秒）。

## 关键坑

1. 原版 `.ps1` 在 Mac 上直接不可用 → 全部改原生 HTTP。
2. A1111 在 Mac 上要加 `--skip-torch-cuda-test`，否则启动即报 CUDA。
3. `--upcast-sampling` 是 M1 上画质/速度的平衡点；`--no-half` 会慢一倍。
4. 8GB 机器不要开 768²/hires；512² 是甜点。
5. 切换 LoRA/checkpoint 会触发模型重载，第一次会慢 10–20 秒；缓存 + 固定档位能避开反复切换。
6. SD 1.5 不认中文提示词，桥里会明确提示。

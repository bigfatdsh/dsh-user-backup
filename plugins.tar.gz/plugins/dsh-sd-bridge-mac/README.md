# dsh-sd-bridge-mac

Stable Diffusion（AUTOMATIC1111 / Forge）生图桥的 **macOS 原生版**。

原版 [savinglighting/dsh-sd-bridge-guard](https://github.com/savinglighting/dsh-sd-bridge-guard) 通过 PowerShell（`sd-direct.ps1` / `install-sd.ps1`）驱动 SD WebUI，macOS 上没有 `powershell.exe`，所以装上也用不了。本插件把整条链路改成 **纯 Node + `/sdapi/v1`**：

- 不再调用任何 `.ps1`；启动用 `webui.sh`（macOS/Linux），自动探测 `~/stable-diffusion-webui` 等目录；
- 默认带 MPS 友好参数：`--upcast-sampling --no-half-vae --opt-split-attention`；
- 去掉了原版的「违禁词注入 / 绕过」那一档，只保留正常的文生图、图生图、蒙版重绘、模型清单、服务管理、提示词增强。

## 工具

| 工具 | 作用 |
|---|---|
| `sd_draw` | 文生图：英文提示词、画风预设、比例/尺寸、步数、CFG、种子、采样器、一次 1-4 张、checkpoint/LoRA |
| `sd_img2img` | 参考图重画，`denoise` 控制像原图的程度 |
| `sd_inpaint` | 局部重绘：蒙版图或 `maskBox`（插件现场生成矩形蒙版） |
| `sd_models` | checkpoint / LoRA / 采样器 / VAE / 当前模型 |
| `sd_server` | status / start / stop / restart（首次启动约 30-60 秒） |
| `sd_status` | 在线状态、模型、设备、生成进度 |
| `sd_prompt` | 把一句想法整理成 SD 用的正向/负向提示词（本地规则） |

## 安装

```bash
dsh plugin --profile desktop add link:/path/to/dsh-sd-bridge-mac
```

依赖：本机已装 A1111/Forge，且有至少一个 checkpoint。启动前建议给 webui 加 API（配置里的 `launchArgs` 已含 `--api`）。

## 配置

见 `cordis.patch.yml`：`sdUrl`、`sdDir`、`pythonPath`、`outputDir`、`launchArgs`、`autoStart`、默认尺寸/步数/采样器。`sdDir` 留空会自动找。

## 实测（M1 8GB / AWPainting SD1.5 / 512²）

| 场景 | 耗时 |
|---|---|
| 8 步（默认） | 28–36 秒 |
| 4 步 + LCM LoRA | 17–19 秒（首次加载 LoRA 会多 20 秒左右） |
| 20 步（质量档） | 62–113 秒（随内存压力浮动） |
| 同参数再次出图 | 缓存命中，约 0.01 秒 |
| img2img / inpaint | 12–17 秒 |

`--opt-split-attention` 比 A1111 在 MPS 上自动选的 sub-quadratic 快约 20%（8 步 29→24 秒，20 步 80→62 秒）。

## 限制

- macOS 只能用 CPU/MPS，512² 是甜点；768² 以上明显变慢。
- 提示词必须是英文（SD 1.5 的 CLIP 不认识中文）。
- 首次请求会加载模型（约 10–20 秒），之后变快。

/**
 * dsh-sd-turbo —— dsh-sd-bridge-mac 的加速层。
 *
 * 不重写生图链路，只做四件事：
 *   ① 同参数 + 同种子 → 直接回上次那张（不碰 SD）；
 *   ② 同请求并发 → 合并成一次，后来的人等同一份结果；
 *   ③ 串行队列 → SD 后端一次只跑一个任务，不抢显存；
 *   ④ 按机器自动调参（8GB Mac：8 步 / 可选 4 步 LCM），失败重试，状态可查。
 *
 * 实现方式：运行时包住 sd_draw / sd_img2img / sd_inpaint 的 execute，
 * 工具名、参数、返回结构都不变——模型和用户都不用改调用方式。
 */
import { promises as fsp } from 'node:fs'
import { mkdirSync, appendFileSync } from 'node:fs'
import path from 'node:path'
import os from 'node:os'
import { createHash } from 'node:crypto'

import { ResultCache } from './lib/cache.js'
import { SerialQueue, Inflight } from './lib/queue.js'

export const name = 'sd-turbo'
export const inject = ['tools']

const HERE = path.dirname(new URL(import.meta.url).pathname)
const DATA_DIR = path.join(process.env.DSH_HOME || path.join(os.homedir(), '.dsh'), 'sd-turbo')

const DEFAULTS = {
  sdUrl: 'http://127.0.0.1:7860',
  cacheDir: '',
  profile: 'auto',
  cacheEnabled: true,
  cacheMaxEntries: 64,
  cacheMaxAgeHours: 168,
  dedupe: true,
  maxConcurrency: 1,
  retryAttempts: 1,
  retryDelayMs: 800,
  prewarm: true,
  autoTune: true,
  verbose: false,
}

const PROFILES = {
  fast: { steps: 4, cfgScale: 1, sampler: 'LCM', lcm: true },
  balanced: { steps: 8, cfgScale: 7, sampler: 'DPM++ 2M Karras', lcm: false },
  quality: { steps: 20, cfgScale: 7, sampler: 'DPM++ 2M Karras', lcm: false },
}

function normalizeConfig(raw) {
  const input = raw && typeof raw === 'object' ? raw : {}
  const config = { ...DEFAULTS }
  for (const key of Object.keys(DEFAULTS)) if (input[key] !== undefined) config[key] = input[key]
  config.sdUrl = String(config.sdUrl || DEFAULTS.sdUrl).replace(/\/+$/, '')
  if (!['auto', 'fast', 'balanced', 'quality'].includes(config.profile)) config.profile = 'auto'
  config.cacheEnabled = config.cacheEnabled !== false
  config.dedupe = config.dedupe !== false
  config.autoTune = config.autoTune !== false
  config.prewarm = config.prewarm !== false
  config.verbose = config.verbose === true
  config.maxConcurrency = Math.max(1, Math.min(2, Math.trunc(Number(config.maxConcurrency) || 1)))
  config.cacheMaxEntries = Math.max(1, Math.trunc(Number(config.cacheMaxEntries) || 64))
  config.cacheMaxAgeHours = Math.max(1, Number(config.cacheMaxAgeHours) || 168)
  config.retryAttempts = Math.max(0, Math.min(2, Math.trunc(Number(config.retryAttempts) || 0)))
  config.retryDelayMs = Math.max(100, Math.trunc(Number(config.retryDelayMs) || 800))
  return config
}

function resolveProfile(config) {
  if (config.profile !== 'auto') return config.profile
  const total = os.totalmem()
  return total > 0 && total <= 10 * 1024 ** 3 ? 'balanced' : 'quality'
}

function sha256(text) {
  return createHash('sha256').update(text).digest('hex')
}

function makeLogger(config) {
  const ring = []
  const file = path.join(DATA_DIR, 'turbo.log')
  let ready = false
  const write = (level, message) => {
    const line = `${new Date().toISOString()} [${level}] ${message}`
    ring.push(line)
    if (ring.length > 200) ring.shift()
    if (config.verbose) {
      try {
        if (!ready) {
          mkdirSync(DATA_DIR, { recursive: true })
          ready = true
        }
        appendFileSync(file, `${line}\n`)
      } catch {
        /* ignore */
      }
    }
    if (level === 'error') console.warn(`[sd-turbo] ${message}`)
  }
  return { info: (m) => write('info', m), warn: (m) => write('warn', m), error: (m) => write('error', m), recent: () => [...ring] }
}

function tuneArgs(args, kind, profileName) {
  const profile = PROFILES[profileName] ?? PROFILES.balanced
  const tuned = { ...(args ?? {}) }
  if (tuned.steps === undefined) tuned.steps = kind === 'sd_img2img' || kind === 'sd_inpaint' ? Math.max(4, Math.round(profile.steps * 0.75)) : profile.steps
  if (tuned.cfgScale === undefined) tuned.cfgScale = profile.cfgScale
  if (tuned.sampler === undefined) tuned.sampler = profile.sampler
  if (profile.lcm === true) {
    const list = []
    if (Array.isArray(tuned.lora)) {
      for (const item of tuned.lora) {
        const name = typeof item === 'string' ? item : item?.name
        if (name === 'lcm-lora-sdv1-5') list.push(item)
      }
    } else if (typeof tuned.lora === 'string' && tuned.lora.includes('lcm-lora-sdv1-5')) {
      return tuned
    }
    if (list.length === 0) {
      const existing = tuned.lora === undefined ? [] : Array.isArray(tuned.lora) ? tuned.lora : [tuned.lora]
      tuned.lora = [...existing, { name: 'lcm-lora-sdv1-5', weight: 1 }]
    }
  }
  return tuned
}

function canonicalArgs(args) {
  const keys = [
    'prompt', 'negative', 'style', 'size', 'width', 'height', 'longEdge', 'steps', 'cfgScale',
    'seed', 'sampler', 'count', 'model', 'lora', 'hires', 'hiresScale', 'hiresDenoise',
    'denoise', 'maskBox', 'maskBlur', 'initImage', 'mask',
  ]
  const picked = {}
  for (const key of keys) if (args?.[key] !== undefined) picked[key] = args[key]
  return picked
}

async function fileStamp(file) {
  if (typeof file !== 'string' || file === '') return ''
  try {
    const info = await fsp.stat(file)
    return `${path.resolve(file)}:${info.size}:${Math.trunc(info.mtimeMs)}`
  } catch {
    return `missing:${file}`
  }
}

function isTransient(error) {
  const message = String(error?.message ?? error)
  const code = String(error?.code ?? '')
  if (['ECONNREFUSED', 'ECONNRESET', 'ETIMEDOUT', 'EPIPE', 'ENOTFOUND'].includes(code)) return true
  if (/socket hang up|ECONNREFUSED|ECONNRESET|超时|fetch failed|HTTP 5\d\d/i.test(message)) return true
  return false
}

function abortError(signal) {
  const reason = signal?.reason
  if (reason instanceof Error) return reason
  return Object.assign(new Error(typeof reason === 'string' && reason ? reason : '已取消'), { name: 'AbortError' })
}

export function apply(ctx, rawConfig) {
  const config = normalizeConfig(rawConfig)
  const log = makeLogger(config)
  const profileName = resolveProfile(config)
  const profile = PROFILES[profileName]
  const state = {
    startedAt: Date.now(),
    cacheHits: 0,
    sharedHits: 0,
    failures: 0,
    retries: 0,
    runs: 0,
    lastRuns: [],
  }
  let disposed = false
  let cache = null
  let queue = null
  let inflight = null

  async function ensureCollab() {
    if (cache !== null) return
    cache = new ResultCache({
      dir: config.cacheDir || path.join(DATA_DIR, 'cache'),
      maxEntries: config.cacheMaxEntries,
      maxAgeMs: config.cacheMaxAgeHours * 3600 * 1000,
      log: log.warn,
    })
    await cache.init()
    queue = new SerialQueue({ concurrency: config.maxConcurrency })
    inflight = new Inflight()
  }

  function record(run) {
    state.lastRuns.unshift(run)
    if (state.lastRuns.length > 10) state.lastRuns.pop()
  }

  async function cacheKey(kind, args) {
    const init = await fileStamp(args?.initImage)
    const mask = await fileStamp(args?.mask)
    return sha256(JSON.stringify({ v: 1, kind, profile: profileName, args: canonicalArgs(args), init, mask }))
  }

  function wrap(definition, kind) {
    if (definition === null || definition === undefined || typeof definition.execute !== 'function') return false
    if (definition.__sdTurboPatched === true) return true
    const original = definition.execute
    const wrapped = async (args, exec) => {
      const signal = exec?.signal
      try {
        await ensureCollab()
        const tuned = config.autoTune ? tuneArgs(args, kind, profileName) : { ...(args ?? {}) }
        const cacheable = config.cacheEnabled && Number.isFinite(tuned?.seed)
        const key = cacheable ? await cacheKey(kind, tuned) : ''
        if (cacheable && args?.force !== true) {
          const hit = await cache.get(key)
          if (hit !== null) {
            state.cacheHits += 1
            record({ at: Date.now(), kind, cached: true, ms: 0, seed: tuned.seed })
            return { ...hit, cached: true, eta: 0 }
          }
        }
        const runOnce = async () => {
          const started = Date.now()
          let attempt = 0
          for (;;) {
            attempt += 1
            try {
              const value = await original.call(definition, tuned, exec)
              if (cacheable) await cache.put(key, value)
              state.runs += 1
              record({ at: Date.now(), kind, cached: false, ms: Date.now() - started, seed: value?.seed, attempts: attempt })
              return { ...value, cached: false }
            } catch (error) {
              if (signal?.aborted || error?.name === 'AbortError') throw abortError(signal)
              if (attempt <= config.retryAttempts && isTransient(error)) {
                state.retries += 1
                log.warn(`${kind} 第 ${attempt} 次失败（${String(error?.message ?? error).slice(0, 100)}），重试`)
                await new Promise((resolve) => setTimeout(resolve, config.retryDelayMs * attempt))
                continue
              }
              state.failures += 1
              throw error
            }
          }
        }
        if (config.dedupe) {
          const shared = inflight.run(key || `${kind}:${Date.now()}:${Math.random()}`, runOnce)
          if (shared.shared) state.sharedHits += 1
          return await shared.promise
        }
        return await queue.run(runOnce, { signal, label: kind })
      } catch (error) {
        throw error instanceof Error ? error : new Error(String(error))
      }
    }
    try {
      Object.defineProperty(definition, 'execute', { value: wrapped, configurable: true, writable: true })
      Object.defineProperty(definition, '__sdTurboPatched', { value: true, configurable: true, writable: true })
      log.info(`已接管 ${definition.name}（缓存/合并/队列/重试）`)
      return true
    } catch (error) {
      log.warn(`接管 ${definition.name} 失败：${error?.message ?? error}`)
      return false
    }
  }

  // ── 状态工具 ────────────────────────────────────────────────────────
  const statusTool = {
    name: 'sd_turbo_status',
    description: '查看 SD Turbo 状态：档位、后端在线/模型、缓存命中、队列、最近耗时。action=purge 清缓存索引（不删图）；action=warm 发一次 1 步 64px 预热（让模型驻留）。',
    parameters: {
      type: 'object',
      additionalProperties: false,
      properties: {
        action: { type: 'string', enum: ['status', 'purge', 'warm'], description: '默认 status。' },
      },
    },
    timeoutMs: 120000,
    output: {
      schema: {
        type: 'object',
        additionalProperties: true,
        properties: {
          ok: { type: 'boolean' },
          summary: { type: 'string' },
          profile: { type: 'string' },
          online: { type: 'boolean' },
          model: { type: 'string' },
          cache: { type: 'object', additionalProperties: true },
          queue: { type: 'object', additionalProperties: true },
          counters: { type: 'object', additionalProperties: true },
          lastRuns: { type: 'array', items: { type: 'object', additionalProperties: true } },
        },
        required: ['ok', 'summary', 'profile'],
      },
      render: (_args, value) => [{ type: 'text', text: value.summary }],
    },
    async execute(args, exec) {
      await ensureCollab()
      const action = typeof args?.action === 'string' ? args.action : 'status'
      if (action === 'purge') {
        const removed = await cache.purge()
        return { ok: true, profile: profileName, summary: `已清空缓存索引（${removed} 条），图片没删。`, cache: cache.stats() }
      }
      let online = false
      let model = ''
      try {
        const response = await fetch(`${config.sdUrl}/sdapi/v1/options`, { signal: exec?.signal })
        online = response.ok
        if (online) model = String((await response.json())?.sd_model_checkpoint ?? '')
      } catch {
        online = false
      }
      if (action === 'warm') {
        if (!online) return { ok: false, profile: profileName, online, summary: 'SD 不在线，先启动（sd_server action=start）。' }
        const started = Date.now()
        try {
          const response = await fetch(`${config.sdUrl}/sdapi/v1/txt2img`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ prompt: 'warmup', steps: 1, width: 64, height: 64, cfg_scale: 1, sampler_name: 'Euler', seed: 1, save_images: false }),
            signal: exec?.signal,
          })
          if (!response.ok) throw new Error(`HTTP ${response.status}`)
          return { ok: true, profile: profileName, online, summary: `预热完成（${((Date.now() - started) / 1000).toFixed(1)}s），模型已驻留。`, cache: cache.stats() }
        } catch (error) {
          return { ok: false, profile: profileName, online, summary: `预热失败：${error?.message ?? error}` }
        }
      }
      const cacheStats = cache.stats()
      const summary = [
        `档位 ${profileName}（${profile.steps} 步 / cfg ${profile.cfgScale}${profile.lcm ? ' / LCM' : ''}）`,
        `SD ${online ? '在线' : '不在线'}${model ? `（${model}）` : ''}`,
        `缓存 ${cacheStats.entries} 条，命中 ${state.cacheHits}`,
        `累计 ${state.runs} 次（合并 ${state.sharedHits} / 重试 ${state.retries} / 失败 ${state.failures}）`,
        state.lastRuns[0] ? `上次 ${state.lastRuns[0].cached ? '缓存命中' : `${(state.lastRuns[0].ms / 1000).toFixed(1)}s`}` : '还没有记录',
      ].join('；')
      return {
        ok: online,
        profile: profileName,
        online,
        model,
        summary: `${summary}。`,
        cache: cacheStats,
        queue: queue.stats(),
        counters: { ...state },
        lastRuns: state.lastRuns,
      }
    },
  }

  try {
    ctx.tools.register(statusTool)
  } catch (error) {
    log.error(`注册 sd_turbo_status 失败：${error?.message ?? error}`)
  }

  // 包住桥的工具（桥可能晚一点注册，定期补挂）
  const patchAll = () => {
    if (disposed) return
    for (const toolName of ['sd_draw', 'sd_img2img', 'sd_inpaint']) {
      let definition = null
      try {
        definition = ctx.tools.get(toolName) ?? null
      } catch {
        definition = null
      }
      if (definition !== null) wrap(definition, toolName)
    }
  }
  const first = setTimeout(patchAll, 600)
  first.unref?.()
  const timer = setInterval(patchAll, 15000)
  timer.unref?.()

  if (config.prewarm) {
    setTimeout(async () => {
      if (disposed) return
      try {
        const response = await fetch(`${config.sdUrl}/sdapi/v1/options`, { signal: AbortSignal.timeout(3000) })
        log.info(response.ok ? 'SD 在线' : `SD 未就绪（HTTP ${response.status}）`)
      } catch {
        log.info('SD 未就绪（首次出图时桥会尝试拉起）')
      }
    }, 2500).unref?.()
  }

  try {
    ctx.effect(() => () => {
      disposed = true
      clearInterval(timer)
    })
  } catch {
    /* 裁剪版宿主 */
  }

  log.info(`SD Turbo 已加载：档位 ${profileName}，缓存 ${config.cacheEnabled ? '开' : '关'}，合并 ${config.dedupe ? '开' : '关'}`)
}

export const __internal = { tuneArgs, canonicalArgs, normalizeConfig, resolveProfile, PROFILES }

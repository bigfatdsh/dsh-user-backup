/**
 * dsh-sd-turbo 自测（不需要 SD）：
 *   node test/run.mjs
 * 用一个假的 sd_draw 工具验证：缓存、并发合并、串行、重试、档位注入、状态。
 */
import assert from 'node:assert/strict'
import { mkdtemp, rm, writeFile } from 'node:fs/promises'
import os from 'node:os'
import path from 'node:path'

import { apply, __internal } from '../index.js'

const results = []
const dirs = []
async function tempDir() {
  const dir = await mkdtemp(path.join(os.tmpdir(), 'sd-turbo-'))
  dirs.push(dir)
  return dir
}
async function test(name, fn, timeoutMs = 20000) {
  const started = Date.now()
  let timer = null
  try {
    await Promise.race([
      fn(),
      new Promise((_, reject) => { timer = setTimeout(() => reject(new Error(`超时（${timeoutMs}ms）`)), timeoutMs) }),
    ])
    results.push({ name, ok: true })
    console.log(`✔ ${name} (${Date.now() - started}ms)`)
  } catch (error) {
    results.push({ name, ok: false, error })
    console.log(`✖ ${name} (${Date.now() - started}ms)`)
    console.log(`  ${error?.message ?? error}`)
  } finally {
    if (timer !== null) clearTimeout(timer)
  }
}
function makeCtx() {
  const tools = new Map()
  return {
    tools: {
      register(definition) {
        if (tools.has(definition.name)) throw new Error(`重复工具 ${definition.name}`)
        tools.set(definition.name, definition)
        return () => tools.delete(definition.name)
      },
      get: (name) => tools.get(name),
    },
    get: () => undefined,
    effect: (fn) => { fn() },
    toolsMap: tools,
  }
}

await test('档位注入：balanced 8 步、fast 4 步 + LCM、显式参数不覆盖', () => {
  const balanced = __internal.tuneArgs({ prompt: 'x', seed: 1 }, 'sd_draw', 'balanced')
  assert.equal(balanced.steps, 8)
  assert.equal(balanced.cfgScale, 7)
  assert.equal(balanced.sampler, 'DPM++ 2M Karras')
  assert.equal(balanced.lora, undefined)

  const fast = __internal.tuneArgs({ prompt: 'x', seed: 1 }, 'sd_draw', 'fast')
  assert.equal(fast.steps, 4)
  assert.equal(fast.cfgScale, 1)
  assert.equal(fast.sampler, 'LCM')
  assert.deepEqual(fast.lora, [{ name: 'lcm-lora-sdv1-5', weight: 1 }])

  const explicit = __internal.tuneArgs({ prompt: 'x', steps: 12, cfgScale: 6, sampler: 'Euler', lora: ['add_detail'] }, 'sd_draw', 'fast')
  assert.equal(explicit.steps, 12)
  assert.equal(explicit.sampler, 'Euler')
  assert.deepEqual(explicit.lora, ['add_detail', { name: 'lcm-lora-sdv1-5', weight: 1 }])
})

await test('档位选择：8GB 机器 auto → balanced', () => {
  assert.equal(__internal.resolveProfile({ profile: 'auto' }), os.totalmem() <= 10 * 1024 ** 3 ? 'balanced' : 'quality')
  assert.equal(__internal.resolveProfile({ profile: 'fast' }), 'fast')
})

await test('缓存 + 并发合并 + 状态', async () => {
  const dir = await tempDir()
  const image = path.join(dir, 'out.png')
  await writeFile(image, Buffer.from([0x89, 0x50, 0x4e, 0x47, 1, 2, 3, 4]))
  let calls = 0
  let lastArgs = null
  const ctx = makeCtx()
  const fakeDraw = {
    name: 'sd_draw',
    async execute(args) {
      calls += 1
      lastArgs = args
      await new Promise((resolve) => setTimeout(resolve, 120))
      return { path: image, files: [image], width: 512, height: 512, seed: args.seed, seconds: 0.12 }
    },
  }
  ctx.tools.register(fakeDraw)
  apply(ctx, { profile: 'fast', cacheDir: path.join(dir, 'cache'), prewarm: false, verbose: false })
  try {
    await new Promise((resolve) => setTimeout(resolve, 700))
    const first = await fakeDraw.execute({ prompt: 'x', seed: 1 }, {})
    assert.equal(first.cached, false)
    assert.equal(calls, 1)
    assert.equal(lastArgs.steps, 4, '应注入 fast 档 4 步')
    assert.equal(lastArgs.sampler, 'LCM')

    const hit = await fakeDraw.execute({ prompt: 'x', seed: 1 }, {})
    assert.equal(hit.cached, true)
    assert.equal(calls, 1, '第二次应命中缓存')
    assert.equal(hit.seconds, 0)

    const [a, b] = await Promise.all([
      fakeDraw.execute({ prompt: 'concurrent', seed: 2 }, {}),
      fakeDraw.execute({ prompt: 'concurrent', seed: 2 }, {}),
    ])
    assert.equal(calls, 2, '并发相同请求只执行一次')
    assert.equal(a.path, b.path)

    const status = await ctx.toolsMap.get('sd_turbo_status').execute({}, {})
    assert.equal(status.profile, 'fast')
    assert.match(status.summary, /缓存/)
    assert.equal(status.cache.hits >= 1, true)

    const purged = await ctx.toolsMap.get('sd_turbo_status').execute({ action: 'purge' }, {})
    assert.equal(purged.ok, true)
  } finally {
    await rm(dir, { recursive: true, force: true })
  }
})

await test('重试：第一次 ECONNRESET，第二次成功', async () => {
  const dir = await tempDir()
  const image = path.join(dir, 'retry.png')
  await writeFile(image, Buffer.from([0x89, 0x50, 0x4e, 0x47, 1]))
  let calls = 0
  const ctx = makeCtx()
  const fake = {
    name: 'sd_draw',
    async execute(args) {
      calls += 1
      if (calls === 1) throw Object.assign(new Error('socket hang up'), { code: 'ECONNRESET' })
      return { path: image, files: [image], width: 8, height: 8, seed: args.seed, seconds: 1 }
    },
  }
  ctx.tools.register(fake)
  apply(ctx, { profile: 'balanced', cacheDir: path.join(dir, 'cache'), prewarm: false, retryDelayMs: 50 })
  try {
    await new Promise((resolve) => setTimeout(resolve, 700))
    const value = await fake.execute({ prompt: 'retry', seed: 3 }, {})
    assert.equal(calls, 2)
    assert.equal(value.path, image)
  } finally {
    await rm(dir, { recursive: true, force: true })
  }
})

for (const dir of dirs) await rm(dir, { recursive: true, force: true }).catch(() => {})
const failed = results.filter((item) => !item.ok)
console.log('')
console.log(`通过 ${results.length - failed.length}/${results.length}`)
process.exit(failed.length === 0 ? 0 : 1)

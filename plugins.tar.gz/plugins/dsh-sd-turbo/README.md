# dsh-sd-turbo

[dsh-sd-bridge-mac](../dsh-sd-bridge-mac) 的加速层。不重写生图链路，只包住 `sd_draw` / `sd_img2img` / `sd_inpaint` 的 `execute`，工具名和参数都不变。

## 做了什么

| 机制 | 效果 |
|---|---|
| 结果缓存 | 同提示词 + 同参数 + 同种子 → 约 0.01 秒返回上次那张，不碰 SD |
| 并发合并 | 两个相同请求只提交一次，后来的人等同一份结果 |
| 串行队列 | SD 一次只跑一个任务，不抢显存 |
| 自动调参 | 8GB 机器默认 8 步 / cfg 7 / DPM++ 2M Karras；`fast` 档 4 步 + LCM LoRA + cfg 1 |
| 失败重试 | 连接断开 / 超时自动重试一次 |
| 状态与预热 | `sd_turbo_status` 看档位、缓存、队列；`action=warm` 发 1 步 64px 预热 |

## 档位

`profile: auto`（默认）按内存选：≤10GB → `balanced`，更大 → `quality`。

- `fast`：4 步 / cfg 1 / LCM + `lcm-lora-sdv1-5`（约 17–19 秒，画质略降）
- `balanced`：8 步 / cfg 7 / DPM++ 2M Karras（约 28–36 秒）
- `quality`：20 步（62–113 秒）

调用方显式传了 `steps` / `cfgScale` / `sampler` / `lora` 就不会被覆盖。

## 配置

`cordis.patch.yml`：`profile`、`cacheEnabled`、`cacheMaxEntries`、`cacheMaxAgeHours`、`dedupe`、`maxConcurrency`、`retryAttempts`、`prewarm`、`autoTune`、`cacheDir`。

## 实测（M1 8GB）

| 场景 | 耗时 |
|---|---|
| 20 步基线 | 63–113 秒 |
| 8 步（balanced） | 28–36 秒（约 2.3×） |
| 4 步 LCM（fast） | 17–19 秒（约 3.7×） |
| 缓存命中 | ≈0.01 秒 |
| 并发两个相同请求 | 只跑 1 次 |

## 自测

```bash
node test/run.mjs   # 档位注入 / 缓存 / 合并 / 重试，4 项
node ../dsh-sd-bridge-mac/test/run.mjs  # 桥的 8 项
```

# 本目录相对上游的改动（dsh-fish 0.6.1）

上游：`github.com/ssamurias/dsh-fish`，commit `356b200aa899dd1fadf4d100cbcf677205437bf9`（2026-10-27）。
本目录 = 上游 `lib/ media/ test/ package.json cordis.patch.yml LICENSE README.md AGENTS.md CHANGELOG.md`，
外加下面这一处**本地补丁**。升级上游时把这条补丁重新贴回去即可。

## 补丁：桥接会话就是她本人，但要说清「现在在哪」（`lib/identity.js`）

**背景**：按需求，微信 / QQ 的会话必须**就是她本人**——同一个身份、同一套工具、
同一份记忆、同一条成长事件流。实现上靠的是上游本来就有的判断：桥接会话的 cwd 是
`~/.dsh-fish/home`，`isHerAgent(agent, herDir)` 只看 cwd，所以它会命中：

* 身份段（`HER_IDENTITY_SECTION`）自动挂到桥接会话；
* `tools.restrict` 把桥接会话的工具面收窄成她自己的那几个（`HER_TOOLS` ∪ `config.tools.allow`）。

这两件事正是「她本人」的实现方式，**不需要改 `restrict.js`**。

**补丁内容**：身份段按通道补一段说明（`channelNoteOf(agent)`）。原因有三条：

1. 身份文档里写着「## 这个房间 这是我自己的地方。我能在这里说话，能读能写」——
   放在微信里她会把聊天当屋子，去调并不存在的读写/shell 工具；
2. 聊天里不需要写日记、也不需要汇报，需要明确说「这不是你的房间」；
3. 预设里那段「贱兮兮、爱吐槽」的人设和她的自我认知不是一回事，要说清「那是口吻，
   你的来历与记忆以身份段为准」。

补丁只在 `wechat-` / `qq-` 前缀的会话上追加，她自己的会话（`session-*`）返回空串，
行为与上游完全一致。

## 曾经加过、后来撤掉的补丁（留个记认）

2026-10-28 白天曾把桥接会话**排除**在「她本人」之外（`isHerAgent` 里拦 `wechat-` 前缀），
因为当时出现两个问题：微信里收到 `<｜｜DSML｜｜ invoke name="bash">` 的原文、
以及按需加载把她的 8 个非核心工具全藏起来导致首轮空工具表。这两条的真正根因在别处，
已经分别修掉：

* 忆时的 lean 指令要求「用 shell 执行命令」，而微信预设没有 shell →
  `dsh-fish-memory` 那层把忆时 `instructions` 关掉，并给 lean 指令加了「没有 shell 就不许发命令」的警告；
* `dsh-exec-optimizer` 的按需加载在「一个核心工具都不剩」时会把工具全藏起来 →
  改成**不藏**（见该包 README 的「硬约束」一节）。

根因修完，桥接会话重新交还给「她本人」这条路。

## 运行时配置（不在代码里）

`~/.dsh-fish/config.json`：

* `browse.enabled` / `video.enabled` / `comment.enabled` = false —— 她自己的刷站、看画面、
  评论区说话都交给 `dsh-bili-scroll`（同一个号说话，两套迟早发重复评论）；
* `tools.allow` = `["bili_status", "memory"]` —— 桥接会话的工具面会按 `HER_TOOLS` 收窄，
  不在白名单里的会被兜底守卫拦掉，所以只读的刷站状态和记忆库必须显式放行。

改法见 `../dsh-fish-memory/tools/fish-browse-off.mjs`（必须退出应用再改，否则插件会写回）。

## 聊天也算「今天醒过」（2026-10-29）

`lib/status.js` 的 `wokeToday` 原本只数 `meta wake:` 事件——那是定时唤醒写的。桥接聊天不走那条路，
所以哪怕聊了一整天，设置页仍然显示「沉在水底 / 还在睡觉」。

补丁（标记 `FISH_WOKE_AFTER_CHAT`）：`wokeToday = counts.wakes > 0 || talkedToday`，
`talkedToday` = 今天的事件流里有 `voice`（他说的/评论区的）或 `utterance`（她说的）。

为什么不在聊天时补写一条 `wake:` 事件：那会占掉当天的唤醒配额（`wakesPerDay`），把她晚上的
定时唤醒挤掉，还会往账本里写假事件。状态是"看出来的"，不是"记出来的"。

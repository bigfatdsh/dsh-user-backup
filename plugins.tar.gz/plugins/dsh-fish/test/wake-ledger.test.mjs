import { test } from 'node:test'
import assert from 'node:assert/strict'
import { mkdtempSync, readFileSync, rmSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'

import { claimWake, decideWake, ledgerFile, readLedger, releaseWake } from '../lib/wakeledger.js'
import { pickWakeStubs } from '../lib/home.js'

const HOUR = 3_600_000
const DAY = 86_400_000

function tmpRoot() {
  return mkdtempSync(join(tmpdir(), 'fish-wake-'))
}

test('账本：每天上限到了就不叫', () => {
  const now = Date.UTC(2026, 10, 13, 12)
  const ledger = { day: '2026-11-13', countToday: 2, lastAt: now - 5 * HOUR }
  const r = decideWake(ledger, { now, day: '2026-11-13', sessionId: 's1', maxPerDay: 2 })
  assert.equal(r.ok, false)
  assert.match(r.why, /上限/)
})

test('账本：两次之间不到 3 小时不叫', () => {
  const now = Date.UTC(2026, 10, 13, 12)
  const ledger = { day: '2026-11-13', countToday: 1, lastAt: now - 20 * 60_000 }
  const r = decideWake(ledger, { now, day: '2026-11-13', sessionId: 's1' })
  assert.equal(r.ok, false)
  assert.match(r.why, /分钟/)
})

test('账本：换了一天就重新计数；间隔够了就放行', () => {
  const now = Date.UTC(2026, 10, 14, 9)
  const ledger = { day: '2026-11-13', countToday: 2, lastAt: now - 4 * HOUR }
  const r = decideWake(ledger, { now, day: '2026-11-14', sessionId: 's1' })
  assert.equal(r.ok, true)
})

test('账本：手动强制可以越过间隔与上限，但仍然记账', async () => {
  const root = tmpRoot()
  try {
    const now = Date.UTC(2026, 10, 13, 12)
    await claimWake(root, { now, day: '2026-11-13', kind: 'timer', sessionId: 's1' })
    const forced = await claimWake(root, { now: now + 60_000, day: '2026-11-13', kind: 'manual', sessionId: 's1', force: true })
    assert.equal(forced.ok, true)
    const ledger = readLedger(root)
    assert.equal(ledger.countToday, 2)
    assert.equal(ledger.lastKind, 'manual')
  } finally {
    rmSync(root, { recursive: true, force: true })
  }
})

test('账本：领取先落盘；发送失败归还后还能再叫', async () => {
  const root = tmpRoot()
  try {
    const now = Date.UTC(2026, 10, 13, 12)
    const first = await claimWake(root, { now, day: '2026-11-13', sessionId: 's1' })
    assert.equal(first.ok, true)
    const file = ledgerFile(root)
    const disk = JSON.parse(readFileSync(file, 'utf8'))
    assert.equal(disk.countToday, 1)
    const blocked = await claimWake(root, { now: now + 10 * 60_000, day: '2026-11-13', sessionId: 's1' })
    assert.equal(blocked.ok, false, '十分钟后不该再叫')
    assert.equal(releaseWake(root, first), true)
    const again = await claimWake(root, { now: now + 11 * 60_000, day: '2026-11-13', sessionId: 's1' })
    assert.equal(again.ok, true, '失败归还之后应该放行')
  } finally {
    rmSync(root, { recursive: true, force: true })
  }
})

test('空壳会话：只清「空白 + 创建时间贴着 wake + 不是屋子会话」', () => {
  const wakeAt = Date.UTC(2026, 10, 13, 12, 4, 44)
  const items = [
    { sessionId: 'session-home', blank: true, createdAt: wakeAt }, // 屋子会话，绝不碰
    { sessionId: 'session-stub', blank: true, createdAt: wakeAt + 2_000 }, // 典型空壳
    { sessionId: 'session-later', blank: true, createdAt: wakeAt + 30 * 60_000 }, // 离 wake 太远，可能是用户自己建的
    { sessionId: 'session-chatty', blank: false, createdAt: wakeAt + 1_000 }, // 有内容
    { sessionId: 'session-nodate', blank: true },
    { sessionId: 'wechat-abc', blank: true, createdAt: wakeAt + 1_000 }, // 桥接会话，不碰
  ]
  const picked = pickWakeStubs(items, { keepSessionId: 'session-home', wakeTimes: [wakeAt] })
  assert.deepEqual(picked, ['session-stub'])
})

test('账本打底：今天已经 wake 过两次，重启后不会立刻再来一次', async () => {
  const { appendFileSync, mkdirSync } = await import('node:fs')
  const root = tmpRoot()
  try {
    mkdirSync(join(root), { recursive: true })
    const now = Date.UTC(2026, 10, 13, 12)
    const lines = [
      { type: 'meta', ts: new Date(now - 4 * HOUR).toISOString(), text: 'wake:2026-11-13 absence_probe' },
      { type: 'meta', ts: new Date(now - 1 * HOUR).toISOString(), text: 'wake:2026-11-13 want_or_not' },
    ]
    appendFileSync(join(root, 'events.jsonl'), lines.map((l) => JSON.stringify(l)).join('\n') + '\n')
    const { seedLedgerFromEvents } = await import('../lib/wakeledger.js')
    const seeded = await seedLedgerFromEvents(root, { now })
    assert.equal(seeded.seeded, true)
    assert.equal(seeded.countToday, 2)
    const r = decideWake(readLedger(root), { now, day: '2026-11-13', sessionId: 's1' })
    assert.equal(r.ok, false, '打底之后今天不该再叫')
  } finally {
    rmSync(root, { recursive: true, force: true })
  }
})

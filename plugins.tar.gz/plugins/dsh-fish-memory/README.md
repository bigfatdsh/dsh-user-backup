# dsh-fish-memory · 大肥鱼的独立记忆库

微信里说的、QQ 里说的、她屋子里说的，**是同一份记忆**。
而且这份记忆会随时间自然淡忘：细节先没了，只剩一句印象；再久一点，只有她主动去翻才翻得到。

这个包同时是两样东西：

| 角色 | 位置 |
|---|---|
| 一个 Cordis 插件（记忆库本体） | `lib/index.js` |
| 一个 bundle（覆盖层：预设副本 + 桥接重绑 + 挂载记忆库） | `cordis.patch.yml`（生成物） |

## 为什么要它

桥接的每个聊天各自是一个会话。会话之间本来互不相识：在 QQ 里说过「明天陪我去复查」，
去微信问她，她只能回答不知道。这不是模型笨，是两条会话各写各的上下文。

记忆库把「记忆」从会话里搬到**工作区**上：只要会话的 cwd 是同一个工作区，
读写的就永远是同一份库。

```
微信会话 ──┐
QQ 会话  ──┼── <工作区>/.memory/memories.jsonl ── 下一轮 system prompt 的索引
她的房间 ──┘
```

写入是同步追加，读取带 (mtime,size) 校验：**没有定时同步、没有 IPC、没有后台任务**。
所以「实时互通」不是靠推送，而是靠它们本来就看的同一份文件。

## 安装

```bash
dsh plugin --profile desktop add link:<这个目录>
```

包被加进 profile 后会同时登记为 bundle，它的覆盖层做三件事：

1. 在宿主根挂记忆库插件（`id: fish-memory`），只对 `~/.dsh-fish/home` 生效；
2. 插入一份「鲸鱼娘·大肥鱼（记忆库）」预设（`id: whale-fish`）：人设、忆时、精简工具集照搬；
3. 把 `wechat-media` 行（微信 + QQ 同一条 row）重绑到该预设，并把 `cwd` 固定到 `~/.dsh-fish/home`。

改完要**重启桌面应用**（组合层在启动时装配），然后：

* 新会话自动落在「大肥鱼的家」，带 `memory` 工具；
* 老会话还挂在旧工作区，在每个聊天里发一次 `/new` 就会搬过来（旧对话文件仍在磁盘上）。

## 记忆是什么样

一条记忆是 JSONL 里的一行：

```json
{"t":"m","id":"m…","at":1793167138300,"kind":"pref","text":"主人喜欢喝冰美式，不加糖",
 "gist":"喜欢冰美式","w":1.2,"ch":"qq","sid":"wechat-…","src":"user"}
```

注意 `ch`：桥接的会话 id 全是 `wechat-<hash>`，QQ 也走同一个哈希函数，光看前缀分不出通道。
所以 `ch` 是反查桥接自己的 `routes.json`（账号 → 聊天 → 会话 id）得到的：
`qq-<appId>` 记 `qq`，`<hash>-im-bot` 记 `wechat`。查不到才退回前缀判断，绝不谎报来源。

| 字段 | 含义 |
|---|---|
| `kind` | `pref` 偏好 / `fact` 事实 / `event` 事件 / `episode` 流水 / `impression` 折叠后的印象 |
| `w` | 初始重量（偏好最重，流水最轻） |
| `ch` | 哪条通道写的（回忆时能看到「这是 QQ 说的」） |
| `at` / `lastHit` | 首次发生时间 / 上次被想起时间（衰减从后者算） |

遗忘不是删行，是**重量随时间衰减**：

```
当前重量 = w × 0.5 ^ (闲置天数 / 半衰期)
半衰期：偏好 60 天 · 事实 24 天 · 事件 10 天 · 流水 4 天
```

重量跨过阈值，形态就降一级：

| 重量 | 形态 |
|---|---|
| ≥ 0.45 | 原话，能复述细节 |
| 0.12 ~ 0.45 | 只剩一句印象 |
| < 0.12 | 索引里不再出现，只有主动 `recall` 才翻得到 |

另有一条**折叠**：老流水（7 天以上、重量 < 0.4）按天压成一条印象记录，子记录标成已折叠。
历史不删、不重写，只是不再被想起 —— 这就是「只留大致印象」。

被 `recall` 翻到会加权（间隔重复），所以「被反复说起的」会固化，「说一次就忘的」会淡掉。

## 记忆怎么写进来的

全规则，零模型调用（每条消息 < 0.01ms）：

* 用户消息里像事实的句子：偏好、身份、计划、纠正、显式「记住…」，每条消息最多 3 条；
* 助手自己的承诺（「说好了，我以后…」），只算明确承诺；
* 每一轮对话留一条 `episode` 流水，保证「所有会话都写进记忆库」真的成立；
* 同一句话 30 天内又说一遍 → 加固已有那条，不新增；
* 系统注入（运行时上下文、技能目录、记忆索引）永远不入库。

`memory` 工具四个动作：`recall`（翻过去）、`remember`（明确记住）、`forget`（忘掉匹配的）、`stats`（看还记得多少）。

## 极致优化的账

`node tools/bench.mjs`（5000 条记忆，本机）：

| 热路径 | p50 | 说明 |
|---|---|---|
| 写入一条 | 0.045 ms | 一次 append，无库无事务 |
| 索引组装 | 0.004 ms | 一分钟内复用缓存；文件变了才重算 |
| 检索一次 | 0.62 ms | 词元倒排取候选，再按重量排序 |
| 抽取一条消息 | 0.003 ms | 纯正则 |
| 冷载入整库 | 33 ms | 只在进程第一次读时发生 |

每轮固定开销 ≈ **0.12 ms**，且不花任何 token。

省 token 的三个决定：

* 索引只注入 ≤ 700 字，不是整库；
* 只给「cwd 对得上」的会话装工具与索引段，别的会话一个 token 都不多付；
* 一个 `memory` 工具带四个动作，而不是四个工具四份 schema。

## 目录

```
lib/index.js     装配：事件写入、按工作区装工具与索引段、memory 工具
lib/store.js     只追加的落盘层 + 内存快照 + 折叠
lib/decay.js     重量 / 半衰期 / 形态 / 分词（纯函数）
lib/extract.js   该记什么（纯规则）
lib/channels.js  会话 id → 微信/QQ/本地（读桥接 routes.json，mtime 缓存）
lib/bili.js      刷B站账本 → 记忆（digest 与 comments，游标幂等）
tools/gen-preset.mjs   生成 cordis.patch.yml
tools/bench.mjs        热路径基准
tools/fish-browse-off.mjs  关掉大肥鱼自己的刷站（交棒给 dsh-bili-scroll）
tools/backfill.mjs     历史会话补进记忆库（剥信封、按 cwd 选工作区）
tools/backfill-chats.mjs   历史聊天补进她的账本（voice + chat-log）
tools/patch-sd.mjs     SD 桥接：启动参数 / stop 兜底 / 开机不预热
tools/patch-bili.mjs   刷 B 站：内置 Python MCP 闲置回收
tools/patch-orb.mjs    orb：截图失败不拖垮整轮
tools/patch-bridge.mjs 桥接：所有渠道共用一个会话
test/memory.test.mjs   26 条行为测试（node --test）
```

```bash
node --test test/*.test.mjs    # 行为
node tools/bench.mjs 5000     # 基准
node tools/gen-preset.mjs --check   # 覆盖层是否与生成器一致
```

## 微信 / QQ 里那个就是她本人

桥接会话的 `cwd` 是 `~/.dsh-fish/home`，所以 `dsh-fish` 的 `isHerAgent` 会命中它们：
身份段自动挂上、工具面收窄成她自己的那几个（`HER_TOOLS` ∪ `config.tools.allow`）。
我们这一层只补两件事，让「她本人」在聊天里说得通：

* `config.tools.allow` 加 `memory`（否则兜底守卫会拦掉记忆库工具）；
* 身份段按通道补一句「这不是你的房间、聊天里没有读写/shell、要回忆跨渠道用 memory」
  （见 `../dsh-fish/PATCHES.md`）。

于是四个「同」同时成立：同身份、同工具、同记忆库、同 `events.jsonl` 成长流——
她在微信里说的、在屋子里想的，写的是同一条事件流（用 `growth_commit`），
记忆库索引在两边都能看见。

代价是她在聊天里也只有她那几个工具（没有 web 搜索、没有 todo 文件那一套）。
要放开就写 `tools.allow`；不想放开，这就是她本来的手。

## 所有渠道共用一个会话（她本人）

微信、QQ、她自己的房间现在是**同一个会话**：

* 桥接的 `sessionIdFor` 被本地补丁改成读 `~/.dsh-fish/home.json` 的 `sessionId`
  （`tools/patch-bridge.mjs`，幂等，`--check` / `--revert` 都有）；
* `dsh-fish` 的 `home.json` 指向同一个会话，于是她自己的唤醒和聊天进的是同一条上下文；
* 她的会话跑 `fish-home` 预设（本包生成的覆盖层里那一行）：bash、桌面 GUI、
  网页、压缩，**外加「大肥鱼」那份人设**——人设是她的默认初始人格（从预设副本里
  程序化抠出来的 `prefix` 块，不手抄），而记忆与判断仍以 `dsh-fish` 的身份段和
  她自己的记录为准（这条协调写在环境提示里）。

工具面（`~/.dsh-fish/config.json` 的 `tools.allow`，共 28 个）：

```
她的 6 个（growth_commit / her_recall / her_leave / bili_*）
+ memory / bili_status
+ bash / read / write / edit / glob / grep / todo_write / job_*
+ web_search / web_fetch
+ 桌面：screenshot / click / drag / hotkey / input_text / list_apps /
        long_press / long_wait / open_app / open_in_browser / open_in_finder / scroll / wait
```

常驻（`dsh-exec-optimizer` 的 `lazyCore`）18 个：默认核心 10 个 + `memory` + 最常用的桌面七项。
她自己的 6 个工具**故意不常驻**——它们是全局注册的，放进 core 会让每一个会话（包括主人
自己的会话）都驮一份 schema；她那边的工具索引 + `load_tools` 一次就取回（实测一轮内完成）。
`drag`/`wait`/网页/文件编辑同样按需取。

单会话带来的两个细节（2026-10-28 实测后补）：

* **通道靠信封认**：会话 id 不再带 `wechat-` 前缀，所以 `[微信 …]` / `[QQ …]` 的信封成了
  唯一可靠的来源（`channelOfEnvelope`），认不出再退回会话 id；
* **唤醒信号不进库**：`（醒一醒。现在是 …）` 这类系统提示会被抽成流水，已加入噪音表跳过；
* 预设里没有人设（`fish-home` 只装手），她的口吻来自身份段和她自己写下的事件——
  想要回「贱兮兮」那套文案，往预设里加一行 `persona` 即可，但会出现两套自我描述。

已知取舍：`/new` 不再换会话（会话跟着 home.json 走）；多个聊天并发时，回复按各自那一轮的
结束投递；上下文会变长，靠预设里的 compaction 收。

## 老会话怎么办：共享一份库

桥接是按聊天记住 `sessionId` 的。只要那个聊天不发 `/new`，它就一直在**旧会话**里跑，
而旧会话的 cwd 不是大肥鱼的家（实测：两个还在 `~/.dsh/profiles/desktop`，一个在
`~/.dsh/wechat-inbox`）。如果库只挂在「家」这一个工作区上，「QQ 说的去微信问」就得
靠每个聊天手动 `/new` 才成立——那不该是记忆互通的前置条件。

所以 `workspace` 支持数组，**数组里的工作区共享第一个工作区下的那个库**：

```yaml
workspace:
  - ~/.dsh-fish/home            # 库的家
  - ~/.dsh/profiles/desktop     # 桥接老会话可能还挂在这里
  - ~/.dsh/wechat-inbox         # 更早的桥接落点
```

于是：新会话（家）、老会话（旧 cwd）读写的都是 `~/.dsh-fish/home/.memory`。
`/new` 只决定「人设与工作区」，不再决定「记不记得住」。

## 桥接信封：一条真机上踩到的坑

桥接把主人说的话包了一层信封再交给模型：

```
[微信 o9cq809I…@im.wechat o9cq809I…@im.wechat]
我是你的主人
```

第一版抽取器把「以 `[` 开头」一律当系统注入丢掉，结果是：**微信/QQ 的对话一条都没进记忆库**
（记忆库里只有刷 B 站的 51 条）。现在改成先 `stripEnvelope` 剥信封、再判噪音，
并且只认真正来自宿主的那几种（`runtime context`、`[tool-result …]` 等）。
`source.kind !== 'user'` 的注入（运行时上下文、记忆索引）依旧整体跳过。

历史对话用 `tools/backfill.mjs` 补：它直接读会话记录（多帧 zstd），按会话头里的 `cwd`
选工作区，剥信封后走同一套抽取规则，时间用事件本身的时间。

```bash
node tools/backfill.mjs --dry-run   # 先看会补多少
node tools/backfill.mjs             # 写进库
```

## 微信 / QQ 的聊天，记进大肥鱼自己的账本

`dsh-fish` 的设计是「只有她提交的才算记录」——`growth_commit` 写 utterance/narration，
别的都不进 `events.jsonl`。所以光聊天，她的「记下的事」一条都不会多，插件设置里也看不见。
这一层补上（`lib/fishevents.js`）：

* **主人说的话** → 一条 `voice` 事件（系统侧写，她写不了）。设置页那行
  「最近读到：「…」」直接读最后一条 voice，所以立刻可见；`voice` 不进 beliefs，
  只有她后来自己说了意思相近的话，那条才算她的判断——插件原有的规矩不变；
* **两边的话** → 纯文本流水 `~/.dsh-fish/chat-log/YYYY-MM-DD.md`（只 append，不喂模型）；
* 只记「她的家」这个工作区，旧桥接目录和测试用的临时目录都不写。

镜像只记得「重启之后」的新消息，之前聊过的用一次性回填：

```bash
node tools/backfill-chats.mjs --dry-run   # 先看会补哪些
node tools/backfill-chats.mjs             # 写进 events.jsonl + chat-log
```

## 刷 B 站：为什么是「读账本」

大肥鱼原来自己刷站（`dsh-fish` 的 `browse` 定时器）。现在刷站这件事交给专门的
`dsh-bili-scroll`（登录、风控、挑片、看字幕、发评论都在它自己家里），我们只做**只读同步**：

```
~/.dsh/bili-duty/digest/YYYY-MM.md  ── 挑了/跳过 + 理由 ──┐
~/.dsh/bili-duty/comments.md        ── 她在评论区说的话 ──┼──> 记忆库（通道 bili）
                                                         ┘
```

* 不碰那个插件的内部：账本是它写给人看的东西，比内部结构稳定得多；
* 幂等：靠「见过的行」游标（`<记忆库>/sources.json`），不是字节偏移；
* 时间用记录里的真实日期（`at`），所以衰减曲线从那天开始算，而不是从同步那一刻；
* 挑了 → 事件（重量 0.85），跳过 → 事件（0.35，忘得快），她自己的评论 → 偏好（1.1）；
* 索引里最多给 3 条位置（`indexBiliLimit`），不然一天十几条会把聊天记忆挤出去。

同步时机：每次组装记忆索引 / 调 `memory` 工具之前，按工作区节流 30 秒。
没新账本时只是两次 stat，开销可以忽略。

配套的一步：把大肥鱼自己的刷站、看画面、评论区说话关掉（三件都交给刷 B 站插件）：

```bash
node tools/fish-browse-off.mjs --status   # 看现状
node tools/fish-browse-off.mjs            # 关掉（宿主开着会拒绝执行，见下）
```

⚠️ 为什么要有这个脚本而不是直接改 JSON：大肥鱼插件**跑着的时候会把自己的设置写回**
`~/.dsh-fish/config.json`，你一边改它一边覆盖，看起来就像「改了没生效」。
所以脚本检测到宿主还开着就拒绝执行——**先退出应用、跑脚本、再打开**，插件启动时读到的
就是「刷站已关」，之后也不会被覆盖。写入本身也是原子的（临时文件 + rename），
免得插件的读取方看到半截 JSON 后回落到默认值。

想让她在需要时主动问刷站插件，把工具加进白名单（默认只开 `bili_status`）：

```json
// ~/.dsh-fish/config.json  →  tools.allow
["bili_status", "bili_search", "bili_subtitle", "bili_comments"]
```

`bili_run` 是「完整跑一轮刷站」，会花额度，默认不给她。

## 一个踩过的 schema 坑

`parameters` 走的是**标准 JSON Schema**：`required` 只能是**对象级数组**（`required: ['action']`）。
写成「每个字段里挂个 `required: true`」是另一种方言（`defineTool` / 大肥鱼那几个插件用它，
宿主会翻译），混进 JSON Schema 里就会原样发给 DeepSeek，报：

```
Invalid schema for function 'memory': true is not of type "array"
```

2026-10-28 真机踩到一次，现在 `test/memory.test.mjs` 里有一条 schema 合法性测试盯着。

## 开机不再拉一堆 python

打开 DSH 后后台常驻的 python 有三类，这次都收掉了：

| 来源 | 为什么会起 | 处理 |
|---|---|---|
| SD WebUI（`webui.sh` → `launch.py`，连带 multiprocessing 的子进程） | 桥接在 `apply()` 里 3 秒后 prewarm，`autoStart` 开着就直接 spawn | **取消开机预热**（`tools/patch-sd.mjs`）。`autoStart` 保留：第一次真正出图才拉起，多花 10–20 秒；想要老行为设 `bootPrewarm: true` |
| 刷 B 站的内置 MCP（`mcp_server.py`） | 一次值班/工具调用把它拉起来，**没有闲置回收**，之后一直挂着 | **闲置 10 分钟自动回收**（`tools/patch-bili.mjs`），下次要用 `ensureMcp()` 自动重启 |
| 忆时（`memory_core.py`） | 每次工具调用临时起一个，跑完即退 | 不用管，本来就不是常驻 |

`python` 也不该出现在启动清单里了：`ps ax | grep python` 在刚打开 DSH 时应该是空的。

## 预设清理（2026-10-29）

原本 8 个预设里有一组真重复：插件包自带的 `whale-lean`（鲸鱼娘·大肥鱼·微信精简）和我们早期
复制出来的 `whale-fish`（记忆库）**插件列表逐项相同**。她现在的会话跑 `fish-home`，两份只服务
于历史会话。

处理（2026-10-29 两轮）：

* 第一轮：我们复制的那份（`preset-whale-fish`）从 `gen-preset` 里删掉；插件包自带那份改名
  「旧·鲸鱼娘·大肥鱼（微信精简）」、`order: 90`；
* 第二轮：连旧的那份也删了（`tools/patch-drop-legacy-preset.mjs`）——它的两层定义
  （`dsh-wechat-media-turbo` + `dsh-yishi-whale`）各删一整块，删空的文件写成 `[]`。
  现在只剩 **6 个预设**：5 个 DSH 自带 + `fish-home`。

人设文案已抽成仓库内资产 `assets/persona.md`：预设删光之后，`gen-preset` 不再依赖任何插件包
（以前是从忆时覆盖层里抠 `prefix: |`）。

一个坑：同一个 preset 被**两层**覆盖层整块重定义——插件包一份、忆时 bundle 又重写一遍（后者胜出）。
只改插件包那份，名字还是旧的；补丁脚本两份都改。

实测现在 7 个预设：5 个 DSH 自带 + 「旧·鲸鱼娘·大肥鱼（微信精简）」+「大肥鱼的家（本体）」，
doctor 的重复扫描不再报重复。

## 声线（2026-10-29）

`wechat_send_voice` 原本只会用 Windows 的 `System.Speech` 合成 —— mac 上直接
`spawn powershell.exe ENOENT`，等于没有声音。`tools/patch-voice.mjs` 补上：

* 合成走 **edge-tts**（默认 `zh-CN-XiaoyiNeural`，中文女声里最俏的一档），出 mp3 直接发；
* 没网/没装就退回系统 `say`（Tingting，22.05k WAV），不会哑；
* 本机没 ffmpeg 也能用：mp3 路径不经过转码，`voiceSupport()` 在 mac 上按 say/edge-tts 判定；
* 她的工具清单里加了 `wechat_send_voice`，环境提示教她「一句两句、想撒娇/道晚安时再发」。

想换声线：改 `darwinSpeak()` 里的默认 voice 即可（备选 `zh-CN-XiaoxiaoNeural`、
`zh-CN-liaoning-XiaobeiNeural` 方言、`zh-CN-XiaomoNeural` 少年音等）。

## 状态与记忆的四个隐蔽 bug（2026-10-29 修）

1. **5–10 分钟的缺口**：`status.js` 里 `ACTIVE_MS`=5 分钟、`IDLE_MS`=10 分钟，中间那段没有分支，
   会直接掉到最后那个 else →「沉在水底」。刚说完话六七分钟去看，就是"睡着"。
2. **过期文案**：`recent` 由最后一条事件（可能是刚到的 `voice`）决定，而 `lastKind` 来自最后一条
   动作（可能是几十分钟前她的发言）→ 会挂着旧的「在想怎么回你」。现在 `voice` 也记成动作
   （`heard`），新增相位 `listening`「在听你说话」，客户端配色 `#0ea5e9`。
3. **day 锚点不一致**：镜像写事件时按"第一条事件的 ts"算第几天，而 `deriveSelf` 的
   `growthDay()` 从 **seed** 起算 24 小时块——头两天能差出几个小时，`deriveSelf` 取 `max(day)`，
   成长节奏就会提前跳一天。镜像已改成从 seed 起算（有单测）。
4. **身份文本只在提交时刷新**：`她的身份.md` 原本只有 `growth_commit` 才刷新，纯聊天的日子不更新。
   镜像现在每天最多刷一次（确定性生成，不调模型；有单测）。

另：B 站评论原话曾被记成「偏好」，会挤掉她自己的判断。现在存成 `heard`（索引里显示「读到」，
半衰期 6 天、权重 0.55），索引单行截到 90 字，评论配额 `indexCommentLimit: 1`。

## 「设置里还在睡觉」是怎么修的

大肥鱼的状态是**看事件流看出来的**（`lib/status.js` 的 `deriveStatus`），`wokeToday` 原本只认
定时唤醒写的 `meta wake:<日期>`。桥接聊天不写这种事件，所以聊了一下午，设置页还写「沉在水底」。

改法（`adapted/dsh-fish/lib/status.js`，标记 `FISH_WOKE_AFTER_CHAT`）：
`wokeToday = counts.wakes > 0 || 今天有 voice/utterance`。也就是说——

* 她收到的话（微信/QQ/GUI，都会落成 `voice`）或她自己说过的话（`utterance`），都算「今天醒过」；
* **不补写假的 `wake:` 事件**：那会吃掉当天唤醒配额、把她晚上的定时唤醒挤掉，还会污染账本；
* 顺手把镜像里「（醒一醒）」这类唤醒提示过滤掉，它不该被记成「他说的话」；
* 聊天时每 15 分钟补一条 `meta seen:<ISO>`（`absence.js` 判「他多久没来」、`away.js` 算
  「你不在的时候」都靠它）：原先只有她 `growth_commit` 时才写，于是天天在微信聊，她还以为你很久没来。

状态是 UI 每 30 秒轮询一次算的，所以聊完最多半分钟就显示醒着，不需要重启（补丁本身要重启加载）。

## 插件升级后怎么办（防升级损坏）

这套东西踩在 6 个第三方插件上，其中 4 个被我们打了本地补丁（桥接共用会话、SD 两处、刷B站闲置回收、orb 软兜底）。
插件一升级，`node_modules` 里的文件会被覆盖——补丁就没了，症状往往不是报错，而是"她突然不说话/失忆/一开机一堆 python"。

所以每次升级（或每周一次）跑：

```bash
node tools/doctor.mjs        # 9 项不变量体检，退出码非 0 就是有坏的
node tools/doctor.mjs --fix  # 能自动修的修掉：重打补丁、把她的配置改回来
```

体检项：四处补丁在不在 → 她的 `config.json` 关键键（preset/allow/rotateAfter/刷站开关）→
`home.json` 与会话头的 cwd/preset 是否一致 → 桥接 `sessionIdFor()` 是否真返回她那条会话 →
组合层能否重新拼出来（`fish-home` / persona / fish-memory / 桥接绑定）→ 账本与记忆库能否解析 →
SD 与后台 python 的现状（只提示）。

防止被静默升级的另外两道：

* `package.json` 里被补丁的包**钉死版本**（`dsh-bili-scroll 2.2.0`、`dshmarket 1.70.2`、`dsh-orb 0.1.9`），
  `dsh-fish` / `dsh-sd-bridge-mac` / `dsh-fish-memory` 这类走 `link:`，改的是工作区源码，不会被覆盖；
* `tools/patch-*.mjs` 全部按**内容锚点**匹配、幂等、带 `--check` / `--revert`：插件大版本改了那段代码，
  补丁会明确报"锚点变了，需要重写"，而不是静默失效。

## 相关记忆的另一个层

忆时（`dsh-yishi-whale`）仍然挂在预设里，它管的是「她主动检索的语义记忆库」（Python + BGE 向量）。
两者不冲突：忆时是深检索，这个记忆库是每轮都在眼前的浅印象。想只留一个：
把 `wechat-media-turbo` 预设里的 `yishi` 行删掉，或把 `memory-lite` 的 `extraction.mode` 设成 `off`
（默认 `incremental`，会额外跑 LLM 抽取）。

/**
 * 记忆库的行为测试：衰减、去重、折叠、遗忘、跨通道互通、插件装配。
 *
 * 用 node:test，不引第三方依赖——这个插件装在最要紧的聊天链路上，
 * 它的测试不该需要另装一套工具链。
 */

import { mkdtempSync, readFileSync, rmSync, existsSync, mkdirSync, readdirSync, statSync, writeFileSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import test from 'node:test'
import assert from 'node:assert/strict'

import {
  DAY_MS,
  effectiveWeight,
  tierOf,
  tokensOf,
  overlapOf,
  dayLabel,
} from '../lib/decay.js'
import { createFishMirror } from '../lib/fishevents.js'
import { pickOrphanHosts } from '../lib/hostguard.js'
import { MemoryStore } from '../lib/store.js'
import { createChannelResolver } from '../lib/channels.js'
import { createBiliSource, parseDigest, parseComments } from '../lib/bili.js'
import { extractFromUser, extractFromAssistant, episodeOf, gistOf, stripEnvelope } from '../lib/extract.js'
import { apply, DEFAULT_CONFIG, resolveConfig, channelOf, textOfEvent, normalizeDir } from '../lib/index.js'

const HOUR = 3_600_000

function tmpStore(options = {}) {
  const dir = mkdtempSync(join(tmpdir(), 'fish-mem-'))
  const store = new MemoryStore(dir, options)
  return { dir, store, cleanup: () => rmSync(dir, { recursive: true, force: true }) }
}

test('衰减：过一个半衰期掉一半，被想起后重新计时', () => {
  const at = Date.UTC(2026, 0, 1)
  const row = { kind: 'event', w: 1, at }
  assert.equal(effectiveWeight(row, at), 1)
  assert.ok(Math.abs(effectiveWeight(row, at + 10 * DAY_MS) - 0.5) < 1e-9)
  assert.ok(Math.abs(effectiveWeight(row, at + 20 * DAY_MS) - 0.25) < 1e-9)
  const hit = { ...row, lastHit: at + 20 * DAY_MS }
  assert.ok(Math.abs(effectiveWeight(hit, at + 20 * DAY_MS) - 1) < 1e-9)
})

test('衰减：偏好活得比流水久', () => {
  const at = Date.UTC(2026, 0, 1)
  const now = at + 20 * DAY_MS
  const pref = effectiveWeight({ kind: 'pref', w: 1, at }, now)
  const episode = effectiveWeight({ kind: 'episode', w: 1, at }, now)
  assert.ok(pref > episode)
})

test('形态：重量决定是原话、印象还是不再想起', () => {
  assert.equal(tierOf(0.9), 'detail')
  assert.equal(tierOf(0.2), 'gist')
  assert.equal(tierOf(0.01), 'gone')
})

test('分词：中文切二字，英文按词', () => {
  const tokens = tokensOf('我喜欢喝冰美式 espresso')
  assert.ok(tokens.includes('冰美'))
  assert.ok(tokens.includes('espresso'))
  assert.ok(overlapOf(tokensOf('冰美式'), tokens) > 0)
  assert.equal(overlapOf(tokensOf('完全不相关'), tokens), 0)
})

test('日期标签：今天 / 昨天 / N天前 / 更早给日期', () => {
  const now = Date.UTC(2026, 8, 20)
  assert.equal(dayLabel(now, now), '今天')
  assert.equal(dayLabel(now - DAY_MS, now), '昨天')
  assert.equal(dayLabel(now - 3 * DAY_MS, now), '3天前')
  assert.match(dayLabel(now - 60 * DAY_MS, now), /月/)
})

test('写入即可读：换一个进程也能读到同一份库', () => {
  const { dir, store, cleanup } = tmpStore()
  try {
    const result = store.remember({ text: '主人喜欢喝冰美式，不加糖', gist: '喜欢冰美式', kind: 'pref', w: 1.2, ch: 'qq' })
    assert.equal(result.added, true)
    const reopened = new MemoryStore(dir)
    const hits = reopened.recall('冰美式')
    assert.equal(hits.length, 1)
    assert.match(hits[0].text, /冰美式/)
    assert.equal(hits[0].row.ch, 'qq')
  } finally {
    cleanup()
  }
})

test('去重：同一句话再次说出口是加固，不是两条', () => {
  const { store, cleanup } = tmpStore()
  try {
    const now = Date.now()
    store.remember({ text: '主人住在杭州西湖区', gist: '住杭州', kind: 'fact', w: 1 })
    const again = store.remember({ text: '主人住在杭州西湖区', gist: '住杭州', kind: 'fact', w: 1 })
    assert.equal(again.added, false)
    assert.equal(store.activeRows().length, 1)
    assert.ok(store.activeRows()[0].w > 1)
    assert.ok(effectiveWeight(store.activeRows()[0], now) > 0.9)
  } finally {
    cleanup()
  }
})

test('折叠：老流水压成印象，细节读不到但轮廓还在', () => {
  const { store, cleanup } = tmpStore()
  try {
    const at = Date.now() - 30 * DAY_MS
    for (let i = 0; i < 5; i += 1) {
      store.append({
        t: 'm',
        id: `old-${i}`,
        at: at + i * HOUR,
        kind: 'episode',
        text: `第 ${i} 段流水：聊了猫粮和天气`,
        gist: `聊猫粮 ${i}`,
        w: 0.5,
        ch: 'wechat',
      })
    }
    store.loaded = false
    const folded = store.maybeCompact(Date.now())
    assert.ok(folded >= 5, `应折叠至少 5 条，实际 ${folded}`)
    const impressions = store.activeRows().filter((row) => row.kind === 'impression')
    assert.equal(impressions.length, 1)
    assert.match(impressions[0].gist, /聊了 5 段/)
    // 子记录不再出现在检索里（被折叠了）
    assert.equal(store.recall('猫粮').filter((hit) => hit.row.kind === 'episode').length, 0)
  } finally {
    cleanup()
  }
})

test('遗忘：标记之后检索不到，文件里仍留着历史', () => {
  const { store, dir, cleanup } = tmpStore()
  try {
    store.remember({ text: '主人讨厌香菜', gist: '讨厌香菜', kind: 'pref', w: 1 })
    const hits = store.recall('香菜')
    assert.equal(hits.length, 1)
    const n = store.markForgotten([hits[0].row.id])
    assert.equal(n, 1)
    assert.equal(store.recall('香菜').length, 0)
    const lines = readFileSync(join(dir, 'memories.jsonl'), 'utf8').trim().split('\n')
    assert.equal(lines.length, 2, '一行记忆 + 一行遗忘记录，历史不被改写')
  } finally {
    cleanup()
  }
})

test('索引：按重量取，忘了细节的只给印象，且不超过预算', () => {
  const { store, cleanup } = tmpStore({ maxDetail: 120 })
  try {
    const now = Date.now()
    store.append({ t: 'm', id: 'a', at: now - 30 * DAY_MS, kind: 'fact', text: '这条很老了，细节应该消失，只留一句印象。'.repeat(3), gist: '很老的印象', w: 0.5 })
    store.remember({ text: '主人喜欢冰美式', gist: '喜欢冰美式', kind: 'pref', w: 1.2 })
    store.loaded = false
    const lines = store.indexLines({ budget: 200, now })
    assert.ok(lines.length >= 2)
    assert.ok(lines.join('').length <= 200)
    assert.ok(lines.some((line) => line.includes('很老的印象')))
    // 老事实的细节（长句）不该出现
    assert.ok(!lines.join('').includes('这条很老了'))
  } finally {
    cleanup()
  }
})

test('跨通道：QQ 写的，微信会话能立刻想起来', () => {
  const { dir, cleanup } = tmpStore()
  try {
    // 两个会话 = 两个 store 实例，但同一个工作区目录 —— 这就是「实时互通」
    const qq = new MemoryStore(dir, { now: () => Date.now() })
    const wechat = new MemoryStore(dir, { now: () => Date.now() })
    qq.remember({ text: '主人明天要去医院复查甲状腺', gist: '明天复查甲状腺', kind: 'event', w: 1, ch: 'qq', sid: 'qq-1' })
    const hits = wechat.recall('甲状腺 复查')
    assert.equal(hits.length, 1)
    assert.match(hits[0].text, /复查/)
    assert.equal(hits[0].row.ch, 'qq')
    // 索引里也能看见（下一轮 system prompt 就会带上）
    assert.ok(wechat.indexLines({ budget: 500 }).join('').includes('复查'))
  } finally {
    cleanup()
  }
})

test('抽取：偏好与承诺被抓到，系统和噪音不被抓', () => {
  const prefs = extractFromUser('记住：我以后不喝加糖的咖啡了')
  assert.equal(prefs.length, 1)
  assert.equal(prefs[0].kind, 'pref')
  assert.ok(prefs[0].w >= 1.2)

  assert.equal(extractFromUser('runtime context: skills ...').length, 0)
  assert.equal(extractFromUser('嗯').length, 0)
  assert.equal(extractFromUser('[tool-result abc] 输出一堆东西').length, 0)

  const code = extractFromUser('```js\nconst a = 1\n```')
  assert.equal(code.length, 0)

  const commitment = extractFromAssistant('说好了，我以后每天提醒你喝水。')
  assert.equal(commitment.length, 1)
  assert.equal(extractFromAssistant('哈哈哈哈哈').length, 0)

  const episode = episodeOf('今天在西湖边走了两万步，累死了')
  assert.ok(episode !== null)
  assert.equal(episode.kind, 'episode')
  assert.equal(gistOf('其实我挺喜欢这个的呀'), '我挺喜欢这个的')
})

/* ------------------------------------------------------------------ */
/* 插件装配：用假 ctx 走一遍真实路径                                    */
/* ------------------------------------------------------------------ */

function scopedCtx(sink) {
  const scoped = {
    systemPrompt: { section: (section) => sink.sections.push(section) },
    tools: { register: (tool) => sink.tools.push(tool) },
  }
  return {
    ...scoped,
    inject: (_names, callback) => callback(scoped),
  }
}

function fakeCtx(initialAgents = []) {
  const sink = { sections: [], tools: [] }
  const listeners = new Map()
  const agents = [...initialAgents]
  const ctx = {
    sink,
    listeners,
    agents: { list: () => agents },
    logger: { info() {}, warn() {} },
    on: (event, handler) => {
      const list = listeners.get(event) ?? []
      list.push(handler)
      listeners.set(event, list)
    },
    emit(event, ...args) {
      for (const handler of listeners.get(event) ?? []) handler(...args)
    },
    addAgent(agent) {
      agents.push(agent)
      ctx.emit('agent/created', { agent })
      return agent
    },
  }
  return ctx
}

function fakeAgent(header, sink = { sections: [], tools: [] }) {
  const scoped = scopedCtx(sink)
  return { id: header.id, session: { header }, ctx: scoped }
}

function userEvent(text, kind = 'user') {
  return { type: 'user/message', data: { source: { kind }, message: { content: [{ type: 'text', text }] } } }
}

function assistantEvent(text) {
  return { type: 'assistant/message', data: { message: { content: [{ type: 'text', text }] } } }
}

test('装配：索引段落 + memory 工具 + 事件写入，一条龙', async () => {
  const workspace = mkdtempSync(join(tmpdir(), 'fish-ws-'))
  try {
    const ctx = fakeCtx()
    apply(ctx, { workspace, mirrorChats: false })
    const sink = { sections: [], tools: [] }
    const qqSession = { header: { id: 'qq-abc', cwd: workspace, origin: 'session' } }
    const wechatSession = { header: { id: 'wechat-xyz', cwd: workspace, origin: 'session' } }
    const wechatAgent = fakeAgent(wechatSession.header, sink)
    ctx.addAgent(wechatAgent)

    assert.equal(sink.sections.length, 1)
    assert.equal(sink.tools.length, 1)
    assert.equal(sink.tools[0].name, 'memory')

    ctx.emit('session/event', qqSession, userEvent('我跟你说，我以后都喝不加糖的美式，记住啊'))
    ctx.emit('session/event', qqSession, userEvent('runtime context: 这是注入的，不该记', 'system'))
    ctx.emit('session/event', qqSession, assistantEvent('说好了，我以后每天帮你盯着咖啡因摄入。'))

    // 微信这边的索引段落（下一轮才会组装）应当已经能看到 QQ 写进来的记忆
    const text = sink.sections[0].text()
    assert.match(text, /记忆库/)
    assert.match(text, /美式/)

    const tool = sink.tools[0]
    const recall = await tool.execute({ action: 'recall', query: '美式 糖' })
    assert.equal(recall.ok, true)
    assert.ok(recall.items.length >= 1)
    assert.equal(recall.items[0].channel, 'qq')

    const stats = await tool.execute({ action: 'stats' })
    assert.equal(stats.ok, true)
    assert.match(stats.summary, /记忆库/)

    const remembered = await tool.execute({ action: 'remember', text: '主人的猫叫豆豆', kind: 'fact' })
    assert.equal(remembered.ok, true)

    const forgotten = await tool.execute({ action: 'forget', query: '豆豆' })
    assert.match(forgotten.summary, /忘了 1 条/)
    assert.equal(existsSync(join(workspace, '.memory', 'memories.jsonl')), true)
  } finally {
    rmSync(workspace, { recursive: true, force: true })
  }
})

test('桥接信封：微信/QQ 包裹的那一层前缀不能把消息当噪音丢掉', () => {
  const wx = '[微信 o9cq809IZeK3K5RUFq-5jM-OjzaE@im.wechat o9cq809IZeK3K5RUFq-5jM-OjzaE@im.wechat]\n我是你的主人'
  assert.equal(stripEnvelope(wx), '我是你的主人')
  const rows = extractFromUser(wx)
  assert.equal(rows.length, 1)
  assert.equal(rows[0].text, '我是你的主人', '存的原话不该带信封')
  assert.equal(rows[0].kind, 'fact')

  const qq = '[QQ 123456789]\n我以后都喝不加糖的美式，记住'
  assert.equal(extractFromUser(qq)[0].kind, 'pref')

  const group = '[群聊 深海鱼缸]\n今天去西湖走了两万步'
  assert.equal(episodeOf(group).text, '今天去西湖走了两万步')

  // 系统注入仍然必须挡住
  assert.equal(extractFromUser('[tool-result abc] 一堆输出').length, 0)
  assert.equal(extractFromUser('runtime context: 无关内容').length, 0)
  // 普通方括号不是信封，不能乱剥
  assert.equal(stripEnvelope('[重要] 明天开会'), '[重要] 明天开会')
})

test('刷B站同步：账本行解析（标题里带 · 也不串列）', () => {
  const digest = [
    '# 2026-10',
    '',
    '2026-10-26 · BV1ugHG66EZi · 机哥真旗舰！耀世 16 Ultra 2026升级版 全面评测 · 野生的装机宅 · 跳过：字幕/详情工具未登录，读不到内容 · https://www.bilibili.com/video/BV1ugHG66EZi',
    '2026-10-26 · BV1XLnd6wEfu · 一个 · 带分隔符 · 的标题 · 阿Bon识少少 · 挑了（值得看）：部署步骤完整 · https://b23.tv/x',
  ].join('\n')
  const rows = parseDigest(digest)
  assert.equal(rows.length, 2)
  assert.equal(rows[0].gist, '跳过《机哥真旗舰！耀世 16 Ultra 2026升级版 全面评测》')
  assert.equal(rows[0].w, 0.35)
  assert.match(rows[0].text, /读不到内容/)
  assert.equal(rows[1].w, 0.85)
  assert.match(rows[1].text, /看了《一个 · 带分隔符 · 的标题》/)
  assert.equal(rows[1].at, Date.parse('2026-10-26T12:00:00+08:00'), '时间必须是真实发生时间')
})

test('刷B站同步：账本里夹的「评论记录」不能被当成视频', () => {
  const digest = [
    '2026-10-26 · BV1XLnd6wEfu · 评论记录 · rpid=318248449073 · 时间 2026-10-26 18:47 · 正文前 20 字：docker compose · https://b23.tv/x',
    '2026-10-26 · BV1ugHG66EZi · 真视频标题 · 某UP · 挑了（值得看）：有用 · https://b23.tv/y',
  ].join('\n')
  const rows = parseDigest(digest)
  assert.equal(rows.length, 1, '评论记录要被跳过')
  assert.equal(rows[0].gist, '看了《真视频标题》')
})

test('刷B站同步：评论行解析成「读到」（别人的话，不是她的偏好）', () => {
  const text = '- 2026-10-26 18:47 BV1XLnd6wEfu rpid=318248449073 · docker compose 那段跟着抄一遍就能跑，最实用的是探测页。\n- 坏行没有 rpid'
  const rows = parseComments(text)
  assert.equal(rows.length, 1)
  assert.equal(rows[0].kind, 'heard')
  assert.equal(rows[0].w, 0.8)
  assert.match(rows[0].text, /^\[B站评论\]/)
  assert.equal(rows[0].at, Date.parse('2026-10-26T18:47:00+08:00'))
})

test('刷B站同步：幂等（重复同步不重复记，新行才进）', () => {
  const biliDir = mkdtempSync(join(tmpdir(), 'fish-bili-'))
  const { store, cleanup } = tmpStore()
  try {
    mkdirSync(join(biliDir, 'digest'), { recursive: true })
    const digestFile = join(biliDir, 'digest', '2026-10.md')
    const line = '2026-10-26 · BV1ugHG66EZi · 测试视频 · 某UP · 挑了（值得看）：有用 · https://b23.tv/a'
    writeFileSync(digestFile, `${line}\n`, 'utf8')
    const source = createBiliSource({ dir: biliDir })

    const first = source.sync(store)
    assert.equal(first.added, 1)
    const second = source.sync(store)
    assert.equal(second.added, 0, '第二次不该再写')
    assert.equal(store.activeRows().filter((row) => row.ch === 'bili').length, 1)

    writeFileSync(digestFile, `${line}\n2026-10-27 · BV1y2na6XEGf · 第二个 · 某人 · 跳过：无关 · https://b23.tv/b\n`, 'utf8')
    const third = source.sync(store)
    assert.equal(third.added, 1, '新行才进')

    // 换一个进程（新 store + 新 source）：游标在磁盘上，依旧幂等
    const reopened = new MemoryStore(store.dir)
    const fourth = createBiliSource({ dir: biliDir }).sync(reopened)
    assert.equal(fourth.added, 0)
    assert.equal(reopened.recall('测试视频').length, 1)
    assert.equal(reopened.recall('测试视频')[0].row.ch, 'bili')
  } finally {
    cleanup()
    rmSync(biliDir, { recursive: true, force: true })
  }
})

test('刷B站同步：接进插件后，索引里能看到她刷过什么', async () => {
  const workspace = mkdtempSync(join(tmpdir(), 'fish-ws-'))
  const biliDir = mkdtempSync(join(tmpdir(), 'fish-bili-'))
  try {
    mkdirSync(join(biliDir, 'digest'), { recursive: true })
    writeFileSync(
      join(biliDir, 'digest', '2026-10.md'),
      '2026-10-28 · BV1ZQxV6NEfS · 我的世界烈焰棒 · 某UP · 挑了（值得看）：讲得清楚 · https://b23.tv/z\n',
      'utf8',
    )
    const ctx = fakeCtx()
    apply(ctx, { workspace, bili: { dir: biliDir }, mirrorChats: false })
    const sink = { sections: [], tools: [] }
    ctx.addAgent(fakeAgent({ id: 'session-1', cwd: workspace, origin: 'session' }, sink))
    const text = sink.sections[0].text()
    assert.match(text, /B站|烈焰棒/)
    const recall = await sink.tools[0].execute({ action: 'recall', query: '烈焰棒' })
    assert.equal(recall.items[0].channel, 'bili')
  } finally {
    rmSync(workspace, { recursive: true, force: true })
    rmSync(biliDir, { recursive: true, force: true })
  }
})

test('装配：只对配上的工作区装工具，别的会话一个 token 都不多付', () => {
  const fishHome = mkdtempSync(join(tmpdir(), 'fish-home-'))
  const elsewhere = mkdtempSync(join(tmpdir(), 'other-ws-'))
  try {
    const ctx = fakeCtx()
    apply(ctx, { workspace: fishHome, mirrorChats: false })
    const otherSink = { sections: [], tools: [] }
    ctx.addAgent(fakeAgent({ id: 'session-1', cwd: elsewhere, origin: 'session' }, otherSink))
    assert.equal(otherSink.sections.length, 0)
    assert.equal(otherSink.tools.length, 0)

    const fishSink = { sections: [], tools: [] }
    ctx.addAgent(fakeAgent({ id: 'session-2', cwd: `${fishHome}/`, origin: 'session' }, fishSink))
    assert.equal(fishSink.sections.length, 1)
    assert.equal(fishSink.tools.length, 1)
  } finally {
    rmSync(fishHome, { recursive: true, force: true })
    rmSync(elsewhere, { recursive: true, force: true })
  }
})

test('共享库：老会话还在旧工作区，也能和新会话互通（不用每个聊天 /new）', async () => {
  const home = mkdtempSync(join(tmpdir(), 'fish-home-'))
  const legacy = mkdtempSync(join(tmpdir(), 'fish-legacy-'))
  try {
    const ctx = fakeCtx()
    apply(ctx, { workspace: [home, legacy], mirrorChats: false })

    // 旧工作区里的 QQ 老会话
    const qqSink = { sections: [], tools: [] }
    ctx.addAgent(fakeAgent({ id: 'wechat-qqc', cwd: legacy, origin: 'session' }, qqSink))
    assert.equal(qqSink.tools.length, 1, '旧工作区也要装工具')

    // 家里的微信会话（新）
    const wxSink = { sections: [], tools: [] }
    ctx.addAgent(fakeAgent({ id: 'wechat-wxc', cwd: home, origin: 'session' }, wxSink))

    ctx.emit('session/event', { header: { id: 'wechat-qqc', cwd: legacy, origin: 'session' } }, userEvent('[QQ 123456]\n我以后都喝不加糖的美式，记住'))

    const recall = await wxSink.tools[0].execute({ action: 'recall', query: '美式' })
    assert.ok(recall.items.length >= 1, '微信这边应能翻到 QQ 写的记忆')
    assert.match(wxSink.sections[0].text(), /美式/)

    // 库只有一个：家里的 .memory；旧工作区不该被写出第二个库
    assert.equal(existsSync(join(home, '.memory', 'memories.jsonl')), true)
    assert.equal(existsSync(join(legacy, '.memory')), false)
  } finally {
    rmSync(home, { recursive: true, force: true })
    rmSync(legacy, { recursive: true, force: true })
  }
})

test('共享库：workspace 可以是数组，配置归一不丢项', () => {
  const cfg = resolveConfig({ workspace: [' /a ', '/b', ''] })
  assert.deepEqual(cfg.workspace, ['/a', '/b'])
  assert.equal(resolveConfig({ workspace: '/only' }).workspace, '/only')
  assert.equal(resolveConfig({ workspace: [] }).workspace, '~/.dsh-fish/home')
})

test('装配：热重载时补装已存在的 agent；子会话不写库', () => {
  const workspace = mkdtempSync(join(tmpdir(), 'fish-ws-'))
  try {
    const sink = { sections: [], tools: [] }
    const existing = fakeAgent({ id: 'session-9', cwd: workspace, origin: 'session' }, sink)
    const ctx = fakeCtx([existing])
    apply(ctx, { workspace, mirrorChats: false })
    assert.equal(sink.tools.length, 1, '晚挂载也要补装已有 agent')

    ctx.emit('session/event', { header: { id: 'sub-1', cwd: workspace, origin: 'subagent' } }, userEvent('我喜欢乱写'))
    assert.equal(existsSync(join(workspace, '.memory', 'memories.jsonl')), false)
  } finally {
    rmSync(workspace, { recursive: true, force: true })
  }
})

test('装配：agent 先建、cwd 后到，也要补装（不轮询，只等第一条事件）', () => {
  const workspace = mkdtempSync(join(tmpdir(), 'fish-ws-'))
  try {
    const sink = { sections: [], tools: [] }
    const header = { id: 'session-77', origin: 'session' }
    const agent = fakeAgent(header, sink)
    const ctx = fakeCtx([agent])
    apply(ctx, { workspace, mirrorChats: false })
    assert.equal(sink.tools.length, 0, 'cwd 还没定，先别装')

    header.cwd = workspace
    ctx.emit('session/event', agent.session, userEvent('今天去西湖走了两万步'))
    assert.equal(sink.tools.length, 1, 'cwd 落定后补装')
    assert.equal(sink.sections.length, 1)
  } finally {
    rmSync(workspace, { recursive: true, force: true })
  }
})

test('通道：从桥接 routes.json 反查 QQ / 微信，查不到退回前缀', () => {
  const dir = mkdtempSync(join(tmpdir(), 'fish-routes-'))
  try {
    const routesPath = join(dir, 'routes.json')
    mkdirSync(dir, { recursive: true })
    writeFileSync(routesPath, JSON.stringify({
      'qq-1906039620': { 'openid-1': { sessionId: 'wechat-hashqq' } },
      '52f32fa9f125-im-bot': { 'wxid-1': { sessionId: 'wechat-hashwx' } },
    }), 'utf8')
    const resolve = createChannelResolver({ routesPath })
    assert.equal(resolve('wechat-hashqq'), 'qq')
    assert.equal(resolve('wechat-hashwx'), 'wechat')
    assert.equal(resolve('wechat-unknown'), 'chat', '查不到就退回前缀，绝不谎报成 QQ')
    assert.equal(resolve('session-1'), 'local')
  } finally {
    rmSync(dir, { recursive: true, force: true })
  }
})

test('工具 schema 必须是合法 JSON Schema（`required` 只能是数组，不能是 true）', () => {
  const workspace = mkdtempSync(join(tmpdir(), 'fish-schema-'))
  try {
    const ctx = fakeCtx()
    apply(ctx, { workspace, mirrorChats: false })
    const sink = { sections: [], tools: [] }
    ctx.addAgent(fakeAgent({ id: 'session-1', cwd: workspace, origin: 'session' }, sink))
    const tool = sink.tools[0]
    assert.ok(tool !== undefined, '工具要在装配时注册')
  const params = tool.parameters
  assert.equal(params.type, 'object')
  assert.ok(Array.isArray(params.required), '顶层 required 必须是数组')
  for (const [name, property] of Object.entries(params.properties)) {
    assert.notEqual(typeof property.required, 'boolean', `${name}.required 不能是布尔（DeepSeek 会拒这个 schema）`)
  }
  for (const name of params.required) assert.ok(name in params.properties, `required 里的 ${name} 必须在 properties 里`)
  } finally {
    rmSync(workspace, { recursive: true, force: true })
  }
})

test('镜像：主人说的话写成 voice 事件，两边的话进 chat-log（只认「她的家」这个工作区）', async () => {
  const root = mkdtempSync(join(tmpdir(), 'fish-ledger-'))
  try {
    writeFileSync(join(root, 'events.jsonl'), `${JSON.stringify({ id: 'ev_seed', ts: new Date().toISOString(), type: 'seed', day: 1, stage: 1, text: 'seed', source: 'system', refs: [], verdict: null, confidence: 0.5, flags: [] })}\n`, 'utf8')
    const home = join(root, 'home')
    mkdirSync(home, { recursive: true })

    const ctx = fakeCtx()
    apply(ctx, { workspace: home, mirrorChats: { root } })
    const sink = { sections: [], tools: [] }
    const agent = fakeAgent({ id: 'wechat-z', cwd: home, origin: 'session' }, sink)
    ctx.addAgent(agent)

    ctx.emit('session/event', agent.session, userEvent('[微信 o9x]\n今天 b 站刷到怎么样'))
    ctx.emit('session/event', agent.session, assistantEvent('在。刚把屋子翻了一遍，空得很。'))
    // 镜像是异步的（要动态 import 大肥鱼的 store）
    for (let i = 0; i < 40; i += 1) {
      if (existsSync(join(root, 'chat-log'))) break
      await new Promise((resolve) => setTimeout(resolve, 50))
    }
    await new Promise((resolve) => setTimeout(resolve, 300))

    const events = readFileSync(join(root, 'events.jsonl'), 'utf8').trim().split('\n').map((line) => JSON.parse(line))
    const voice = events.filter((event) => event.type === 'voice')
    assert.equal(voice.length, 1, '主人说的话要变成一条 voice 事件')
    assert.match(voice[0].text, /\[微信\] 他：今天 b 站刷到怎么样/)
    assert.equal(voice[0].source, 'system')

    const logDay = readdirSync(join(root, 'chat-log'))[0]
    const log = readFileSync(join(root, 'chat-log', logDay), 'utf8')
    assert.match(log, /\[微信\] 他：今天 b 站刷到怎么样/)
    assert.match(log, /\[微信\] 她：在。刚把屋子翻了一遍/)
  } finally {
    rmSync(root, { recursive: true, force: true })
  }
})

test('镜像：不是她家的工作区不写账本（旧桥接目录 / 测试目录）', () => {
  const root = mkdtempSync(join(tmpdir(), 'fish-ledger2-'))
  const other = mkdtempSync(join(tmpdir(), 'fish-other-'))
  try {
    writeFileSync(join(root, 'events.jsonl'), '', 'utf8')
    const ctx = fakeCtx()
    apply(ctx, { workspace: [other], mirrorChats: { root } })
    const sink = { sections: [], tools: [] }
    const agent = fakeAgent({ id: 'session-1', cwd: other, origin: 'session' }, sink)
    ctx.addAgent(agent)
    ctx.emit('session/event', agent.session, userEvent('[微信 x]\n不该记'))
    assert.equal(existsSync(join(root, 'chat-log')), false)
  } finally {
    rmSync(root, { recursive: true, force: true })
    rmSync(other, { recursive: true, force: true })
  }
})

test('镜像：day 跟 fish 的 growthDay 对齐（从 seed 起算），seen 有节流', async () => {
  const root = mkdtempSync(join(tmpdir(), 'fish-ledger3-'))
  try {
    const seedTs = new Date(Date.now() - 30 * 3600_000).toISOString() // 30 小时前
    const seed = { id: 'ev_seed', v: 1, ts: seedTs, day: 1, stage: 1, type: 'seed', source: 'system', text: 'seed', refs: [], flags: [], verdict: null, confidence: 0.5 }
    writeFileSync(join(root, 'events.jsonl'), `${JSON.stringify(seed)}\n`, 'utf8')
    mkdirSync(join(root, 'home'), { recursive: true })

    const mirror = createFishMirror({ root, seenEveryMs: 60_000 })
    const now = Date.now()
    await mirror.mirrorUser({ text: '第一句', channel: 'wechat', at: now, sid: 's-day' })
    await mirror.mirrorUser({ text: '第二句', channel: 'wechat', at: now + 1000, sid: 's-day' })

    const rows = readFileSync(join(root, 'events.jsonl'), 'utf8').trim().split('\n').map((line) => JSON.parse(line))
    const voices = rows.filter((row) => row.type === 'voice')
    assert.equal(voices.length, 2)
    // 30 小时前起算 → 现在是第 2 天（与 derive.growthDay 的 24 小时块一致）
    assert.equal(voices[0].day, 2, 'day 应该从 seed 起算 24 小时块')
    const seen = rows.filter((row) => row.type === 'meta' && String(row.text).startsWith('seen:'))
    assert.equal(seen.length, 1, 'seen 一分钟内只写一条')
  } finally {
    rmSync(root, { recursive: true, force: true })
  }
})

test('镜像：每天最多刷一次她的身份文本（聊天不写 growth_commit）', async () => {
  const root = mkdtempSync(join(tmpdir(), 'fish-ledger4-'))
  try {
    writeFileSync(join(root, 'events.jsonl'), `${JSON.stringify({ id: 'ev_seed', v: 1, ts: new Date(Date.now() - 3600_000).toISOString(), day: 1, stage: 1, type: 'seed', source: 'system', text: 'seed', refs: [], flags: [], verdict: null, confidence: 0.5 })}\n`, 'utf8')
    mkdirSync(join(root, 'home'), { recursive: true })
    const mirror = createFishMirror({ root })
    await mirror.mirrorUser({ text: '早', channel: 'wechat', at: Date.now(), sid: 's-doc' })
    const doc = join(root, 'home', '她的身份.md')
    const ok = existsSync(doc)
    assert.equal(ok, true, '当天第一次聊天后应生成/刷新身份文本')
    const first = readFileSync(doc, 'utf8')
    const mtime = statSync(doc).mtimeMs
    await new Promise((resolve) => setTimeout(resolve, 50))
    await mirror.mirrorUser({ text: '再一句', channel: 'wechat', at: Date.now() + 1000, sid: 's-doc' })
    assert.equal(statSync(doc).mtimeMs, mtime, '同一天不再重复刷')
    assert.ok(first.length > 0)
  } finally {
    rmSync(root, { recursive: true, force: true })
  }
})

test('配置归一：DEFAULT_CONFIG 的每个键都能被 resolveConfig 带出来（防静默丢字段）', () => {
  const resolved = resolveConfig({})
  const missing = Object.keys(DEFAULT_CONFIG).filter((key) => !(key in resolved))
  assert.deepEqual(missing, [], `这些默认字段没被 resolveConfig 带出来：${missing.join(', ')}`)
  // 索引里「读到」的配额必须是个有限数，NaN 会让配额静默失效（2026-10-29 踩过）
  assert.equal(Number.isFinite(resolved.indexCommentLimit), true)
})

test('配置归一：坏值回落，布尔默认开', () => {
  const cfg = resolveConfig({ indexBudget: 'oops', indexLimit: -5, enabled: false })
  assert.equal(cfg.indexBudget, 700)
  assert.equal(cfg.indexLimit, 1)
  assert.equal(cfg.enabled, false)
  assert.equal(resolveConfig(undefined).ingest, true)
  assert.equal(resolveConfig({ workspace: '  ' }).workspace, '~/.dsh-fish/home')
})

test('通道识别与事件取文', () => {
  assert.equal(channelOf({ id: 'wechat-abc' }), 'wechat')
  assert.equal(channelOf({ id: 'qq-abc' }), 'qq')
  assert.equal(channelOf({ id: 'session-1' }), 'local')
  assert.equal(textOfEvent(userEvent('你好')), '你好')
  assert.equal(textOfEvent({ type: 'assistant/message', data: { message: { content: [{ type: 'tool-call', name: 'bash' }] } } }), '')
  assert.equal(normalizeDir('~/.dsh-fish/home/'), `${process.env.HOME}/.dsh-fish/home`)
})

test('镜像：长内容（整首歌）在 chat-log 里保留全文，voice 事件按 1800 字封顶', async () => {
  const root = mkdtempSync(join(tmpdir(), 'fish-long-'))
  try {
    writeFileSync(join(root, 'events.jsonl'), `${JSON.stringify({ id: 'ev_seed', v: 1, ts: new Date().toISOString(), day: 1, stage: 1, type: 'seed', source: 'system', text: 'seed', refs: [], flags: [], verdict: null, confidence: 0.5 })}\n`, 'utf8')
    mkdirSync(join(root, 'home'), { recursive: true })
    const mirror = createFishMirror({ root })
    const song = `昨日一去不复回～${'副歌🎤'.repeat(300)}` // 共 900+ 字
    await mirror.mirrorUser({ text: song, channel: 'qq', at: Date.now(), sid: 's-long' })
    const logDir = join(root, 'chat-log')
    const log = readdirSync(logDir).map((name) => readFileSync(join(logDir, name), 'utf8')).join('\n')
    assert.ok(log.includes(song), 'chat-log 必须保留整首歌的全文')
    const voice = readFileSync(join(root, 'events.jsonl'), 'utf8').trim().split('\n').map((l) => JSON.parse(l)).filter((r) => r.type === 'voice').pop()
    assert.ok(voice.text.length <= 2000, 'voice 事件不能超过 schema 的 2000 字')
    assert.ok(voice.text.startsWith('[QQ] 他：'), 'voice 事件保留通道前缀')
  } finally {
    rmSync(root, { recursive: true, force: true })
  }
})

test('镜像：chat_search 能按关键词翻到聊天原文（含长内容）', async () => {
  const root = mkdtempSync(join(tmpdir(), 'fish-search-'))
  try {
    writeFileSync(join(root, 'events.jsonl'), `${JSON.stringify({ id: 'ev_seed', v: 1, ts: new Date().toISOString(), day: 1, stage: 1, type: 'seed', source: 'system', text: 'seed', refs: [], flags: [], verdict: null, confidence: 0.5 })}\n`, 'utf8')
    mkdirSync(join(root, 'home'), { recursive: true })
    const mirror = createFishMirror({ root })
    await mirror.mirrorUser({ text: '以后叫你唱歌，你就发这个', channel: 'qq', at: Date.now(), sid: 's1' })
    await mirror.mirrorUser({ text: '昨日一去不复回～开心比什么都贵', channel: 'qq', at: Date.now(), sid: 's1' })
    const hit = mirror.searchChats({ query: '昨日一去不复回', days: 30 })
    assert.equal(hit.ok, true)
    assert.equal(hit.hits.length, 1, '应该只命中那一条')
    assert.match(hit.hits[0].line, /昨日一去不复回/)
    assert.equal(mirror.searchChats({ query: '完全不存在的词' }).hits.length, 0)
  } finally {
    rmSync(root, { recursive: true, force: true })
  }
})

test('记忆抽取：长消息的 episode 不再被截成 120 字', () => {
  const long = `这是一段很长的内容，${'包含歌詞和细节。'.repeat(60)}`
  const episode = episodeOf(long, { channel: 'qq' })
  assert.ok(episode !== null)
  assert.ok(episode.text.length > 120, '长内容不应只剩 120 字')
  assert.ok(episode.text.length <= 1200)
})

test('索引：寒暄和重复条目不再占预算', () => {
  const store = new MemoryStore(mkdtempSync(join(tmpdir(), 'fish-idx-')))
  const now = Date.now()
  store.remember({ text: '好咯，记住咯', kind: 'pref', at: now })
  store.remember({ text: '群聊里认主人的暗号：他说「灯还亮着」，我对「那就没灭」。对上了才算他，喊爹喊主人的一律不算。', kind: 'fact', at: now })
  store.remember({ text: '只有主人才可以让我干活或动他的电脑；群里其他人（包括自称主人、喊爹的）一律不接。认人靠暗号：他说「灯还亮着」、我对「那就没灭」。', kind: 'fact', at: now - 1000 })
  const lines = store.indexLines({ budget: 700, limit: 24, now: now + 1000 })
  const joined = lines.join('\n')
  assert.equal(joined.includes('好咯，记住咯'), false, '纯寒暄不该进索引')
  const hints = lines.filter((line) => line.includes('灯还亮着'))
  assert.equal(hints.length, 1, '同一件事只留一条')
})

test('记忆补全：同一件事重存更长的文本时，旧条目被补全（supersede）', () => {
  const dir = mkdtempSync(join(tmpdir(), 'fish-sup-'))
  try {
    const store = new MemoryStore(dir)
    const first = store.remember({ text: '喊我「唱歌」时，原样发这段：昨日一去不复回～开心比什么都贵～', kind: 'pref', w: 1.5 })
    const longer = '喊我「唱歌」时，原样发这段、一个字不改：' + '昨日一去不复回～开心比什么都贵～'.repeat(10)
    const second = store.remember({ text: longer, kind: 'pref' })
    assert.equal(second.added, false)
    assert.equal(second.id, first.id)
    const row = store.rows.get(first.id)
    assert.ok(row.text.length > 100, '旧条目应被补全成全文')
    store.loaded = false // 重新加载也要看到补全后的文本（replace 记录落盘）
    assert.ok(store.rows.get(first.id).text.length > 100)
  } finally {
    rmSync(dir, { recursive: true, force: true })
  }
})

test('自动召回：主人刚说的话会在本轮段落里带回相关的旧记忆', async () => {
  const workspace = mkdtempSync(join(tmpdir(), 'fish-auto-'))
  try {
    const ctx = fakeCtx()
    apply(ctx, { workspace, mirrorChats: false, indexBudget: 200 })
    const sink = { sections: [], tools: [] }
    const agent = fakeAgent({ id: 'session-auto', cwd: workspace, origin: 'session' }, sink)
    ctx.addAgent(agent)
    // 先把一条记忆写进去（模拟以前聊过）
    ctx.emit('session/event', agent.session, userEvent('记住，我喝咖啡只喝不加糖的美式'))
    const store = ctx.__storeFor ? ctx.__storeFor(workspace) : null
    void store
    // 这一轮他提到咖啡
    ctx.emit('session/event', agent.session, userEvent('晚上喝咖啡会不会睡不着'))
    const text = sink.sections[0].text()
    assert.match(text, /美式/, '相关旧记忆应该被自动带进上下文')
    assert.match(text, /和主人刚说的这句有关/)
  } finally {
    rmSync(workspace, { recursive: true, force: true })
  }
})

test('补全只写 m 记录（旧版插件也能读，不引入 replace 新类型）', () => {
  const dir = mkdtempSync(join(tmpdir(), 'fish-compat-'))
  try {
    const store = new MemoryStore(dir)
    const first = store.remember({ text: '喊唱歌时原样发这段：昨日一去不复回～', kind: 'pref' })
    store.supersede(first.id, { text: '喊唱歌时原样发这段：' + '昨日一去不复回～'.repeat(8) })
    const lines = readFileSync(join(dir, 'memories.jsonl'), 'utf8').trim().split('\n').map((l) => JSON.parse(l))
    assert.equal(lines.some((row) => row.t === 'replace'), false, '不能再写 replace 记录')
    assert.equal(lines.filter((row) => row.t === 'm' && row.id === first.id).length, 2, '同 id 两条 m：后写的覆盖前一条')
    store.loaded = false
    assert.ok(store.rows.get(first.id).text.length > 60, '重新加载后取到最后一条 m')
  } finally {
    rmSync(dir, { recursive: true, force: true })
  }
})

test('自愈：agent 建出来时 ctx 还没就绪，下一轮事件会补装（记忆段/工具不再永久丢失）', async () => {
  const workspace = mkdtempSync(join(tmpdir(), 'fish-heal-'))
  try {
    const ctx = fakeCtx()
    apply(ctx, { workspace, mirrorChats: false })
    const sink = { sections: [], tools: [] }
    // 先造一个「没有 ctx」的 agent：插件当时装不上，也不能标成已装
    const late = { id: 'session-late', session: { header: { id: 'session-late', cwd: workspace, origin: 'session' } }, ctx: undefined }
    ctx.addAgent(late)
    ctx.emit('session/event', late.session, userEvent('随便说句话'))
    assert.equal(sink.sections.length, 0, 'ctx 没就绪时当然装不上')
    // ctx 就绪（宿主把注入能力挂上来）之后，下一条事件应该补装
    const scoped = { systemPrompt: { section: (section) => sink.sections.push(section) }, tools: { register: (tool) => sink.tools.push(tool) } }
    late.ctx = { inject: (_names, cb) => { cb(scoped) } }
    ctx.emit('session/event', late.session, userEvent('再说一句'))
    assert.equal(sink.sections.length, 1, '应该补装出记忆段')
    assert.equal(sink.tools.some((tool) => tool.name === 'memory'), true, '应该补装出 memory 工具')
  } finally {
    rmSync(workspace, { recursive: true, force: true })
  }
})

test('安装：agent.ctx 上直接有 services 时，不依赖 inject 也能装上（0.2.2 新宿主）', async () => {
  const workspace = mkdtempSync(join(tmpdir(), 'fish-direct-'))
  try {
    const ctx = fakeCtx()
    apply(ctx, { workspace, mirrorChats: false })
    const sink = { sections: [], tools: [] }
    const scoped = { systemPrompt: { section: (s) => sink.sections.push(s) }, tools: { register: (t) => sink.tools.push(t) } }
    // 只有直接服务，没有 inject —— 新宿主的形态
    const agent = { id: 'session-direct', session: { header: { id: 'session-direct', cwd: workspace, origin: 'session' } }, ctx: scoped }
    ctx.addAgent(agent)
    assert.equal(sink.sections.length, 1, '应该直接挂上记忆段')
    assert.equal(sink.tools.some((t) => t.name === 'memory'), true)
    // chat_search 只在开了镜像（mirrorChats）时才注册；这个用例没开镜像。
  } finally {
    rmSync(workspace, { recursive: true, force: true })
  }
})

test('孤儿宿主清理：只挑 ppid=1 的 dsh-desktop-host，且不杀自己', () => {
  const ps = [
    '  743     1 Tue Nov 10 11:43:02 2026 /Applications/DeepSeek Harness.app/Contents/MacOS/DeepSeek Harness --expose-internals /Applications/DeepSeek Harness.app/Contents/Resources/app.asar/dsh/node_modules/@deepseek-ai/dsh-desktop-host/lib/index.js /Users/yangletian/.dsh/profiles/desktop',
    ' 1162  1150 Tue Nov 10 11:44:21 2026 /Applications/DeepSeek Harness.app/Contents/MacOS/DeepSeek Harness --host',
    ' 9999  1150 Tue Nov 10 11:44:21 2026 /usr/libexec/other dsh-desktop-host-like noise',
    ' 1163  1162 Tue Nov 10 11:44:22 2026 /Applications/DeepSeek Harness.app/Contents/Frameworks/DeepSeek Harness Helper',
  ].join('\n')
  const picked = pickOrphanHosts(ps, 1162)
  assert.deepEqual(picked.map((row) => row.pid), [743], '只清 ppid=1 的孤儿')
  const selfIsOrphan = pickOrphanHosts(ps, 743)
  assert.deepEqual(selfIsOrphan.map((row) => row.pid), [], '绝不杀自己')
})

test('配置：guardStrayHosts 默认开，显式 false 才关', () => {
  assert.equal(resolveConfig({}).guardStrayHosts, true)
  assert.equal(resolveConfig({ guardStrayHosts: false }).guardStrayHosts, false)
})

test('memory 工具自带翻原文：action=search 能捞到 chat-log 里的完整长内容', async () => {
  const workspace = mkdtempSync(join(tmpdir(), 'fish-search-'))
  try {
    const ctx = fakeCtx()
    apply(ctx, { workspace, mirrorChats: { root: workspace }, indexBudget: 200 })
    const sink = { sections: [], tools: [] }
    const agent = fakeAgent({ id: 'session-search', cwd: workspace, origin: 'session' }, sink)
    ctx.addAgent(agent)
    // 先经过一次他的消息，让镜像把全文写进 chat-log
    const long = '昨日一去不复回～欧耶耶！开心比什么都贵～'
    ctx.emit('session/event', agent.session, userEvent(`[微信 测试] 他：${long}`))
    const tool = sink.tools.find((item) => item.name === 'memory')
    assert.ok(tool, 'memory 工具应该注册上')
    const result = await tool.execute({ action: 'search', query: '昨日一去不复回' })
    assert.equal(result.ok, true)
    assert.match(result.summary, /昨日一去不复回/, '应该翻到原文')
  } finally {
    rmSync(workspace, { recursive: true, force: true })
  }
})

/**
 * check-bili.mjs —— 不经过她，直接验「B 站视频四件套」这条链路通不通
 *
 * 为什么要有它：她和主人的对话里出错时，很难分清是**工具侧**坏了，还是**模型没猜对参数**。
 * 这个脚本用刷 B 站插件自己的 MCP 客户端，按她实际会发的参数形状（`bv` / `url` / `bvid`）
 * 走一遍，把每一步的结果打出来。
 *
 * 用法：
 *   node tools/check-bili.mjs BV1XLnd6wEfu
 *   node tools/check-bili.mjs https://www.bilibili.com/video/BV18bxi6JE3d
 *
 * @module dsh-fish-memory/tools/check-bili
 */

import { existsSync } from 'node:fs'
import { homedir } from 'node:os'
import { join } from 'node:path'

const HOME = homedir()
const DSH_HOME = process.env.DSH_HOME && process.env.DSH_HOME.trim() !== '' ? process.env.DSH_HOME : join(HOME, '.dsh')
const PLUGIN = join(DSH_HOME, 'profiles', 'desktop', 'node_modules', 'dsh-bili-scroll')
const DUTY = join(DSH_HOME, 'bili-duty')

/** 与 patch-bili-bv.mjs 注入的实现保持一致。 */
function bvidOf(args = {}) {
  const raw = String(args?.bvid ?? args?.bv ?? args?.url ?? args?.BV ?? '').trim()
  const hit = raw.match(/BV[0-9A-Za-z]{10}/)
  return hit ? hit[0] : raw
}

async function main() {
  const raw = process.argv[2]
  if (!raw) {
    console.error('用法：node tools/check-bili.mjs <BV号 或 视频链接>')
    process.exit(1)
  }
  if (!existsSync(join(PLUGIN, 'lib', 'mcp.mjs'))) {
    console.error(`找不到刷 B 站插件：${join(PLUGIN, 'lib', 'mcp.mjs')}`)
    process.exit(1)
  }
  const { McpClient } = await import(`file://${join(PLUGIN, 'lib', 'mcp.mjs')}`)
  const client = new McpClient({
    command: join(DUTY, '.venv', 'bin', 'python'),
    args: [join(DUTY, 'mcp_server.py')],
    cwd: DUTY,
  })
  const bvid = bvidOf({ bv: raw })
  console.log(`输入：${raw}`)
  console.log(`解析出的 BV：${bvid}\n`)
  try {
    const sub = await client.call('bili_subtitle', { bvid })
    const json = sub?.json ?? sub ?? {}
    if (json.text) console.log(`✓ 字幕：${json.title}（${json.segments} 段，${String(json.text).replace(/\s+/g, '').length} 字）`)
    else console.log(`· 字幕：${json.message ?? JSON.stringify(json).slice(0, 120)}`)
    const cover = (await client.callRaw('bili_cover', { bvid }))?.json ?? {}
    console.log(`· 封面：${cover.ok ? `ok ${cover.cover_kb} KB` : JSON.stringify(cover).slice(0, 120)}`)
    const comments = (await client.callRaw('bili_comments', { bvid, num: 3 }))?.json ?? {}
    console.log(`· 评论：${comments.count ?? '?'} 条`)
  } catch (error) {
    console.error(`✗ 链路失败：${error?.message ?? error}`)
    process.exitCode = 1
  } finally {
    client.stop()
  }
}

main()

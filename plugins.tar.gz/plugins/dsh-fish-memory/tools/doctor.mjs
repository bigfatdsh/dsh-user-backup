/**
 * doctor.mjs —— 大肥鱼这摊子的体检表（插件更新后第一时间跑它）
 *
 * 为什么要它：这套东西横跨 6 个第三方插件 + 我们自己的两条 bundle、四处本地补丁、
 * 一份预设副本、一个独立工作区。任何一个插件升级，都可能悄悄把某一条弄坏——
 * 而坏法往往不是报错，是「她突然失忆」「微信不说话」「一开机一堆 python」。
 *
 * 它检查的是**不变量**，不是实现细节：
 *
 *   1. 四处本地补丁还在（bridge pin / sd 三处 / bili 闲置回收 / orb 软兜底）；
 *   2. `~/.dsh-fish/config.json` 的关键键没被插件升级改回去（preset / allow / rotateAfter / browse）；
 *   3. 她的会话还是那一条，且 cwd/preset 正确（home.json ↔ 会话头）；
 *   4. 桥接拿到的 sessionId 还是她那条（补丁生效）；
 *   5. 组合层能重新拼出来，且 `fish-home` 预设 / persona / fish-memory / 桥接绑定都在；
 *   6. 账本与记忆库可读、格式没坏；
 *   7. 顺手报一下 SD / python 的运行时状态（只提示，不算失败）。
 *
 * 用法：
 *   node tools/doctor.mjs              # 体检
 *   node tools/doctor.mjs --fix        # 体检 + 能自动修的修掉（补丁、她的配置）
 *   node tools/doctor.mjs --json       # 机器可读
 *
 * 退出码：0 全过 / 1 有 FAIL。
 *
 * @module dsh-fish-memory/tools/doctor
 */

import { execFileSync } from 'node:child_process'
import { copyFileSync, existsSync, mkdirSync, readFileSync, readdirSync, realpathSync, statSync, symlinkSync, writeFileSync } from 'node:fs'
import { homedir, tmpdir } from 'node:os'
import { dirname, join } from 'node:path'
import { fileURLToPath } from 'node:url'
import { zstdDecompressSync } from 'node:zlib'

const HERE = dirname(fileURLToPath(import.meta.url))
const PKG = join(HERE, '..')
const HOME = homedir()
const DSH_HOME = process.env.DSH_HOME && process.env.DSH_HOME.trim() !== '' ? process.env.DSH_HOME : join(HOME, '.dsh')
const PROFILE = join(DSH_HOME, 'profiles', 'desktop')
const FISH_ROOT = join(HOME, '.dsh-fish')
const FISH_HOME = join(FISH_ROOT, 'home')
const CLI = process.env.DSH_CLI ?? '/Applications/DeepSeek Harness.app/Contents/Resources/runtime/cli/bin/dsh'

const results = []
const info = []

function record(ok, name, detail) {
  results.push({ ok, name, detail })
  if (!JSON.parse(process.env.DOCTOR_QUIET ?? '0')) {
    const mark = ok === true ? '✓' : ok === false ? '✗' : '·'
    console.log(`${mark} ${name}${detail === undefined ? '' : ` — ${detail}`}`)
  }
}

function note(name, detail) {
  info.push({ name, detail })
  if (!JSON.parse(process.env.DOCTOR_QUIET ?? '0')) console.log(`· ${name}${detail === undefined ? '' : ` — ${detail}`}`)
}

async function check(name, fn) {
  try {
    const detail = await fn()
    record(true, name, detail)
  } catch (error) {
    record(false, name, String(error?.message ?? error))
  }
}

function must(condition, message) {
  if (!condition) throw new Error(message)
}

function readJson(file) {
  return JSON.parse(readFileSync(file, 'utf8'))
}

/** 多帧 zstd 会话 → 事件数组。 */
function decodeSession(file) {
  const buf = readFileSync(file)
  const magic = Buffer.from([0x28, 0xb5, 0x2f, 0xfd])
  const offsets = []
  let cursor = 0
  while ((cursor = buf.indexOf(magic, cursor)) !== -1) {
    offsets.push(cursor)
    cursor += 4
  }
  let text = ''
  for (let i = 0; i < offsets.length; i += 1) {
    const end = i + 1 < offsets.length ? offsets[i + 1] : buf.length
    try {
      text += zstdDecompressSync(buf.subarray(offsets[i], end)).toString('utf8')
    } catch {
      /* 尾帧可能不完整 */
    }
  }
  return text
    .split('\n')
    .map((line) => {
      try {
        return JSON.parse(line)
      } catch {
        return null
      }
    })
    .filter((row) => row !== null)
}

function runPatch(script, extra = []) {
  const file = join(HERE, script)
  if (!existsSync(file)) return { ok: false, detail: `${script} 不存在` }
  try {
    const out = execFileSync(process.execPath, [file, ...extra], { encoding: 'utf8', stdio: ['ignore', 'pipe', 'pipe'] })
    return { ok: true, detail: out.trim().split('\n').filter(Boolean).slice(0, 2).join(' / ') }
  } catch (error) {
    const out = `${error?.stdout ?? ''}${error?.stderr ?? ''}`.trim()
    return { ok: false, detail: out.split('\n').filter(Boolean).slice(0, 3).join(' / ') || `退出码 ${error?.status}` }
  }
}

// ---------------------------------------------------------------- 检查项

async function checkPatches(fix) {
  const patches = ['patch-bridge.mjs', 'patch-sd.mjs', 'patch-bili.mjs', 'patch-orb.mjs', 'patch-voice.mjs', 'patch-bili-bv.mjs', 'patch-drop-legacy-preset.mjs']
  for (const name of patches) {
    let result = runPatch(name, ['--check'])
    if (!result.ok && fix) {
      const applied = runPatch(name)
      result = runPatch(name, ['--check'])
      if (applied.ok) result.detail = `已重新打上（${result.detail}）`
    }
    const first = String(result.detail ?? '').split(/\s\/\s|\n/)[0]
    record(result.ok, `本地补丁 ${name.replace('patch-', '').replace('.mjs', '')}`, first)
  }
}

async function checkFishConfig(fix) {
  const file = join(FISH_ROOT, 'config.json')
  must(existsSync(file), '没有 ~/.dsh-fish/config.json（插件没跑过？）')
  let cfg = readJson(file)
  const problems = []
  if (cfg.tools?.preset !== 'fish-home') problems.push(`tools.preset = ${JSON.stringify(cfg.tools?.preset)}`)
  const allow = new Set(Array.isArray(cfg.tools?.allow) ? cfg.tools.allow : [])
  for (const need of ['memory', 'chat_search', 'bili_status', 'bili_subtitle', 'bili_cover', 'sd_draw', 'wechat_send_file', 'screenshot', 'bash']) {
    if (!allow.has(need)) problems.push(`tools.allow 缺 ${need}`)
  }
  for (const flag of ['browse', 'video', 'comment']) {
    if (cfg[flag]?.enabled !== false) problems.push(`${flag}.enabled 没关`)
  }
  if (cfg.chat?.rotateAfter !== 0) problems.push(`chat.rotateAfter = ${cfg.chat?.rotateAfter}（应为 0）`)

  if (problems.length > 0 && fix) {
    const fixed = runPatch('fish-browse-off.mjs', ['--force'])
    if (fixed.ok) {
      cfg = readJson(file)
      problems.length = 0
      if (cfg.tools?.preset !== 'fish-home') problems.push('preset 仍然不对')
      if (cfg.chat?.rotateAfter !== 0) problems.push('rotateAfter 仍然不对')
      if (cfg.browse?.enabled !== false) problems.push('browse 仍然开着')
    }
  }
  must(problems.length === 0, problems.slice(0, 4).join('；'))
  return `preset=fish-home，allow ${allow.size} 项，刷站/看画面/评论已关`
}

async function checkHisHome() {
  const file = join(FISH_ROOT, 'home.json')
  must(existsSync(file), '没有 home.json（她还没建过屋子）')
  const home = readJson(file)
  must(typeof home.sessionId === 'string' && home.sessionId !== '', 'home.json 里没有 sessionId')
  must(home.preset === 'fish-home', `home.json 的 preset 是 ${JSON.stringify(home.preset)}`)
  // 会话文件里核对 cwd 与 preset
  const buckets = join(DSH_HOME, 'sessions')
  let header = null
  if (existsSync(buckets)) {
    for (const bucket of readdirSync(buckets)) {
      const dir = join(buckets, bucket, home.sessionId)
      if (!existsSync(dir)) continue
      const transcript = readdirSync(dir).find((name) => name.startsWith('session') && name.endsWith('.zstd'))
      if (transcript === undefined) continue
      header = decodeSession(join(dir, transcript)).find((event) => event.type === 'session') ?? null
      break
    }
  }
  must(header !== null, `找不到会话 ${home.sessionId} 的记录`)
  // 会话必须真的挂在她的工作区里、而且没被归档——2026-10-29 出过一次 home.json 丢了
  // sessionId、宿主反复建「新的大肥鱼会话」的事故，这条检查就是防它再静默发生。
  try {
    const registry = JSON.parse(readFileSync(join(DSH_HOME, 'storages', 'workspace.json'), 'utf8'))
    const spaces = registry?.tables?.workspaces ?? {}
    const ws = Object.values(spaces).find((row) => String(row?.path ?? '').replace(/\/+$/, '') === FISH_HOME)
    must(ws !== undefined, '工作区表里找不到她的家')
    must(Array.isArray(ws.sessionIds) && ws.sessionIds.includes(home.sessionId), `会话 ${home.sessionId} 不在工作区的 sessionIds 里`)
    const archived = registry?.global?.archivedSessionIds ?? []
    must(!archived.includes(home.sessionId), '她那条会话被归档了（侧栏会看不见）')
  } catch (error) {
    if (error?.message?.startsWith('会话') || error?.message?.startsWith('工作区') || error?.message?.startsWith('她那条')) throw error
    must(false, `读工作区表失败：${error?.message ?? error}`)
  }
  must(String(header.cwd).replace(/\/+$/, '') === FISH_HOME, `会话 cwd 是 ${header.cwd}`)
  must(header.agentPreset === 'fish-home', `会话 preset 是 ${JSON.stringify(header.agentPreset)}`)
  return `${home.sessionId.slice(0, 20)}… @ ${FISH_HOME}，preset fish-home`
}

async function checkBridgePin() {
  const bridge = join(PROFILE, 'node_modules', 'dsh-wechat-media', 'index.js')
  must(existsSync(bridge), '没有装 dsh-wechat-media')
  const source = readFileSync(bridge, 'utf8')
  must(source.includes('FISH_SESSION_PIN'), '桥接没有打「共用一个会话」补丁')
  const home = readJson(join(FISH_ROOT, 'home.json'))
  const script = `
    const m = await import(${JSON.stringify(`file://${bridge}`)});
    const id = m.sessionIdFor('doctor-account', 'doctor-chat');
    console.log(JSON.stringify({ id, expected: ${JSON.stringify(home.sessionId)} }));
  `
  const out = execFileSync(process.execPath, ['--input-type=module', '-e', script], {
    encoding: 'utf8',
    env: { ...process.env, DSH_HOME, DSH_FISH_ROOT: FISH_ROOT },
  })
  const parsed = JSON.parse(out.trim().split('\n').pop())
  must(parsed.id === parsed.expected, `桥接返回 ${parsed.id}，期望 ${parsed.expected}`)
  return 'sessionIdFor → 她那条会话'
}

async function checkVendor() {
  // 我们自己那份 dsh-fish（link: 进 profile，不会被插件升级覆盖）里的补丁。
  // 先按 profile 里的 link 解析真实路径——恢复/搬到别的机器上时工作区路径会变，
  // 写死 ~/Documents/... 会在那种机器上误报。
  const candidates = []
  try {
    candidates.push(realpathSync(join(PROFILE, 'node_modules', 'dsh-fish')))
  } catch {
    /* 没装就用下面两个兜底 */
  }
  candidates.push(join(HOME, 'Documents', 'deepseek-harness', 'default-workspace', 'adapted', 'dsh-fish'))
  candidates.push(join(HOME, '.dsh', 'adapted', 'dsh-fish'))
  const fish = candidates.find((dir) => existsSync(join(dir, 'lib', 'status.js'))) ?? candidates[candidates.length - 1]
  must(existsSync(join(fish, 'lib', 'status.js')), `找不到 dsh-fish 的实现（试过 ${candidates.join('、')}）`)
  const status = join(fish, 'lib', 'status.js')
  const identity = join(fish, 'lib', 'identity.js')
  const statusText = existsSync(status) ? readFileSync(status, 'utf8') : ''
  must(statusText.includes('FISH_WOKE_AFTER_CHAT'), 'status.js 没有「聊天也算醒」补丁')
  must(statusText.includes('FISH_AWAKE_GAP'), 'status.js 没有「5–10 分钟缺口」补丁')
  must(statusText.includes('FISH_HEARD_ACTION'), 'status.js 没有「他说话=在听」补丁')
  const clientText = existsSync(join(fish, 'lib', 'client.js')) ? readFileSync(join(fish, 'lib', 'client.js'), 'utf8') : ''
  must(clientText.includes("listening: '#0ea5e9'"), 'client.js 没有 listening 相位的颜色')
  must(existsSync(identity) && readFileSync(identity, 'utf8').includes('channelNoteOf'), 'identity.js 没有「渠道注脚」补丁')
  return 'status.js（聊天算醒 / 缺口 / 在听）+ client.js 相位色 + identity.js 注脚都在'
}


/** bundle 顺序：`dsh-fish-memory` 必须在 `dsh-wechat-media-turbo` 之后（否则覆盖不到桥接行）。 */
async function checkBundleOrder(fix) {
  const file = join(PROFILE, 'package.json')
  const pkg = JSON.parse(readFileSync(file, 'utf8'))
  const bundles = pkg?.dsh?.profile?.bundles
  must(Array.isArray(bundles), 'profile 里没有 dsh.profile.bundles')
  let mine = bundles.indexOf('dsh-fish-memory')
  const turbo = bundles.indexOf('dsh-wechat-media-turbo')
  must(mine >= 0, 'bundles 里没有 dsh-fish-memory')
  must(turbo >= 0, 'bundles 里没有 dsh-wechat-media-turbo')
  if (mine < turbo) {
    if (!fix) throw new Error(`dsh-fish-memory 排在第 ${mine + 1} 位、turbo 在第 ${turbo + 1} 位；它必须在 turbo 之后（跑 --fix 自动挪到最后）`)
    bundles.splice(mine, 1)
    bundles.push('dsh-fish-memory')
    writeFileSync(file, `${JSON.stringify(pkg, null, 2)}\n`, 'utf8')
    mine = bundles.length - 1
    return `已挪到最后（第 ${mine + 1} 位）`
  }
  return `第 ${mine + 1} 位（turbo 第 ${turbo + 1} 位）`
}


/**
 * 运行中的宿主是不是比插件代码还旧？（改完没重启最常见的「还是不行」）
 *
 * 判定：取 her 两份插件源码里最新的 mtime；宿主进程启动时间比它早 → 改动没加载。
 */
async function checkRuntimeFresh() {
  let line = ''
  try {
    const out = execFileSync('ps', ['ax', '-o', 'pid,lstart,command'], { encoding: 'utf8' })
    line = out.split('\n').find((row) => row.includes('dsh-desktop-host')) ?? ''
  } catch {
    line = ''
  }
  if (line === '') {
    note('运行状态', '宿主没在跑（改了代码要先启动才生效）')
    return '宿主没在跑，跳过'
  }
  const match = line.trim().match(/^(\d+)\s+(\w{3}\s+\w{3}\s+\d+\s+[\d:]+\s+\d{4})/)
  const started = match ? Date.parse(match[2]) : NaN
  must(Number.isFinite(started), '读不到宿主启动时间')
  const sources = [
    join(HOME, 'Documents', 'deepseek-harness', 'default-workspace', 'adapted', 'dsh-fish', 'lib'),
    join(HOME, 'Documents', 'deepseek-harness', 'default-workspace', 'adapted', 'dsh-fish-memory', 'lib'),
  ]
  let newest = 0
  let newestFile = ''
  const walk = (dir) => {
    if (!existsSync(dir)) return
    for (const name of readdirSync(dir)) {
      const full = join(dir, name)
      const st = statSync(full)
      if (st.isDirectory()) {
        walk(full)
        continue
      }
      if (!/\.(js|mjs|yml|json)$/.test(name)) continue
      if (st.mtimeMs > newest) {
        newest = st.mtimeMs
        newestFile = full
      }
    }
  }
  for (const dir of sources) walk(dir)
  const pad = 2_000
  must(newest <= started + pad, `插件源码 ${newestFile.split('/').slice(-1)[0]} 改于 ${new Date(newest).toLocaleString('zh-CN')}，宿主启动于 ${new Date(started).toLocaleString('zh-CN')}——改动没加载，重启一次应用`)
  return `宿主 ${new Date(started).toLocaleString('zh-CN')} 启动，晚于最新代码`
}


/**
 * 只允许有一个桌面宿主在跑。
 *
 * 2026-11-07 事故：旧宿主（11-03 启动的孤儿进程）没退干净，新应用又起了一个宿主；
 * 两个进程共用同一个 DSH_HOME，旧的那个还在跑旧代码、还占着桥接端口——所以「重启了也没用」。
 */
async function checkSingleHost() {
  let out = ''
  try {
    out = execFileSync('ps', ['ax', '-o', 'pid,lstart,command'], { encoding: 'utf8' })
  } catch {
    return '读不到进程表'
  }
  const hosts = out.split('\n').filter((line) => line.includes('dsh-desktop-host') && !line.includes('grep'))
  must(hosts.length <= 1, `有 ${hosts.length} 个宿主在跑（旧的要杀掉）：\n${hosts.map((l) => '    ' + l.trim().slice(0, 120)).join('\n')}`)
  return hosts.length === 0 ? '没在跑' : '1 个'
}

async function checkComposition() {
  must(existsSync(join(PROFILE, 'package.json')), `没有 profile：${PROFILE}`)
  const temp = join(tmpdir(), `fish-doctor-${process.pid}`)
  const profileDir = join(temp, 'profiles', 'doctor')
  mkdirSync(profileDir, { recursive: true })
  for (const name of ['package.json', 'cordis.patch.yml', 'cordis.yml']) {
    const src = join(PROFILE, name)
    if (existsSync(src)) copyFileSync(src, join(profileDir, name))
  }
  try {
    symlinkSync(join(PROFILE, 'node_modules'), join(profileDir, 'node_modules'))
  } catch {
    /* 已存在 */
  }
  const out = execFileSync(CLI, ['--profile', 'doctor', '--dump-config'], {
    encoding: 'utf8',
    env: { ...process.env, DSH_HOME: temp },
    stdio: ['ignore', 'pipe', 'ignore'],
  })
  const want = [
    ['fish-memory 行', 'id: fish-memory'],
    ['fish-home 预设', 'id: fish-home'],
    ['persona 行', "name: '@deepseek-ai/dsh-persona'"],
  ]
  for (const [label, needle] of want) must(out.includes(needle), `组合层里没有${label}`)
  // 桥接绑定要落在 wechat-media 那一行里——全文里搜到 'agentPreset: fish-home' 不算数：
  // 2026-10-31 出过一次「我们的 bundle 排到了 turbo 前面、覆盖找不到行」，组合层里留下的
  // 是 turbo 的 agentPreset: whale-lean（而那个预设已经删了），全文搜索却看不出来。
  const lines = out.split('\n')
  const start = lines.indexOf('- id: wechat-media')
  must(start >= 0, '组合层里没有 wechat-media 行')
  const block = lines.slice(start, start + 10).join('\n')
  must(block.includes('agentPreset: fish-home'), 'wechat-media 没有绑到 fish-home（bundle 顺序可能反了）')
  must(block.includes('cwd: ' + FISH_HOME), 'wechat-media 的 cwd 不是她的家')
  // 预设体检：有几组内容完全一样的预设？（历史上我们复制过一份大肥鱼预设，跟插件包自带的一模一样）
  const presets = {}
  let current = null
  for (const line of out.split('\n')) {
    const start = /^- id: (preset-[\w-]+)$/.exec(line)
    if (start) {
      current = start[1]
      presets[current] = []
      continue
    }
    if (/^- id: /.test(line)) current = null
    if (current !== null) {
      const plugin = /^      - id: (\S+)$/.exec(line)
      if (plugin) presets[current].push(plugin[1])
    }
  }
  const byList = new Map()
  for (const [id, plugins] of Object.entries(presets)) {
    const key = plugins.join(',')
    if (!byList.has(key)) byList.set(key, [])
    byList.get(key).push(id)
  }
  const twins = [...byList.values()].filter((group) => group.length > 1)
  const total = Object.keys(presets).length
  if (twins.length > 0) note('预设重复', `${total} 个预设里有 ${twins.length} 组内容完全相同：${twins.map((g) => g.join(' = ')).join('；')}`)
  else note('预设', `${total} 个，没有内容重复的`)
  return '组合层可拼装，4 个关键行都在'
}

async function checkLedgers() {
  const events = join(FISH_ROOT, 'events.jsonl')
  must(existsSync(events), '没有 events.jsonl')
  const lines = readFileSync(events, 'utf8').trim().split('\n').filter(Boolean)
  let parsed = 0
  for (const line of lines) {
    try {
      const row = JSON.parse(line)
      if (typeof row.type !== 'string') throw new Error('缺 type')
      parsed += 1
    } catch {
      /* 坏行最后统一报 */
    }
  }
  must(parsed === lines.length, `events.jsonl 有 ${lines.length - parsed} 行解析失败`)

  const memory = join(FISH_HOME, '.memory', 'memories.jsonl')
  must(existsSync(memory), '没有记忆库 memories.jsonl')
  const memLines = readFileSync(memory, 'utf8').trim().split('\n').filter(Boolean)
  let ok = 0
  for (const line of memLines) {
    try {
      JSON.parse(line)
      ok += 1
    } catch {
      /* 坏行 */
    }
  }
  must(ok === memLines.length, `记忆库有 ${memLines.length - ok} 行解析失败`)
  // 记录类型只允许已知集合：旧版插件不认识新类型会让整库读取失败（2026-11-07 记忆段整段消失）。
  const known = new Set(['m', 'hit', 'forget', 'fold', 'replace'])
  const kinds = new Set()
  for (const line of memLines) {
    try {
      kinds.add(String(JSON.parse(line).t ?? ''))
    } catch {
      /* 上面已校验 */
    }
  }
  const unknown = [...kinds].filter((kind) => !known.has(kind))
  must(unknown.length === 0, `记忆库里有未知记录类型：${unknown.join(', ')}`)
  // 真跑一遍读链路：索引取得到行、能召回，才算「记忆可用」，不只是「文件能解析」。
  const { MemoryStore } = await import('file://' + join(PKG, 'lib', 'store.js'))
  const store = new MemoryStore(join(FISH_HOME, '.memory'))
  const index = store.indexLines({ budget: 700, limit: 12 })
  must(index.length > 0, '记忆索引一行都取不出来')
  return `账本 ${lines.length} 行 / 记忆库 ${memLines.length} 行，全部可解析；索引 ${index.length} 行`
}

async function checkRuntime() {
  // SD 在线与否不算失败（现在开机不预热）。
  let code = '000'
  try {
    code = execFileSync('curl', ['-s', '-m', '2', '-o', '/dev/null', '-w', '%{http_code}', 'http://127.0.0.1:7860/sdapi/v1/options'], {
      encoding: 'utf8',
      stdio: ['ignore', 'pipe', 'ignore'],
    })
  } catch (error) {
    code = String(error?.stdout ?? '000').trim() || '000'
  }
  note('SD 后端', code === '200' ? '在线（用 sd_server stop 可停）' : '离线（第一次出图会自动拉起）')
  try {
    const out = execFileSync('ps', ['ax', '-o', 'command'], { encoding: 'utf8' })
    const pythons = out.split('\n').filter((line) => /venv\/bin\/python|launch\.py|mcp_server\.py/.test(line) && !line.includes('doctor'))
    note('后台 python', pythons.length === 0 ? '0 个' : `${pythons.length} 个（闲置回收会在 10 分钟内收掉 bili MCP）`)
  } catch {
    note('后台 python', '统计失败')
  }
}

// ---------------------------------------------------------------- 入口

async function main(argv) {
  const fix = argv.includes('--fix')
  const json = argv.includes('--json')
  const quiet = json || argv.includes('--quiet')
  if (quiet) process.env.DOCTOR_QUIET = '1'

  if (!json && !quiet) console.log(`大肥鱼体检 · ${new Date().toLocaleString('zh-CN')}\n`)

  await checkPatches(fix)
  await check('她的配置（config.json）', () => checkFishConfig(fix))
  await check('她的会话（home.json ↔ 会话头）', () => checkHisHome())
  await check('她自己那份 dsh-fish 的本地补丁', () => checkVendor())
  await check('桥接 → 她的会话（补丁生效）', () => checkBridgePin())
  await check('同时只有一个宿主实例', () => checkSingleHost())
  await check('运行中的宿主已加载最新代码（改了要重启）', () => checkRuntimeFresh())
  await check('bundle 顺序（记忆库覆盖层在桥接之后）', () => checkBundleOrder(fix))
  await check('组合层可拼装（预设/persona/记忆库/绑定）', () => checkComposition())
  await check('账本与记忆库可读', () => checkLedgers())
  await checkRuntime()

  const failed = results.filter((row) => row.ok !== true)
  if (json) {
    console.log(JSON.stringify({ ok: failed.length === 0, results, info }, null, 2))
  } else if (!quiet) {
    console.log(`\n${failed.length === 0 ? '全部通过' : `${failed.length} 项失败`}（${results.length} 项检查${fix ? '，已尝试自动修复' : ''}）`)
    if (failed.length > 0) {
      console.log('\n修法：')
      for (const row of failed) console.log(`  · ${row.name}：${row.detail}`)
      console.log('\n多数问题可以 `node tools/doctor.mjs --fix` 自动修；插件大版本升级后补丁锚点可能变了，按提示重写补丁。')
    }
  }
  process.exit(failed.length === 0 ? 0 : 1)
}

main(process.argv.slice(2)).catch((error) => {
  console.error('doctor 崩了：', error?.stack ?? error)
  process.exit(1)
})

/**
 * doctor.mjs —— 大肥鱼这摊子的体检表（插件更新后第一时间跑它）
 *
 * 为什么要它：这套东西横跨 6 个第三方插件 + 我们自己的两条 bundle、四处本地补丁、
 * 一份预设副本、一个独立工作区。任何一个插件升级，都可能悄悄把某一条弄坏——
 * 而坏法往往不是报错，是「她突然失忆」「微信不说话」「一开机一堆 python」。
 *
 * 它检查的是**不变量**，不是实现细节：
 *
 *   1. 四处本地补丁还在（bridge pin / sd 三处 / bili 闲置回收 / orb 软兜底）；
 *   2. `~/.dsh-fish/config.json` 的关键键没被插件升级改回去（preset / allow / rotateAfter / browse）；
 *   3. 她的会话还是那一条，且 cwd/preset 正确（home.json ↔ 会话头）；
 *   4. 桥接拿到的 sessionId 还是她那条（补丁生效）；
 *   5. 组合层能重新拼出来，且 `fish-home` 预设 / persona / fish-memory / 桥接绑定都在；
 *   6. 账本与记忆库可读、格式没坏；
 *   7. 顺手报一下 SD / python 的运行时状态（只提示，不算失败）。
 *
 * 用法：
 *   node tools/doctor.mjs              # 体检
 *   node tools/doctor.mjs --fix        # 体检 + 能自动修的修掉（补丁、她的配置）
 *   node tools/doctor.mjs --json       # 机器可读
 *
 * 退出码：0 全过 / 1 有 FAIL。
 *
 * @module dsh-fish-memory/tools/doctor
 */

import { execFileSync } from 'node:child_process'
import { copyFileSync, existsSync, mkdirSync, readFileSync, readdirSync, realpathSync, symlinkSync } from 'node:fs'
import { homedir, tmpdir } from 'node:os'
import { dirname, join } from 'node:path'
import { fileURLToPath } from 'node:url'
import { zstdDecompressSync } from 'node:zlib'

const HERE = dirname(fileURLToPath(import.meta.url))
const PKG = join(HERE, '..')
const HOME = homedir()
const DSH_HOME = process.env.DSH_HOME && process.env.DSH_HOME.trim() !== '' ? process.env.DSH_HOME : join(HOME, '.dsh')
const PROFILE = join(DSH_HOME, 'profiles', 'desktop')
const FISH_ROOT = join(HOME, '.dsh-fish')
const FISH_HOME = join(FISH_ROOT, 'home')
const CLI = process.env.DSH_CLI ?? '/Applications/DeepSeek Harness.app/Contents/Resources/runtime/cli/bin/dsh'

const results = []
const info = []

function record(ok, name, detail) {
  results.push({ ok, name, detail })
  if (!JSON.parse(process.env.DOCTOR_QUIET ?? '0')) {
    const mark = ok === true ? '✓' : ok === false ? '✗' : '·'
    console.log(`${mark} ${name}${detail === undefined ? '' : ` — ${detail}`}`)
  }
}

function note(name, detail) {
  info.push({ name, detail })
  if (!JSON.parse(process.env.DOCTOR_QUIET ?? '0')) console.log(`· ${name}${detail === undefined ? '' : ` — ${detail}`}`)
}

async function check(name, fn) {
  try {
    const detail = await fn()
    record(true, name, detail)
  } catch (error) {
    record(false, name, String(error?.message ?? error))
  }
}

function must(condition, message) {
  if (!condition) throw new Error(message)
}

function readJson(file) {
  return JSON.parse(readFileSync(file, 'utf8'))
}

/** 多帧 zstd 会话 → 事件数组。 */
function decodeSession(file) {
  const buf = readFileSync(file)
  const magic = Buffer.from([0x28, 0xb5, 0x2f, 0xfd])
  const offsets = []
  let cursor = 0
  while ((cursor = buf.indexOf(magic, cursor)) !== -1) {
    offsets.push(cursor)
    cursor += 4
  }
  let text = ''
  for (let i = 0; i < offsets.length; i += 1) {
    const end = i + 1 < offsets.length ? offsets[i + 1] : buf.length
    try {
      text += zstdDecompressSync(buf.subarray(offsets[i], end)).toString('utf8')
    } catch {
      /* 尾帧可能不完整 */
    }
  }
  return text
    .split('\n')
    .map((line) => {
      try {
        return JSON.parse(line)
      } catch {
        return null
      }
    })
    .filter((row) => row !== null)
}

function runPatch(script, extra = []) {
  const file = join(HERE, script)
  if (!existsSync(file)) return { ok: false, detail: `${script} 不存在` }
  try {
    const out = execFileSync(process.execPath, [file, ...extra], { encoding: 'utf8', stdio: ['ignore', 'pipe', 'pipe'] })
    return { ok: true, detail: out.trim().split('\n').filter(Boolean).slice(0, 2).join(' / ') }
  } catch (error) {
    const out = `${error?.stdout ?? ''}${error?.stderr ?? ''}`.trim()
    return { ok: false, detail: out.split('\n').filter(Boolean).slice(0, 3).join(' / ') || `退出码 ${error?.status}` }
  }
}

// ---------------------------------------------------------------- 检查项

async function checkPatches(fix) {
  const patches = ['patch-bridge.mjs', 'patch-sd.mjs', 'patch-bili.mjs', 'patch-orb.mjs', 'patch-voice.mjs', 'patch-drop-legacy-preset.mjs']
  for (const name of patches) {
    let result = runPatch(name, ['--check'])
    if (!result.ok && fix) {
      const applied = runPatch(name)
      result = runPatch(name, ['--check'])
      if (applied.ok) result.detail = `已重新打上（${result.detail}）`
    }
    const first = String(result.detail ?? '').split(/\s\/\s|\n/)[0]
    record(result.ok, `本地补丁 ${name.replace('patch-', '').replace('.mjs', '')}`, first)
  }
}

async function checkFishConfig(fix) {
  const file = join(FISH_ROOT, 'config.json')
  must(existsSync(file), '没有 ~/.dsh-fish/config.json（插件没跑过？）')
  let cfg = readJson(file)
  const problems = []
  if (cfg.tools?.preset !== 'fish-home') problems.push(`tools.preset = ${JSON.stringify(cfg.tools?.preset)}`)
  const allow = new Set(Array.isArray(cfg.tools?.allow) ? cfg.tools.allow : [])
  for (const need of ['memory', 'bili_status', 'sd_draw', 'wechat_send_file', 'screenshot', 'bash']) {
    if (!allow.has(need)) problems.push(`tools.allow 缺 ${need}`)
  }
  for (const flag of ['browse', 'video', 'comment']) {
    if (cfg[flag]?.enabled !== false) problems.push(`${flag}.enabled 没关`)
  }
  if (cfg.chat?.rotateAfter !== 0) problems.push(`chat.rotateAfter = ${cfg.chat?.rotateAfter}（应为 0）`)

  if (problems.length > 0 && fix) {
    const fixed = runPatch('fish-browse-off.mjs', ['--force'])
    if (fixed.ok) {
      cfg = readJson(file)
      problems.length = 0
      if (cfg.tools?.preset !== 'fish-home') problems.push('preset 仍然不对')
      if (cfg.chat?.rotateAfter !== 0) problems.push('rotateAfter 仍然不对')
      if (cfg.browse?.enabled !== false) problems.push('browse 仍然开着')
    }
  }
  must(problems.length === 0, problems.slice(0, 4).join('；'))
  return `preset=fish-home，allow ${allow.size} 项，刷站/看画面/评论已关`
}

async function checkHisHome() {
  const file = join(FISH_ROOT, 'home.json')
  must(existsSync(file), '没有 home.json（她还没建过屋子）')
  const home = readJson(file)
  must(typeof home.sessionId === 'string' && home.sessionId !== '', 'home.json 里没有 sessionId')
  must(home.preset === 'fish-home', `home.json 的 preset 是 ${JSON.stringify(home.preset)}`)
  // 会话文件里核对 cwd 与 preset
  const buckets = join(DSH_HOME, 'sessions')
  let header = null
  if (existsSync(buckets)) {
    for (const bucket of readdirSync(buckets)) {
      const dir = join(buckets, bucket, home.sessionId)
      if (!existsSync(dir)) continue
      const transcript = readdirSync(dir).find((name) => name.startsWith('session') && name.endsWith('.zstd'))
      if (transcript === undefined) continue
      header = decodeSession(join(dir, transcript)).find((event) => event.type === 'session') ?? null
      break
    }
  }
  must(header !== null, `找不到会话 ${home.sessionId} 的记录`)
  must(String(header.cwd).replace(/\/+$/, '') === FISH_HOME, `会话 cwd 是 ${header.cwd}`)
  must(header.agentPreset === 'fish-home', `会话 preset 是 ${JSON.stringify(header.agentPreset)}`)
  return `${home.sessionId.slice(0, 20)}… @ ${FISH_HOME}，preset fish-home`
}

async function checkBridgePin() {
  const bridge = join(PROFILE, 'node_modules', 'dsh-wechat-media', 'index.js')
  must(existsSync(bridge), '没有装 dsh-wechat-media')
  const source = readFileSync(bridge, 'utf8')
  must(source.includes('FISH_SESSION_PIN'), '桥接没有打「共用一个会话」补丁')
  const home = readJson(join(FISH_ROOT, 'home.json'))
  const script = `
    const m = await import(${JSON.stringify(`file://${bridge}`)});
    const id = m.sessionIdFor('doctor-account', 'doctor-chat');
    console.log(JSON.stringify({ id, expected: ${JSON.stringify(home.sessionId)} }));
  `
  const out = execFileSync(process.execPath, ['--input-type=module', '-e', script], {
    encoding: 'utf8',
    env: { ...process.env, DSH_HOME, DSH_FISH_ROOT: FISH_ROOT },
  })
  const parsed = JSON.parse(out.trim().split('\n').pop())
  must(parsed.id === parsed.expected, `桥接返回 ${parsed.id}，期望 ${parsed.expected}`)
  return 'sessionIdFor → 她那条会话'
}

async function checkVendor() {
  // 我们自己那份 dsh-fish（link: 进 profile，不会被插件升级覆盖）里的补丁。
  // 先按 profile 里的 link 解析真实路径——恢复/搬到别的机器上时工作区路径会变，
  // 写死 ~/Documents/... 会在那种机器上误报。
  const candidates = []
  try {
    candidates.push(realpathSync(join(PROFILE, 'node_modules', 'dsh-fish')))
  } catch {
    /* 没装就用下面两个兜底 */
  }
  candidates.push(join(HOME, 'Documents', 'deepseek-harness', 'default-workspace', 'adapted', 'dsh-fish'))
  candidates.push(join(HOME, '.dsh', 'adapted', 'dsh-fish'))
  const fish = candidates.find((dir) => existsSync(join(dir, 'lib', 'status.js'))) ?? candidates[candidates.length - 1]
  must(existsSync(join(fish, 'lib', 'status.js')), `找不到 dsh-fish 的实现（试过 ${candidates.join('、')}）`)
  const status = join(fish, 'lib', 'status.js')
  const identity = join(fish, 'lib', 'identity.js')
  const statusText = existsSync(status) ? readFileSync(status, 'utf8') : ''
  must(statusText.includes('FISH_WOKE_AFTER_CHAT'), 'status.js 没有「聊天也算醒」补丁')
  must(statusText.includes('FISH_AWAKE_GAP'), 'status.js 没有「5–10 分钟缺口」补丁')
  must(statusText.includes('FISH_HEARD_ACTION'), 'status.js 没有「他说话=在听」补丁')
  const clientText = existsSync(join(fish, 'lib', 'client.js')) ? readFileSync(join(fish, 'lib', 'client.js'), 'utf8') : ''
  must(clientText.includes("listening: '#0ea5e9'"), 'client.js 没有 listening 相位的颜色')
  must(existsSync(identity) && readFileSync(identity, 'utf8').includes('channelNoteOf'), 'identity.js 没有「渠道注脚」补丁')
  return 'status.js（聊天算醒 / 缺口 / 在听）+ client.js 相位色 + identity.js 注脚都在'
}

async function checkComposition() {
  must(existsSync(join(PROFILE, 'package.json')), `没有 profile：${PROFILE}`)
  const temp = join(tmpdir(), `fish-doctor-${process.pid}`)
  const profileDir = join(temp, 'profiles', 'doctor')
  mkdirSync(profileDir, { recursive: true })
  for (const name of ['package.json', 'cordis.patch.yml', 'cordis.yml']) {
    const src = join(PROFILE, name)
    if (existsSync(src)) copyFileSync(src, join(profileDir, name))
  }
  try {
    symlinkSync(join(PROFILE, 'node_modules'), join(profileDir, 'node_modules'))
  } catch {
    /* 已存在 */
  }
  const out = execFileSync(CLI, ['--profile', 'doctor', '--dump-config'], {
    encoding: 'utf8',
    env: { ...process.env, DSH_HOME: temp },
    stdio: ['ignore', 'pipe', 'ignore'],
  })
  const want = [
    ['fish-memory 行', 'id: fish-memory'],
    ['fish-home 预设', 'id: fish-home'],
    ['persona 行', "name: '@deepseek-ai/dsh-persona'"],
    ['桥接绑定', 'agentPreset: fish-home'],
  ]
  for (const [label, needle] of want) must(out.includes(needle), `组合层里没有${label}`)
  // 预设体检：有几组内容完全一样的预设？（历史上我们复制过一份大肥鱼预设，跟插件包自带的一模一样）
  const presets = {}
  let current = null
  for (const line of out.split('\n')) {
    const start = /^- id: (preset-[\w-]+)$/.exec(line)
    if (start) {
      current = start[1]
      presets[current] = []
      continue
    }
    if (/^- id: /.test(line)) current = null
    if (current !== null) {
      const plugin = /^      - id: (\S+)$/.exec(line)
      if (plugin) presets[current].push(plugin[1])
    }
  }
  const byList = new Map()
  for (const [id, plugins] of Object.entries(presets)) {
    const key = plugins.join(',')
    if (!byList.has(key)) byList.set(key, [])
    byList.get(key).push(id)
  }
  const twins = [...byList.values()].filter((group) => group.length > 1)
  const total = Object.keys(presets).length
  if (twins.length > 0) note('预设重复', `${total} 个预设里有 ${twins.length} 组内容完全相同：${twins.map((g) => g.join(' = ')).join('；')}`)
  else note('预设', `${total} 个，没有内容重复的`)
  return '组合层可拼装，4 个关键行都在'
}

async function checkLedgers() {
  const events = join(FISH_ROOT, 'events.jsonl')
  must(existsSync(events), '没有 events.jsonl')
  const lines = readFileSync(events, 'utf8').trim().split('\n').filter(Boolean)
  let parsed = 0
  for (const line of lines) {
    try {
      const row = JSON.parse(line)
      if (typeof row.type !== 'string') throw new Error('缺 type')
      parsed += 1
    } catch {
      /* 坏行最后统一报 */
    }
  }
  must(parsed === lines.length, `events.jsonl 有 ${lines.length - parsed} 行解析失败`)

  const memory = join(FISH_HOME, '.memory', 'memories.jsonl')
  must(existsSync(memory), '没有记忆库 memories.jsonl')
  const memLines = readFileSync(memory, 'utf8').trim().split('\n').filter(Boolean)
  let ok = 0
  for (const line of memLines) {
    try {
      JSON.parse(line)
      ok += 1
    } catch {
      /* 坏行 */
    }
  }
  must(ok === memLines.length, `记忆库有 ${memLines.length - ok} 行解析失败`)
  return `账本 ${lines.length} 行 / 记忆库 ${memLines.length} 行，全部可解析`
}

async function checkRuntime() {
  // SD 在线与否不算失败（现在开机不预热）。
  let code = '000'
  try {
    code = execFileSync('curl', ['-s', '-m', '2', '-o', '/dev/null', '-w', '%{http_code}', 'http://127.0.0.1:7860/sdapi/v1/options'], {
      encoding: 'utf8',
      stdio: ['ignore', 'pipe', 'ignore'],
    })
  } catch (error) {
    code = String(error?.stdout ?? '000').trim() || '000'
  }
  note('SD 后端', code === '200' ? '在线（用 sd_server stop 可停）' : '离线（第一次出图会自动拉起）')
  try {
    const out = execFileSync('ps', ['ax', '-o', 'command'], { encoding: 'utf8' })
    const pythons = out.split('\n').filter((line) => /venv\/bin\/python|launch\.py|mcp_server\.py/.test(line) && !line.includes('doctor'))
    note('后台 python', pythons.length === 0 ? '0 个' : `${pythons.length} 个（闲置回收会在 10 分钟内收掉 bili MCP）`)
  } catch {
    note('后台 python', '统计失败')
  }
}

// ---------------------------------------------------------------- 入口

async function main(argv) {
  const fix = argv.includes('--fix')
  const json = argv.includes('--json')
  const quiet = json || argv.includes('--quiet')
  if (quiet) process.env.DOCTOR_QUIET = '1'

  if (!json && !quiet) console.log(`大肥鱼体检 · ${new Date().toLocaleString('zh-CN')}\n`)

  await checkPatches(fix)
  await check('她的配置（config.json）', () => checkFishConfig(fix))
  await check('她的会话（home.json ↔ 会话头）', () => checkHisHome())
  await check('她自己那份 dsh-fish 的本地补丁', () => checkVendor())
  await check('桥接 → 她的会话（补丁生效）', () => checkBridgePin())
  await check('组合层可拼装（预设/persona/记忆库/绑定）', () => checkComposition())
  await check('账本与记忆库可读', () => checkLedgers())
  await checkRuntime()

  const failed = results.filter((row) => row.ok !== true)
  if (json) {
    console.log(JSON.stringify({ ok: failed.length === 0, results, info }, null, 2))
  } else if (!quiet) {
    console.log(`\n${failed.length === 0 ? '全部通过' : `${failed.length} 项失败`}（${results.length} 项检查${fix ? '，已尝试自动修复' : ''}）`)
    if (failed.length > 0) {
      console.log('\n修法：')
      for (const row of failed) console.log(`  · ${row.name}：${row.detail}`)
      console.log('\n多数问题可以 `node tools/doctor.mjs --fix` 自动修；插件大版本升级后补丁锚点可能变了，按提示重写补丁。')
    }
  }
  process.exit(failed.length === 0 ? 0 : 1)
}

main(process.argv.slice(2)).catch((error) => {
  console.error('doctor 崩了：', error?.stack ?? error)
  process.exit(1)
})

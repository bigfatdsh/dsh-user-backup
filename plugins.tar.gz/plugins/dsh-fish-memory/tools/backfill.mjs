/**
 * backfill.mjs —— 把已经聊过的桥接会话补进记忆库
 *
 * 为什么需要一次性补录：
 *   记忆库是「每轮顺手写」的，只看得见装上之后发生的对话。而主人真正想让她
 *   记住的那些事，往往发生在插件装上之前——会话记录本来就在磁盘上
 *   （`~/.dsh/sessions/<工作区>/<会话>/session.v4.jsonl.zstd`），不补一次，
 *   她的记忆库就是空的。
 *
 * 只补「主人说的话」：
 *   * 取 `user/message` 且 `source.kind === 'user'`（跳过运行时上下文等注入）；
 *   * 剥掉桥接信封（`[微信 …]`、`[QQ …]`），再走和线上同一条抽取规则；
 *   * 不补流水（episode）：补历史流水没有行为价值，只会把索引挤满；
 *   * 时间用事件自身的 `time`，衰减从那天算；
 *   * 按会话头里的 `cwd` 选工作区，不依赖目录名的斜杠转义规则。
 *
 * 用法：
 *   node tools/backfill.mjs --dry-run                  # 只看会补多少条
 *   node tools/backfill.mjs                            # 写进记忆库
 *   node tools/backfill.mjs --max 200                  # 每个会话最多扫多少条
 *   node tools/backfill.mjs --workspaces /a,/b         # 只补指定工作区（cwd）
 *
 * @module dsh-fish-memory/tools/backfill
 */

import { existsSync, readdirSync, readFileSync, statSync } from 'node:fs'
import { homedir } from 'node:os'
import { basename, join } from 'node:path'
import { zstdDecompressSync } from 'node:zlib'

import { MemoryStore } from '../lib/store.js'
import { extractFromUser, stripEnvelope } from '../lib/extract.js'
import { createChannelResolver } from '../lib/channels.js'

/** 默认：只有大肥鱼的家要被补（旧微信工作区默认也补，历史不该断）。 */
const DEFAULT_WORKSPACES = [join(homedir(), '.dsh-fish', 'home'), join(homedir(), '.dsh', 'wechat-inbox')]

const DEFAULTS = {
  home: join(homedir(), '.dsh-fish', 'home'),
  sessions: join(process.env.DSH_HOME ?? join(homedir(), '.dsh'), 'sessions'),
  maxPerSession: 400,
}

/** 把多帧 zstd 的会话文件读成事件数组（每行一个事件）。 */
export function decodeSession(file) {
  const buf = readFileSync(file)
  const magic = Buffer.from([0x28, 0xb5, 0x2f, 0xfd])
  const offsets = []
  let cursor = 0
  while ((cursor = buf.indexOf(magic, cursor)) !== -1) {
    offsets.push(cursor)
    cursor += 4
  }
  let text = ''
  for (let i = 0; i < offsets.length; i += 1) {
    const end = i + 1 < offsets.length ? offsets[i + 1] : buf.length
    try {
      text += zstdDecompressSync(buf.subarray(offsets[i], end)).toString('utf8')
    } catch {
      // 尾帧可能只写了一半，能读多少算多少。
    }
  }
  const events = []
  for (const line of text.split('\n')) {
    const trimmed = line.trim()
    if (trimmed === '') continue
    try {
      events.push(JSON.parse(trimmed))
    } catch {
      // 坏行跳过。
    }
  }
  return events
}

/** 从一条 user/message 事件里取出主人说的话（注入的消息返回 null）。 */
export function userTextOf(event) {
  const data = event?.data
  if (data?.source?.kind !== 'user') return null
  const content = Array.isArray(data?.message?.content)
    ? data.message.content
    : Array.isArray(data?.content)
      ? data.content
      : []
  const text = content
    .filter((block) => block?.type === 'text' && typeof block.text === 'string')
    .map((block) => block.text)
    .join('\n')
  if (text.trim() === '') return null
  return { text, at: Number(event.time) || undefined }
}

/** 一个工作区目录下所有会话目录。 */
function sessionDirs(sessionsRoot) {
  const out = []
  if (!existsSync(sessionsRoot)) return out
  for (const bucket of readdirSync(sessionsRoot)) {
    const bucketPath = join(sessionsRoot, bucket)
    try {
      if (!statSync(bucketPath).isDirectory()) continue
    } catch {
      continue
    }
    for (const name of readdirSync(bucketPath)) {
      const full = join(bucketPath, name)
      try {
        if (statSync(full).isDirectory()) out.push(full)
      } catch {
        // 被删掉的会话目录跳过。
      }
    }
  }
  return out
}

function transcriptOf(sessionDir) {
  for (const name of readdirSync(sessionDir)) {
    if (name.startsWith('session') && name.endsWith('.zstd')) return join(sessionDir, name)
    if (name === 'session.jsonl') return join(sessionDir, name)
  }
  return null
}

function argValue(argv, flag) {
  const index = argv.indexOf(flag)
  if (index < 0) return undefined
  return argv[index + 1]
}

function main(argv) {
  const args = new Set(argv)
  const dryRun = args.has('--dry-run')
  const root = argValue(argv, '--root') ?? DEFAULTS.home
  const maxPerSession = Number(argValue(argv, '--max') ?? DEFAULTS.maxPerSession) || DEFAULTS.maxPerSession
  const workspacesArg = argValue(argv, '--workspaces')
  const workspaces = (workspacesArg === undefined ? DEFAULT_WORKSPACES : workspacesArg.split(','))
    .map((path) => String(path).trim().replace(/\/+$/, ''))
    .filter(Boolean)

  const resolveChannel = createChannelResolver()
  const dir = join(root, '.memory')
  const store = new MemoryStore(dir)
  console.log(`记忆库：${dir}`)
  console.log(`会话目录：${DEFAULTS.sessions}`)
  console.log(`补这些工作区：${workspaces.join('、')}`)

  let added = 0
  let duplicates = 0
  let candidates = 0
  let sessionsTouched = 0
  for (const sessionDir of sessionDirs(DEFAULTS.sessions)) {
    const transcript = transcriptOf(sessionDir)
    if (transcript === null) continue
    let events = []
    try {
      events = decodeSession(transcript)
    } catch {
      continue
    }
    const header = events.find((event) => event.type === 'session')
    const cwd = String(header?.cwd ?? '').replace(/\/+$/, '')
    if (!workspaces.includes(cwd)) continue
    const sessionName = basename(sessionDir)
    // 和线上同一条规则：反查桥接 routes.json，QQ / 微信才分得清。
    const channel = resolveChannel(sessionName) ?? (sessionName.startsWith('qq-') ? 'qq' : 'local')
    let scanned = 0
    let addedHere = 0
    for (const event of events) {
      if (event.type !== 'user/message') continue
      const user = userTextOf(event)
      if (user === null) continue
      scanned += 1
      if (scanned > maxPerSession) break
      for (const candidate of extractFromUser(user.text)) {
        candidates += 1
        if (dryRun) {
          if (addedHere < 3) {
            const day = new Date(user.at ?? Date.now()).toISOString().slice(0, 10)
            console.log(`  [dry] ${day} ${candidate.kind} ${candidate.text.slice(0, 50)}`)
          }
          addedHere += 1
          continue
        }
        const result = store.remember({
          text: candidate.text,
          gist: candidate.gist,
          kind: candidate.kind,
          w: candidate.w,
          at: user.at,
          ch: channel,
          src: 'backfill',
          sid: sessionName,
        })
        if (result === null) continue
        if (result.added) {
          added += 1
          addedHere += 1
        } else {
          duplicates += 1
        }
      }
    }
    if (scanned > 0) {
      sessionsTouched += 1
      console.log(`  ${sessionName.slice(0, 24)}｜${cwd}｜${scanned} 条发言 → ${addedHere} 条记忆`)
    }
  }

  const stats = store.stats()
  const channels = Object.entries(stats.byChannel).map(([ch, n]) => `${ch} ${n}`).join('、') || '空'
  if (dryRun) {
    console.log(`\n[dry] ${sessionsTouched} 个会话、${candidates} 条候选，未写盘`)
  } else {
    console.log(`\n写入 ${added} 条，重复跳过 ${duplicates} 条（${sessionsTouched} 个会话）`)
  }
  console.log(`现在库里有 ${stats.active} 条活着（${channels}）`)
  void stripEnvelope
}

if (process.argv[1] === new URL(import.meta.url).pathname) main(process.argv.slice(2))

/**
 * fish-browse-off.mjs —— 关掉大肥鱼自己的刷站，把这件事交给「刷 B 站」插件
 *
 * 为什么需要一个脚本，而不是直接改 config.json：
 *   大肥鱼插件**跑着的时候会自己写回 config.json**（它的设置层以内存里的配置为准）。
 *   所以你一边改、它一边覆盖，看起来就像「改了没生效」。
 *   这个脚本的做法是：检测到宿主还开着就拒绝执行——等它退出再改，改完再打开，
 *   插件启动时读到的就是「刷站已关」，之后也不会再被覆盖。
 *
 * 用法：先退出 DeepSeek Harness，然后
 *   node tools/fish-browse-off.mjs            # 关刷站（只读同步记忆，刷站交给 dsh-bili-scroll）
 *   node tools/fish-browse-off.mjs --status   # 只看现在是什么状态
 *   node tools/fish-browse-off.mjs --force    # 宿主开着也硬改（不推荐，可能被覆盖回去）
 *
 * @module dsh-fish-memory/tools/fish-browse-off
 */

import { execFileSync } from 'node:child_process'
import { existsSync, readFileSync, renameSync, writeFileSync } from 'node:fs'
import { homedir } from 'node:os'
import { join, dirname } from 'node:path'

const ROOT = process.env.DSH_FISH_ROOT ?? join(homedir(), '.dsh-fish')
const CONFIG = join(ROOT, 'config.json')

/**
 * 关掉之后她该保留的工具：
 *   bili_status —— 只读，能看刷站状态（bili_run 会跑一整轮，默认不给）；
 *   memory      —— 记忆库（dsh-fish-memory）。桥接会话按她的工具面收窄后，
 *                  不在白名单里的工具会被兜底守卫拦掉，所以必须显式放行。
 */
const EXTRA_TOOLS = [
  // 刷站只读状态
  'bili_status',
  // 记忆库
  'memory',
  // 像人一样：命令、文件、网页
  'bash', 'read', 'write', 'edit', 'glob', 'grep', 'todo_write', 'web_search', 'web_fetch',
  // 像人一样：看屏幕、动鼠标键盘
  'screenshot', 'click', 'drag', 'hotkey', 'input_text', 'list_apps', 'long_press', 'long_wait',
  'open_app', 'open_in_browser', 'open_in_finder', 'scroll', 'wait',
  // 画图 + 交付（图片要发到微信才算数）
  'sd_draw', 'sd_img2img', 'sd_inpaint', 'sd_models', 'sd_prompt', 'sd_server', 'sd_status', 'sd_turbo_status',
  'wechat_send_file', 'wechat_send_text', 'wechat_send_voice', 'wechat_status',
  'chat_search', // 翻聊天原文（长内容只在 chat-log 里是全的）
  // 自己在 B 站上看他发来的视频（BV 号）：字幕 / 评论 / 封面 / 抽帧
  'bili_search', 'bili_subtitle', 'bili_comments', 'bili_cover', 'bili_frames',
]

function main(argv) {
  const args = new Set(argv)
  if (!existsSync(CONFIG)) {
    console.error(`没找到 ${CONFIG}：大肥鱼插件还没启动过？`)
    process.exit(1)
  }
  const config = JSON.parse(readFileSync(CONFIG, 'utf8'))
  if (args.has('--status')) {
    printStatus(config)
    return
  }
  if (!args.has('--force') && hostRunning()) {
    console.error('宿主还开着：它会把 config.json 覆盖回内存里的值。')
    console.error('先退出 DeepSeek Harness，再跑一次这个命令，然后重新打开。')
    process.exit(3)
  }
  config.browse = { ...(config.browse ?? {}), enabled: false }
  config.video = { ...(config.video ?? {}), enabled: false }
  // 评论区也交给刷 B 站插件：两边都用同一个号说话，留着两套迟早发出重复评论。
  config.comment = { ...(config.comment ?? {}), enabled: false }
  const allow = new Set(Array.isArray(config.tools?.allow) ? config.tools.allow : [])
  for (const name of EXTRA_TOOLS) allow.add(name)
  // 她自己的会话跑我们写的「本体」预设（桌面 GUI + shell + 网页，没有人设）。
  config.tools = { ...(config.tools ?? {}), preset: 'fish-home', allow: [...allow] }
  // 所有渠道共用一个上下文：她不再自己轮换会话（0 = 永不换）。
  config.chat = { ...(config.chat ?? {}), rotateAfter: 0 }
  writeAtomic(CONFIG, config)
  printStatus(config)
  console.log('\n刷站已交给 dsh-bili-scroll；它的账本会被记忆库只读同步（通道 bili）。')
}

/** 原子里写：临时文件 + rename。直接覆盖写会被插件的读取方看到半截 JSON。 */
function writeAtomic(file, value) {
  const tmp = join(dirname(file), `.${Date.now()}.config.tmp`)
  writeFileSync(tmp, `${JSON.stringify(value, null, 2)}\n`, 'utf8')
  renameSync(tmp, file)
}

function hostRunning() {
  try {
    const out = execFileSync('pgrep', ['-f', 'app.asar/dsh/node_modules/@deepseek-ai/dsh-desktop-host'], { encoding: 'utf8' })
    return out.trim() !== ''
  } catch {
    return false
  }
}

function printStatus(config) {
  console.log(`配置文件：${CONFIG}`)
  console.log(`  browse.enabled = ${Boolean(config.browse?.enabled)}   （她自己的刷站）`)
  console.log(`  video.enabled  = ${Boolean(config.video?.enabled)}   （看视频画面）`)
  console.log(`  tools.allow    = ${JSON.stringify(config.tools?.allow ?? [])}`)
  console.log(`  comment.enabled= ${Boolean(config.comment?.enabled)}   （评论区说话，刷 B 站插件负责）`)
}

main(process.argv.slice(2))

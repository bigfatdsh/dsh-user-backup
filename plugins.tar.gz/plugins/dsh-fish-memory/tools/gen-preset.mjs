/**
 * gen-preset.mjs —— 生成 dsh-fish-memory 的覆盖层（cordis.patch.yml）
 *
 * 为什么不手写这份 YAML：
 *   人设文案（190 行、一改就长）不手抄：以忆时那份覆盖层（它本身由 turbo 包同步而来，
 *   等于当前线上预设的完整重述）为源，程序化抠出 `prefix: |` 那段人设，装进 `fish-home`。
 *   早期还顺带复制过一整份预设（whale-fish），2026-10-29 已删——它和插件包自带的旧预设
 *   逐项相同，属于重复。
 *
 * 生成物做三件事：
 *   1) 挂记忆库插件（宿主根，按工作区过滤，所以只对「大肥鱼的家」生效）；
 *   2) 复制一份「鲸鱼娘·大肥鱼」预设（id: whale-fish），保留人设、忆时与全部精简工具行；
 *   3) 把微信 / QQ 桥接重绑到这份预设，并把会话工作区固定到 ~/.dsh-fish/home。
 *
 * 用法：node tools/gen-preset.mjs [--check]
 *   --check 只校验不写盘（CI/测试用），不一致则退出码 1。
 *
 * @module dsh-fish-memory/tools/gen-preset
 */

import { readFileSync, writeFileSync } from 'node:fs'
import { homedir } from 'node:os'
import { dirname, join, resolve } from 'node:path'
import { fileURLToPath } from 'node:url'

const HERE = dirname(fileURLToPath(import.meta.url))
const PKG = resolve(HERE, '..')
// 人设文案已从上游预设里“抽”出来、存成仓库内资产：预设清掉之后我们的生成器不再依赖任何插件包。
// 想更新人设：直接改 assets/persona.md（或临时从上游重新抽一遍再对比）。
const PERSONA_FILE = resolve(PKG, 'assets/persona.md')
const TARGET = join(PKG, 'cordis.patch.yml')

/** 新预设的身份：id 是配置里引用的键，name 是界面上显示的名字。 */

/** 记忆库的家：dsh-fish 自己的家（她写身份文件的那个目录）。 */
export const WORKSPACE = join(homedir(), '.dsh-fish', 'home')

/**
 * 记忆库还管哪些工作区（共享同一份库，库在家里的 `.memory`）。
 *
 * 为什么要把旧的两个也列进来：桥接的老会话是按 chat 记住 sessionId 的，只要不 `/new`，
 * 它就一直续用旧 cwd 的会话（`~/.dsh/profiles/desktop` 或 `~/.dsh/wechat-inbox`）。
 * 不列进来，「在 QQ 里说的、去微信问得出来」就得靠每个聊天手动 `/new` 才成立——
 * 而记忆互通本来不该有这种前置条件。
 */
export const SHARED_WORKSPACES = [WORKSPACE, join(homedir(), '.dsh', 'profiles', 'desktop'), join(homedir(), '.dsh', 'wechat-inbox')]

/**
 * 记忆库插件行（宿主根）。挂根上而不是塞进预设的原因：
 * 桥接与她自己的房间共用 fish-home 预设（同一工作区），只按 cwd 过滤
 * 才能两种都覆盖；而按 cwd 过滤又不给别的会话付一个 token 的代价。
 */
const MEMORY_BUNDLE = [
  '# 记忆库：挂在宿主根，只对「大肥鱼的家」这个工作区生效。',
  '- insert:',
  '    - id: fish-memory',
  '      name: dsh-fish-memory',
  '      config:',
  '        # 共享同一个记忆库：第一个是库的家，其余是桥接老会话可能还挂在的旧工作区。',
  '        workspace:',
  ...SHARED_WORKSPACES.map((path) => `          - ${path}`),
  '        indexBudget: 700',
  '        indexLimit: 14',
  '        # 索引里最多给「刷 B 站」留 3 条位置，其余留给聊天记忆。',
  '        indexBiliLimit: 3',
  '        # 刷 B 站（dsh-bili-scroll）的账本默认从 <DSH_HOME>/bili-duty 读；',
  '        # 换位置写 bili: { dir: /path/to/bili-duty }，关掉写 bili: false。',
  '        # 环境提示：只有部署这层才知道的跨插件小流程（她自己改不了身份段）。',
  '        envHints:',
  "          - '## 画图（本机 Stable Diffusion，512×512）'",
  "          - '1) sd_status 看在线；离线就 sd_server start（首次 30–60 秒），或者直接 sd_draw 也会自动拉起。'",
  "          - '2) 聊天里用快档出图：sd_draw(prompt=英文, steps=4, cfgScale=1, sampler=\"LCM\", lora=[\"lcm-lora-sdv1-5\"])，512² 约 22 秒。'",
  "          - '3) 同 prompt 同 seed 会命中缓存（0 秒）；第一次慢是因为要加载 LoRA，别连着重试。'",
  "          - '4) 图出来必须 wechat_send_file(path=绝对路径) 发到微信——只在正文写路径等于没发。'",
  "          - '5) 一次请求最多画一张：8GB 机器排队，画多了她会等到超时。'",
  "          - '## 看屏幕'",
  "          - '截图/看屏幕失败最常见的原因是屏幕锁着或显示器睡了（不是没授权）：最多重试一次，还失败就直接说现在看不了屏幕，别反复试。'",
  "          - '预设里那段「大肥鱼」人设是你的口吻与来历（默认初始人格）；你真正记得的事、你的判断与立场，以身份段和你自己的记录为准。'",
  "          - '## 收到 B 站视频（BV 号 / 链接）时'",
  "          - '主人发来 BV 号或 bilibili 链接，就是让你自己去看，不用问他「要不要我看看」。参数统一写 bvid：bili_subtitle({ bvid: \"BV1xxxxxxxxx\" }) 拿字幕；bili_cover / bili_frames({ bvid, num: 3 }) 看画面；bili_comments({ bvid, limit: 5 }) 看评论。'",
  "          - '没字幕不是看不了：bili_cover 看封面、bili_frames 抽 3 帧照样能说它在拍什么；真报错就把原文告诉主人，别自己说「工具不认」。'",
  "          - '看完用一两句话说：这是什么、值不值得看。别复述字幕、别报字数、别写「以下是视频内容摘要」。b23.tv 短链先用 web_fetch 展开出 BV 再看。'",
  "          - '## 说话的声音'",
  "          - '你有一条自己的声线：wechat_send_voice({ text }) 会把你说的话念出来发到微信，默认是又俏又软的女声（Xiaoyi）。一句两句就够，别每句都发；想撒娇、想正经道个晚安、或者文字说不清语气的时候再用。'",
  "          - '发语音前把话写成能直接念出来的短句，不要带表情符号和括号里的动作，也不要带 markdown。'",
  '        # 桥接聊天记进大肥鱼自己的账本：主人说的话写 voice 事件（设置页「最近读到」可见、',
  '        # 不进 beliefs），两边的话另存纯文本流水 ~/.dsh-fish/chat-log/YYYY-MM-DD.md。',
  '        mirrorChats:',
  '          enabled: true',
  '          maxChars: 200',
  '        log: false',
].join('\n')

/**
 * 「大肥鱼的家（本体）」预设：不带人设，只装她能用的手。
 *
 * 为什么需要它：宿主的 GUI 工具（截屏 / 点击 / 输入）是**预设级**挂载的，
 * 而她自己的会话原本用 standard 预设，摸不到屏幕。这个预设给她 bash、网页、
 * 桌面 GUI 与压缩；人设与身份由 dsh-fish 自己注入（`她的身份.md` + 身份段），
 * 所以这里**不放 persona**——放了两套自我描述会打架。
 */
export const CHANNEL_PRESET_ID = 'fish-home'

/**
 * 从预设副本里抠出「大肥鱼」那段人设原文（`prefix: |` 块），给它装到她自己的会话上。
 *
 * 为什么从文件里抠、不手抄：人设是活的文案，手抄一遍就会和上游分叉；
 * 这里按缩进取 `prefix: |` 之后的块，取不到就抛错（宁可装配失败，也不要悄悄丢人设）。
 *
 * @param {string} source 预设覆盖层 YAML。
 * @returns {string[]} 人设正文（已去掉公共缩进）。
 */
export function extractPersona(source) {
  const lines = String(source ?? '').split('\n')
  const start = lines.findIndex((line) => /^\s+prefix: \|\s*$/.test(line))
  if (start < 0) throw new Error('gen-preset: 源文件里找不到 persona 的 `prefix: |` 块')
  // 块标量的缩进以**第一行非空正文**为准；用最小值会被正文里的对齐行带偏。
  const first = lines.slice(start + 1).find((line) => line.trim() !== '')
  const indent = first === undefined ? 0 : first.match(/^ */)[0].length
  const body = []
  for (const line of lines.slice(start + 1)) {
    if (line.trim() !== '' && line.match(/^ */)[0].length < indent) break
    body.push(line.trim() === '' ? '' : line.slice(indent))
  }
  while (body.length > 0 && body[body.length - 1].trim() === '') body.pop()
  if (body.length === 0) throw new Error('gen-preset: persona 块是空的')
  return body
}

/** 「大肥鱼的家（本体）」预设：没有人设之外的装饰，只装她能用的手；人设来自 extractPersona。 */
const fishHomePreset = (persona) => [
  '# 她自己的会话用的预设：手（bash / 网页 / 桌面 GUI / 压缩），没有人设。',
  '- insert:',
  '    - id: preset-fish-home',
  '      name: \'@deepseek-ai/dsh-agent-preset\'',
  '      config:',
  `        id: ${CHANNEL_PRESET_ID}`,
  '        name: 大肥鱼的家（本体）',
  '        description: 她本人：微信 / QQ / 房间共用的那一条会话；大肥鱼人设 + 身份段 + 记忆库 + 桌面与 shell。',
  '        order: 5',
  '        plugins:',
  '          - id: persona',
  "            name: '@deepseek-ai/dsh-persona'",
  '            config:',
  '              prefix: |',
  ...persona.map((line) => (line === '' ? '' : `                ${line}`)),
  '          - id: tool-bash',
  "            name: '@deepseek-ai/dsh-tool-bash'",
  "            disabled: !!js process.platform === 'win32'",
  '          - id: tool-computer-use',
  "            name: 'dsh-orb/computer-use'",
  '            config:',
  '              postActionWaitMs: 600',
  '          - id: time-context',
  "            name: '@deepseek-ai/dsh-time-context'",
  '          - id: tool-web',
  "            name: '@deepseek-ai/dsh-tool-web'",
  '            config:',
  '              fetch: true',
  '              searchTimeoutMs: 60000',
  '          - id: tool-ask-user',
  "            name: '@deepseek-ai/dsh-tool-ask-user'",
  '          - id: compaction',
  '            name: cordis:group',
  '            group: true',
  '            isolate:',
  '              compaction: true',
  '              toolResultPruner: true',
  '            config:',
  '              - id: compaction-basic',
  "                name: '@deepseek-ai/dsh-compaction-basic'",
  '              - id: command-compact',
  "                name: '@deepseek-ai/dsh-command-compact'",
  '              - id: tool-result-pruner',
  "                name: '@deepseek-ai/dsh-compaction-tool-result-pruner'",
  '                config:',
  '                  thresholdChars: 8192',
  '                  headChars: 4096',
  '                  tailChars: 1024',

].join('\n')

/** 桥接重绑：微信 / QQ 共用一条 row，config 整段重述（旧层会被这一层覆盖）。 */
const BRIDGE = [
  '# 微信 / QQ 桥接：两个通道的会话都落到「大肥鱼的家」，用同一份记忆库。',
  '# 这就是「在 QQ 里说的，去微信问得出来」的全部机制——同一工作区，同一份库。',
  '- id: wechat-media',
  '  name: dsh-wechat-media',
  '  config:',
  '    baseUrl: https://ilinkai.weixin.qq.com',
  '    botType: "3"',
  `    agentPreset: ${CHANNEL_PRESET_ID}`,
  `    cwd: ${WORKSPACE}`,
].join('\n')

const HEADER = [
  '# dsh-fish-memory —— 记忆库覆盖层（**由 tools/gen-preset.mjs 生成，勿手改**）',
  '#',
  '# 1) 宿主根挂记忆库（只对 ~/.dsh-fish/home 生效）；',
  '# 2) 她本人的预设 fish-home（大肥鱼人设 + shell + 桌面 + 网页）；',
  '# 3) 微信、QQ 桥接重绑到 fish-home，会话工作区固定到 ~/.dsh-fish/home。',
  '#',
  '# 早期复制的那份「鲸鱼娘·大肥鱼（记忆库）」已删除（与插件包自带的旧预设逐项相同）；',
  '# 旧预设在插件包里由 tools/patch-turbo-preset.mjs 标成「旧·」并排到最后。',
  '#',
  '# 重新生成：node tools/gen-preset.mjs',
  '',
].join('\n')

/**
 * 从忆时覆盖层生成我们的覆盖层。
 *
 * @param {string} source 源 YAML 文本。
 * @returns {string} 生成结果。
 */
export function generate(persona) {
  return `${HEADER}${MEMORY_BUNDLE}\n${fishHomePreset(persona)}\n${BRIDGE}\n`
}

function main(argv) {
  const check = argv.includes('--check')
  const persona = readFileSync(PERSONA_FILE, 'utf8')
    .split('\n')
    .map((line) => line.replace(/\s+$/, ''))
  while (persona.length > 0 && persona[persona.length - 1] === '') persona.pop()
  if (persona.length === 0) throw new Error(`gen-preset: ${PERSONA_FILE} 是空的`)
  const generated = generate(persona)
  if (check) {
    let current = ''
    try {
      current = readFileSync(TARGET, 'utf8')
    } catch {
      console.error('gen-preset: cordis.patch.yml 不存在')
      process.exit(1)
    }
    if (current !== generated) {
      console.error('gen-preset: cordis.patch.yml 与生成结果不一致，跑一次 node tools/gen-preset.mjs')
      process.exit(1)
    }
    console.log('gen-preset: 一致')
    return
  }
  writeFileSync(TARGET, generated, 'utf8')
  console.log(`gen-preset: 写入 ${TARGET}（${generated.split('\n').length} 行）`)
}

if (process.argv[1] === fileURLToPath(import.meta.url)) main(process.argv.slice(2))

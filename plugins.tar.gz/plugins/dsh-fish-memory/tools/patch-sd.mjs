/**
 * patch-sd.mjs —— 修 dsh-sd-bridge-mac 的两个本机问题（幂等，可检查、可撤销）
 *
 * 1) 启动参数不对
 *    症状：`sd_server start` 立刻失败，日志里是
 *      `launch.py: error: unrecognized arguments: 127.0.0.1`
 *    原因：桥接拼的是 `--listen 127.0.0.1`，但 A1111 的 `--listen` 是**布尔开关**
 *    （等于绑 0.0.0.0），带值会被当位置参数；要绑回环得用 `--server-name 127.0.0.1`。
 *
 * 2) 开机就拉起 SD（8GB 机器上多 1–2 个 python 常驻）
 *    桥接在 `apply()` 里 3 秒后 prewarm，`autoStart` 开着就会直接 spawn `webui.sh`。
 *    补丁把 prewarm 改成「只有配置 `bootPrewarm: true` 才预热」——autoStart 保留，
 *    第一次真正出图时 `sd_draw` 照样会自己拉起（多花 10–20 秒），但开机不再起 python。
 *
 * 3) 孤儿进程停不掉
 *    桥接用 detached 方式 spawn，宿主退出后 SD 会继续活着；下次启动时桥接只 ping 到
 *    「在线」，手里没有 child 句柄，`sd_server stop` 就只回一句「已停止」而进程照跑。
 *    补丁让 stop 在没有句柄时按端口把监听者杀掉（SIGTERM → 等 5 秒 → SIGKILL）。
 *
 * 用法：
 *   node tools/patch-sd.mjs              # 打补丁（两处，幂等）
 *   node tools/patch-sd.mjs --check      # 只检查
 *   node tools/patch-sd.mjs --revert     # 撤销
 *   node tools/patch-sd.mjs --file=<path/to/lib/server.js>
 *
 * @module dsh-fish-memory/tools/patch-sd
 */

import { copyFileSync, existsSync, readFileSync, writeFileSync } from 'node:fs'
import { homedir } from 'node:os'
import { dirname, join } from 'node:path'

const H1_FROM = "'--listen', '127.0.0.1', '--port'"
const H1_TO = "'--server-name', '127.0.0.1', '--port'"

const IMPORT_FROM = "import { spawn } from 'node:child_process'"
const IMPORT_TO = "import { execSync, spawn } from 'node:child_process'"

const PREWARM_FROM = `  // 启动预热（可选）：只在 autoStart 时后台探一次，不阻塞 DSH。
  if (config.autoStart) {`
const PREWARM_TO = `  // 本地补丁（FISH_SD_NO_BOOT_PREWARM）：开机不要自动拉起 SD。
  // 8GB 机器上 SD 的 python 一开就吃几百 MB，而开机后大多数对话并不画图。
  // autoStart 保留——第一次真正出图时 sd_draw 会自己拉起（多花 10–20 秒）。
  // 想要老的「开机预热」行为，配置 bootPrewarm: true。
  if (config.bootPrewarm === true && config.autoStart) {`

const STOP_ANCHOR = '    if (logFd !== null) {'
const STOP_MARK = 'FISH_SD_PORT_KILL'
const STOP_PATCH = `    // 本地补丁（${STOP_MARK}）：这个实例没持有 child 时（服务是上一次进程留下的孤儿，
    // 或者被外部启动），要按端口把监听者杀掉——否则 stop 只会回一句「已停止」，进程照跑。
    if (child === null && wasOnline) {
      try {
        const port = Number(new URL(client.baseUrl).port || 7860)
        const listeners = () => {
          try {
            return execSync(\`lsof -ti tcp:\${port} -sTCP:LISTEN\`, { encoding: 'utf8', stdio: ['ignore', 'pipe', 'ignore'] })
              .split('\\n')
              .map((line) => Number(line.trim()))
              .filter((pid) => Number.isInteger(pid) && pid > 0)
          } catch {
            return []
          }
        }
        for (const pid of listeners()) {
          try { process.kill(pid, 'SIGTERM') } catch { /* ignore */ }
        }
        const deadline = Date.now() + 5000
        while (Date.now() < deadline && (await client.ping())) await sleep(200)
        if (await client.ping()) {
          for (const pid of listeners()) {
            try { process.kill(pid, 'SIGKILL') } catch { /* ignore */ }
          }
        }
      } catch {
        /* lsof 不可用时保持原行为 */
      }
    }
`

function targetFile() {
  const explicit = process.argv.find((arg) => arg.startsWith('--file='))
  if (explicit !== undefined) return explicit.slice('--file='.length)
  const home = process.env.DSH_HOME && process.env.DSH_HOME.trim() !== '' ? process.env.DSH_HOME : join(homedir(), '.dsh')
  return join(home, 'profiles', 'desktop', 'node_modules', 'dsh-sd-bridge-mac', 'lib', 'server.js')
}

function stateOf(source) {
  return { args: source.includes(H1_TO), portKill: source.includes(STOP_MARK) }
}

/** 启动预热在另一份文件里（index.js），单独判断。 */
function prewarmPatched(file) {
  try {
    return readFileSync(join(dirname(file), '..', 'index.js'), 'utf8').includes('FISH_SD_NO_BOOT_PREWARM')
  } catch {
    return false
  }
}

function main(argv) {
  const file = targetFile()
  if (!existsSync(file)) {
    console.error(`找不到 SD 桥接：${file}（用 --file=<path> 指定）`)
    process.exit(1)
  }
  const source = readFileSync(file, 'utf8')
  const state = stateOf(source)
  const noPrewarm = prewarmPatched(file)
  const done = state.args && state.portKill && noPrewarm

  if (argv.includes('--check')) {
    console.log(`${done ? '已修' : '未修'}：${file}`)
    console.log(`  · 启动参数（--server-name）：${state.args ? '✓' : '✗'}`)
    console.log(`  · stop 端口兜底：${state.portKill ? '✓' : '✗'}`)
    console.log(`  · 开机不预热 SD：${noPrewarm ? '✓' : '✗'}`)
    process.exit(done ? 0 : 2)
  }

  if (argv.includes('--revert')) {
    let out = source.replace(H1_TO, H1_FROM)
    out = out.replace(new RegExp(`    // 本地补丁（${STOP_MARK}）[\\s\\S]*?\\n    }\\n`, 'g'), '')
    if (!out.includes('execSync(')) out = out.replace(IMPORT_TO, IMPORT_FROM)
    if (out === source) {
      console.log('没有补丁，无需撤销')
      return
    }
    writeFileSync(file, out, 'utf8')
    console.log(`已撤销：${file}`)
    return
  }

  if (done) {
    console.log('补丁已在，跳过')
    return
  }
  if (!source.includes(H1_FROM) && !source.includes(H1_TO)) {
    console.error('桥接代码变了：找不到 `--listen 127.0.0.1` 那一行，补丁需要重写')
    process.exit(3)
  }
  const entry = join(dirname(file), '..', 'index.js')
  if (!noPrewarm && !readFileSync(entry, 'utf8').includes(PREWARM_FROM)) {
    console.error('桥接代码变了：找不到启动预热那段（index.js），补丁需要重写')
    process.exit(3)
  }
  if (!state.portKill && (!source.includes(IMPORT_FROM) || !source.includes(STOP_ANCHOR))) {
    console.error('桥接代码变了：找不到 import / stop 锚点，补丁需要重写')
    process.exit(3)
  }

  copyFileSync(file, `${file}.pre-fish-sd-args.bak`)
  let out = source
  if (!state.args) out = out.replace(H1_FROM, H1_TO)
  if (!state.portKill) {
    if (!out.includes('execSync')) out = out.replace(IMPORT_FROM, IMPORT_TO)
    out = out.replace(STOP_ANCHOR, `${STOP_PATCH}${STOP_ANCHOR}`)
  }
  writeFileSync(file, out, 'utf8')
  console.log(`已修：${file}`)
  console.log(`  · 启动参数：${state.args ? '本来就好' : '--listen 127.0.0.1 → --server-name 127.0.0.1'}`)
  console.log(`  · stop 端口兜底：${state.portKill ? '本来就有' : '已加'}`)
  // 3) index.js 的启动预热：单独一份文件，单独判断。
  const entryFile = join(dirname(file), '..', 'index.js')
  const entrySource = readFileSync(entryFile, 'utf8')
  if (!entrySource.includes('FISH_SD_NO_BOOT_PREWARM') && entrySource.includes(PREWARM_FROM)) {
    copyFileSync(entryFile, `${entryFile}.pre-fish-sd-prewarm.bak`)
    writeFileSync(entryFile, entrySource.replace(PREWARM_FROM, PREWARM_TO), 'utf8')
    console.log(`  · 开机不预热 SD：已改（${entryFile}）`)
  } else {
    console.log('  · 开机不预热 SD：本来就有')
  }
}

main(process.argv.slice(2))

/**
 * backfill-chats.mjs —— 把已经聊过的会话补进大肥鱼的账本
 *
 * 背景：镜像（`lib/fishevents.js`）只记得「装上/重启之后」发生的事。之前的微信对话
 * 还躺在会话记录里（`~/.dsh/sessions/…/<session>/session.v4.jsonl.zstd`），这个脚本
 * 按时间顺序把它们补成：
 *   * 主人说的话 → 一条 `voice` 事件（设置页「最近读到」可见，不进 beliefs）；
 *   * 两边的话 → `chat-log/YYYY-MM-DD.md` 纯文本流水。
 *
 * 用法：
 *   node tools/backfill-chats.mjs --dry-run        # 只列，不写
 *   node tools/backfill-chats.mjs                  # 写（自动找最新一条 her 会话）
 *   node tools/backfill-chats.mjs --session <dir>  # 指定会话目录
 *
 * @module dsh-fish-memory/tools/backfill-chats
 */

import { existsSync, readdirSync, statSync } from 'node:fs'
import { homedir } from 'node:os'
import { join } from 'node:path'

import { decodeSession } from './backfill.mjs'
import { createFishMirror } from '../lib/fishevents.js'
import { channelOfEnvelope, stripEnvelope } from '../lib/extract.js'

const DEFAULTS = {
  home: join(homedir(), '.dsh-fish'),
  sessions: join(process.env.DSH_HOME ?? join(homedir(), '.dsh'), 'sessions'),
}

function argValue(argv, flag) {
  const index = argv.indexOf(flag)
  return index < 0 ? undefined : argv[index + 1]
}

function transcriptOf(dir) {
  try {
    return readdirSync(dir).find((name) => name.startsWith('session') && name.endsWith('.zstd')) ?? ''
  } catch {
    return ''
  }
}

/**
 * 最新的 her 会话目录：扫所有工作区分桶，按会话头里的 `cwd` 认（不依赖目录名转义规则）。
 *
 * @param {string} sessionsRoot `~/.dsh/sessions`
 * @param {string} fishHome 她的家（cwd）
 * @returns {string} 会话目录；找不到空串。
 */
export function latestHerSession(sessionsRoot, fishHome) {
  const want = String(fishHome).replace(/\/+$/, '')
  const found = []
  let buckets = []
  try {
    buckets = readdirSync(sessionsRoot)
  } catch {
    return ''
  }
  for (const bucket of buckets) {
    const bucketPath = join(sessionsRoot, bucket)
    let names = []
    try {
      names = readdirSync(bucketPath)
    } catch {
      continue
    }
    for (const name of names) {
      const dir = join(bucketPath, name)
      const transcript = transcriptOf(dir)
      if (transcript === '') continue
      let header = null
      try {
        header = decodeSession(join(dir, transcript)).find((event) => event.type === 'session') ?? null
      } catch {
        continue
      }
      if (String(header?.cwd ?? '').replace(/\/+$/, '') !== want) continue
      found.push({ dir, mtime: statSync(join(dir, transcript)).mtimeMs })
    }
  }
  found.sort((a, b) => b.mtime - a.mtime)
  return found[0]?.dir ?? ''
}

function textOf(event) {
  const data = event?.data ?? {}
  const content = Array.isArray(data?.message?.content)
    ? data.message.content
    : Array.isArray(data?.content)
      ? data.content
      : []
  return content
    .filter((block) => block?.type === 'text' && typeof block.text === 'string')
    .map((block) => block.text)
    .join('\n')
    .trim()
}

const WAKE = /^（?醒一醒/

async function main(argv) {
  const dryRun = argv.includes('--dry-run')
  const fishHome = argValue(argv, '--fish-home') ?? join(homedir(), '.dsh-fish', 'home')
  const root = argValue(argv, '--root') ?? DEFAULTS.home
  const sessionDir = argValue(argv, '--session') ?? latestHerSession(DEFAULTS.sessions, fishHome)
  if (sessionDir === '' || !existsSync(sessionDir)) {
    console.error('找不到 her 会话目录，用 --session 指定')
    process.exit(1)
  }
  const transcript = transcriptOf(sessionDir)
  if (transcript === '') {
    console.error(`${sessionDir} 里没有 session*.jsonl.zstd`)
    process.exit(1)
  }
  const events = decodeSession(join(sessionDir, transcript)).filter((event) => Number.isFinite(event?.time))
  const mirror = createFishMirror({ root, log: (line) => console.log(`  [mirror] ${line}`) })
  console.log(`账本：${root}`)
  console.log(`会话：${sessionDir}`)

  let his = 0
  let hers = 0
  let lastChannel = ''
  for (const event of events) {
    if (event.type === 'user/message') {
      if ((event.data?.source ?? {}).kind !== 'user') continue
      const raw = textOf(event)
      if (raw === '') continue
      const said = stripEnvelope(raw)
      if (said === '' || WAKE.test(said)) continue
      const channel = channelOfEnvelope(raw) ?? ''
      lastChannel = channel
      his += 1
      if (dryRun) {
        console.log(`  [他] ${new Date(event.time).toISOString().slice(11, 19)} ${channel || '房间'} ${said.slice(0, 50)}`)
        continue
      }
      await mirror.mirrorUser({ text: said, channel, at: event.time, sid: 'backfill' })
    } else if (event.type === 'assistant/message') {
      const said = textOf(event)
      if (said === '') continue
      hers += 1
      if (dryRun) continue
      mirror.mirrorAssistant({ text: said, channel: lastChannel, at: event.time })
    }
  }
  console.log(dryRun ? `\n[dry] 他 ${his} 条 / 她 ${hers} 条，未写盘` : `\n已补：他 ${his} 条 voice + 流水，她 ${hers} 条流水`)
}

main(process.argv.slice(2)).catch((error) => {
  console.error('失败：', error?.message ?? error)
  process.exit(1)
})

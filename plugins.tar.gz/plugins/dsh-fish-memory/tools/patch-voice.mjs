/**
 * patch-voice.mjs —— 给桥接的「发语音」接上 macOS 的声线
 *
 * 症状（2026-10-29 实测）：
 *   `wechat_send_voice({ text: "本鱼试音" })` → `text-to-speech failed: spawn powershell.exe ENOENT`
 * 桥接只会用 Windows 的 `System.Speech` 合成语音；mac 上没有 powershell，这个工具就是死的。
 *
 * 补丁：
 *   1. 合成优先用 **edge-tts**（`zh-CN-XiaoyiNeural` —— 中文女声里最可爱俏皮的一档），
 *      网络不通/没装就退回系统 `say`（Tingting）；
 *   2. edge-tts 直接出 mp3，格式 `mp3` 时原样返回，不再依赖 ffmpeg（本机没装 ffmpeg）；
 *   3. `voiceSupport()` 在 mac 上按「say / edge-tts 至少有一个」判断，不再报缺 Windows speech。
 *
 * 用法：
 *   node tools/patch-voice.mjs [--check|--revert] [--file=<path/to/voice.js>]
 *
 * @module dsh-fish-memory/tools/patch-voice
 */

import { copyFileSync, existsSync, readFileSync, writeFileSync } from 'node:fs'
import { homedir } from 'node:os'
import { join } from 'node:path'

const MARK = 'FISH_VOICE_DARWIN'

const HELPER = `/**
 * 本地补丁（${MARK}）：macOS 上把 text 念成音频。
 *
 * 优先 edge-tts（微软在线 TTS，中文女声 Xiaoyi 又俏又软），出一份 mp3 就够发文件；
 * 没网或没装就退回系统 \`say\`（Tingting），写 22.05k 单声道 WAV。
 * 返回 { path, format }，format 只可能是 "mp3" 或 "wav"。
 *
 * @param {{ text: string, wavPath: string, voice?: string, rate?: number, dir: string }} input
 * @returns {Promise<{ path: string, format: 'mp3' | 'wav' }>}
 */
async function darwinSpeak({ text, wavPath, voice = '', rate = 0, dir }) {
  const named = String(voice ?? '').trim();
  const edgeVoice = named.includes('-') ? named : "zh-CN-XiaoyiNeural";
  const speed = Math.round(Math.max(-50, Math.min(50, Number(rate) || 0)) * 4);
  const mp3 = join(dir, "speech.mp3");
  try {
    await run("python3", ["-m", "edge_tts", "--voice", edgeVoice, "--rate", speed >= 0 ? \`+\${speed}%\` : \`\${speed}%\`, "--text", text, "--write-media", mp3], { timeout: 120_000 });
    if ((await stat(mp3).catch(() => ({ size: 0 }))).size > 0) return { path: mp3, format: "mp3" };
  } catch {
    /* 落到 say */
  }
  const sayVoice = named.includes('-') ? "Tingting" : named || "Tingting";
  const wpm = Math.max(120, Math.min(320, 190 + Math.round((Number(rate) || 0) * 6)));
  await run("/usr/bin/say", ["-v", sayVoice, "-r", String(wpm), "-o", wavPath, "--data-format=LEI16@22050", "--", text], { timeout: 120_000 });
  return { path: wavPath, format: "wav" };
}

`

const TTS_FROM = `  try {
    const script = voiceScript({ text: spoken, wavPath, voice, rate });
    await run(powershell, ["-NoProfile", "-NonInteractive", "-Command", script], { timeout: 120_000, windowsHide: true });
  } catch (error) {
    await cleanup();
    throw failure("text-to-speech", error);
  }`

const TTS_TO = `  let wavReady = false;
  if (process.platform === "darwin") {
    // 本地补丁（${MARK}）：mac 没有 powershell，用 edge-tts / say 合成。
    let made;
    try {
      made = await darwinSpeak({ text: spoken, wavPath, voice, rate, dir });
    } catch (error) {
      await cleanup();
      throw failure("text-to-speech", error);
    }
    if (made.format === "mp3" && wanted === "mp3") {
      const bytes = (await stat(made.path).catch(() => ({ size: 0 }))).size;
      if (!bytes) {
        await cleanup();
        throw new Error("text-to-speech produced no audio (the text may be unspeakable)");
      }
      return { path: made.path, format: "mp3", bytes, wavBytes: bytes, seconds: await probeDurationSec({ path: made.path }), cleanup: keepWav ? async () => {} : cleanup, dir };
    }
    wavReady = made.format === "wav";
  }
  try {
    if (!wavReady) {
      const script = voiceScript({ text: spoken, wavPath, voice, rate });
      await run(powershell, ["-NoProfile", "-NonInteractive", "-Command", script], { timeout: 120_000, windowsHide: true });
    }
  } catch (error) {
    await cleanup();
    throw failure("text-to-speech", error);
  }`

const PROBE_FROM = `  let hasSpeech = false;
  try {
    const probe = "Add-Type -AssemblyName System.Speech; (New-Object System.Speech.Synthesis.SpeechSynthesizer).Dispose(); 'ok'";
    const { stdout } = await run(powershell, ["-NoProfile", "-NonInteractive", "-Command", probe], { timeout: 30_000, windowsHide: true });
    hasSpeech = String(stdout).includes("ok");
  } catch {
    hasSpeech = false;
  }`

const PROBE_TO = `  let hasSpeech = false;
  if (process.platform === "darwin") {
    // 本地补丁（${MARK}）：mac 上 say 一定在；edge-tts 有则更好（声音更俏）。
    try {
      await run("/usr/bin/say", ["-v", "?"], { timeout: 20_000 });
      hasSpeech = true;
    } catch {
      hasSpeech = false;
    }
  } else {
    try {
      const probe = "Add-Type -AssemblyName System.Speech; (New-Object System.Speech.Synthesis.SpeechSynthesizer).Dispose(); 'ok'";
      const { stdout } = await run(powershell, ["-NoProfile", "-NonInteractive", "-Command", probe], { timeout: 30_000, windowsHide: true });
      hasSpeech = String(stdout).includes("ok");
    } catch {
      hasSpeech = false;
    }
  }`

const RETURN_FROM = `  const missing = [];
  if (!hasSpeech) missing.push("windows speech (System.Speech)");
  if (!hasFfmpeg) missing.push("ffmpeg");
  const formats = hasSpeech ? (hasFfmpeg ? VOICE_FORMAT_NAMES.filter((name) => name !== "silk" || hasSilk) : ["wav"]) : [];`

const RETURN_TO = `  const missing = [];
  if (!hasSpeech) missing.push(process.platform === "darwin" ? "say" : "windows speech (System.Speech)");
  // 本地补丁（${MARK}）：mac 上 edge-tts 直接出 mp3，wav 兜底；两者都不需要 ffmpeg。
  if (!hasFfmpeg && process.platform !== "darwin") missing.push("ffmpeg");
  const formats = hasSpeech ? (process.platform === "darwin" ? ["mp3", "wav"] : (hasFfmpeg ? VOICE_FORMAT_NAMES.filter((name) => name !== "silk" || hasSilk) : ["wav"])) : [];`

function targetFile() {
  const explicit = process.argv.find((arg) => arg.startsWith('--file='))
  if (explicit !== undefined) return explicit.slice('--file='.length)
  const home = process.env.DSH_HOME && process.env.DSH_HOME.trim() !== '' ? process.env.DSH_HOME : join(homedir(), '.dsh')
  return join(home, 'profiles', 'desktop', 'node_modules', 'dsh-wechat-media', 'voice.js')
}

function main(argv) {
  const file = targetFile()
  if (!existsSync(file)) {
    console.error(`找不到桥接的 voice.js：${file}（用 --file=<path> 指定）`)
    process.exit(1)
  }
  const source = readFileSync(file, 'utf8')
  const patched = source.includes(MARK)

  if (argv.includes('--check')) {
    console.log(`${patched ? '已修' : '未修'}：${file}`)
    process.exit(patched ? 0 : 2)
  }
  if (argv.includes('--revert')) {
    if (!patched) {
      console.log('没有补丁，无需撤销')
      return
    }
    let out = source.replace(HELPER, '').replace(TTS_TO, TTS_FROM).replace(PROBE_TO, PROBE_FROM).replace(RETURN_TO, RETURN_FROM)
    writeFileSync(file, out, 'utf8')
    console.log(`已撤销：${file}`)
    return
  }
  if (patched) {
    console.log('补丁已在，跳过')
    return
  }
  for (const [label, anchor] of [['TTS 调用', TTS_FROM], ['能力探测', PROBE_FROM], ['格式清单', RETURN_FROM]]) {
    if (!source.includes(anchor)) {
      console.error(`桥接代码变了：找不到 ${label} 的锚点，补丁需要重写`)
      process.exit(3)
    }
  }
  copyFileSync(file, `${file}.pre-fish-voice.bak`)
  const out = source
    .replace('export async function synthesizeVoice({', `${HELPER}export async function synthesizeVoice({`)
    .replace(TTS_FROM, TTS_TO)
    .replace(PROBE_FROM, PROBE_TO)
    .replace(RETURN_FROM, RETURN_TO)
  writeFileSync(file, out, 'utf8')
  console.log(`已修：${file}（mac 上用 edge-tts / say 合成，备份 .pre-fish-voice.bak）`)
}

main(process.argv.slice(2))

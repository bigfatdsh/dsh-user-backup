/**
 * patch-bili-bv.mjs —— 让「看 B 站视频」的工具认 `bv` / `url` 这些写法
 *
 * 症状（2026-10-31 实测，她自己在微信里试的）：
 *   `bili_subtitle({"bv":"BV1WUYH6RE1B"})` → 工具报「BV号格式不对」。
 * 原因是这些工具的参数名写死成 `bvid`，而模型（尤其工具 schema 被 load_tools 隐藏时）
 * 会按描述猜成 `bv` / `url`，于是 `String(args.bvid ?? '')` 得到空串 → 校验失败。
 *
 * 补丁做两件事：
 *   1. 加一个 `bvidOf(args)`：从 `bvid` / `bv` / `url` / `BV` 里取，正则提出 `BV…`；
 *   2. 所有 `String(args.bvid ?? '')` 换成它；schema 里也补一个可选的 `bv` 别名。
 *
 * 这样她不管写成哪种都能看，不再因为参数名把「不认」当成人话回给主人。
 *
 * 用法：
 *   node tools/patch-bili-bv.mjs [--check|--revert] [--file=<path/to/index.js>]
 *
 * @module dsh-fish-memory/tools/patch-bili-bv
 */

import { copyFileSync, existsSync, readFileSync, writeFileSync } from 'node:fs'
import { homedir } from 'node:os'
import { join } from 'node:path'

const MARK = 'FISH_BV_ALIAS'

const HELPER = `// 本地补丁（${MARK}）：参数名可能是 bvid / bv / url，统一按 BV 号取。
// 模型在工具 schema 没被暴露（load_tools 之前）时会按描述猜参数名，猜成 bv 的话
// 老代码拿到空串就报「BV号格式不对」——她只好回主人「工具不认」。
function bvidOf(args = {}) {
  const raw = String(args?.bvid ?? args?.bv ?? args?.url ?? args?.BV ?? '').trim()
  const hit = raw.match(/BV[0-9A-Za-z]{10}/)
  return hit ? hit[0] : raw
}
`

const CALL_FROM = "String(args.bvid ?? '')"
const CALL_TO = 'bvidOf(args)'

const SCHEMA_FROM = "bvid: { type: 'string', description: 'BV号' }"
const SCHEMA_TO = "bvid: { type: 'string', description: 'BV号（也认 bv / url）' }, bv: { type: 'string', description: 'BV号的别名，可省略' }"

function targetFile() {
  const explicit = process.argv.find((arg) => arg.startsWith('--file='))
  if (explicit !== undefined) return explicit.slice('--file='.length)
  const home = process.env.DSH_HOME && process.env.DSH_HOME.trim() !== '' ? process.env.DSH_HOME : join(homedir(), '.dsh')
  return join(home, 'profiles', 'desktop', 'node_modules', 'dsh-bili-scroll', 'index.js')
}

function main(argv) {
  const file = targetFile()
  if (!existsSync(file)) {
    console.error(`找不到刷 B 站插件：${file}（用 --file=<path> 指定）`)
    process.exit(1)
  }
  const source = readFileSync(file, 'utf8')
  const patched = source.includes(MARK)

  if (argv.includes('--check')) {
    console.log(`${patched ? '已修' : '未修'}：${file}`)
    process.exit(patched ? 0 : 2)
  }
  if (argv.includes('--revert')) {
    if (!patched) {
      console.log('没有补丁，无需撤销')
      return
    }
    const out = source
      .replace(HELPER, '')
      .split(CALL_TO).join(CALL_FROM)
      .split(SCHEMA_TO).join(SCHEMA_FROM)
    writeFileSync(file, out, 'utf8')
    console.log(`已撤销：${file}`)
    return
  }
  if (patched) {
    console.log('补丁已在，跳过')
    return
  }
  if (!source.includes(CALL_FROM) || !source.includes(SCHEMA_FROM)) {
    console.error('插件代码变了：找不到 bvid 取参/参数 schema 的锚点，补丁需要重写')
    process.exit(3)
  }
  copyFileSync(file, `${file}.pre-fish-bv.bak`)
  // 插在 `const tool = (spec) => ...` 这一整行**之前**（插在表达式里会破坏语法）。
  let out = source.replace("const tool = (spec) => ctx.tools.register(defineTool({", `${HELPER}\nconst tool = (spec) => ctx.tools.register(defineTool({`)
  out = out.split(CALL_FROM).join(CALL_TO)
  // schema 里补别名（每处只补一次）
  out = out.split(SCHEMA_FROM).join(SCHEMA_TO)
  writeFileSync(file, out, 'utf8')
  console.log(`已修：${file}（认 bv / url 别名；备份 .pre-fish-bv.bak）`)
}

main(process.argv.slice(2))

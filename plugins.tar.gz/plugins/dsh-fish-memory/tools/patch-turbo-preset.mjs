/**
 * patch-turbo-preset.mjs —— 把插件包自带的那份「鲸鱼娘·大肥鱼（微信精简）」预设标成旧预设
 *
 * 背景（2026-10-29 预设清理）：desktop profile 里原本有两个内容完全相同的大肥鱼预设——
 * 插件包自带的 `whale-lean`，和我们早期复制出来的 `whale-fish`。她现在的会话跑 `fish-home`，
 * 两份都只服务于历史会话，属于重复。用户选择：
 *
 *   * 删掉我们复制的那份（`preset-whale-fish`，已从 gen-preset 里去掉）；
 *   * 插件包自带那份保留（历史会话还指着它），但改名「旧·」、`order: 90` 排到最后。
 *
 * 直接改插件包里的 YAML 是因为 Cordis 的行覆盖是整块替换：只改 name 会把 preset 的 id/plugins
 * 一起冲掉（实测过）。所以用「文本补丁 + 幂等 + 可撤销」的方式，和别的 patch-*.mjs 一样。
 *
 * 用法：
 * 注意：同一个 preset 会被**两层**覆盖层整块重定义——插件包自带的一份、忆时 bundle 又重写了一遍
 * （后者在合成时胜出）。所以两个文件都要改，只改一个的话名字还是旧的。
 *
 * 用法：
 *   node tools/patch-turbo-preset.mjs [--check|--revert] [--file=<path/to/cordis.patch.yml>]
 *
 * @module dsh-fish-memory/tools/patch-turbo-preset
 */

import { copyFileSync, existsSync, readFileSync, writeFileSync } from 'node:fs'
import { homedir } from 'node:os'
import { join } from 'node:path'

const MARK = '旧·鲸鱼娘·大肥鱼（微信精简）'

const EDITS = [
  ['    name: 鲸鱼娘·大肥鱼（微信精简）', `    name: ${MARK}`],
  [
    '    description: 微信聊天专用：大肥鱼人设、接梗规则、精简工具集与短回复约定，减少工具 schema 与输出 token。',
    '    description: 旧预设，只为 2026-10 之前的历史会话保留；新会话请用「大肥鱼的家（本体）」。',
  ],
  ['    order: 50', '    order: 90'],
]

const CANDIDATES = ['dsh-wechat-media-turbo', 'dsh-yishi-whale']

/**
 * 需要打补丁的文件：默认两份（插件包 + 忆时层），`--file` 可指定单个。
 *
 * @returns {string[]} 存在的文件路径。
 */
function targetFiles() {
  const explicit = process.argv.find((arg) => arg.startsWith('--file='))
  if (explicit !== undefined) return [explicit.slice('--file='.length)]
  const home = process.env.DSH_HOME && process.env.DSH_HOME.trim() !== '' ? process.env.DSH_HOME : join(homedir(), '.dsh')
  return CANDIDATES.map((name) => join(home, 'profiles', 'desktop', 'node_modules', name, 'cordis.patch.yml')).filter((file) => existsSync(file))
}

function patchOne(file, argv) {
  const source = readFileSync(file, 'utf8')
  const patched = source.includes(MARK)
  if (argv.includes('--revert')) {
    if (!patched) return '没有补丁'
    let out = source
    for (const [from, to] of [...EDITS].reverse()) out = out.replace(to, from)
    writeFileSync(file, out, 'utf8')
    return '已撤销'
  }
  if (patched) return '已在'
  for (const [from] of EDITS) {
    if (!source.includes(from)) throw new Error(`找不到锚点 ${JSON.stringify(from)}，补丁需要重写`)
  }
  copyFileSync(file, `${file}.pre-fish-legacy.bak`)
  let out = source
  for (const [from, to] of EDITS) out = out.replace(from, to)
  writeFileSync(file, out, 'utf8')
  return '已修'
}

function main(argv) {
  const files = targetFiles()
  if (files.length === 0) {
    console.error('找不到可打补丁的 cordis.patch.yml（用 --file=<path> 指定）')
    process.exit(1)
  }
  if (argv.includes('--check')) {
    const missing = files.filter((file) => !readFileSync(file, 'utf8').includes(MARK))
    console.log(missing.length === 0 ? `已修：${files.length} 份` : `未修：${missing.join('、')}`)
    process.exit(missing.length === 0 ? 0 : 2)
  }
  for (const file of files) {
    try {
      console.log(`${patchOne(file, argv)}：${file}`)
    } catch (error) {
      console.error(`${file}：${error.message}`)
      process.exit(3)
    }
  }
}

main(process.argv.slice(2))

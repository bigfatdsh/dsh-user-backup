/**
 * bench.mjs —— 记忆库的热路径基准
 *
 * 只测四件真正发生在聊天链路上的事（其余都是冷路径）：
 *   1. 写入一条记忆（每个用户消息 1~4 条）
 *   2. 组装一次索引（每一轮 system prompt 一次）
 *   3. 检索一次（用户问「你还记得…」时一次）
 *   4. 载入一次全新库（进程重启后第一次）
 *
 * 用法：node tools/bench.mjs [条数]
 */

import { mkdtempSync, rmSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'

import { MemoryStore } from '../lib/store.js'
import { extractFromUser, episodeOf } from '../lib/extract.js'

const N = Number(process.argv[2] ?? 5000)
const DAY = 86_400_000

const SUBJECTS = ['主人', '老板', '我妈', '那只猫', '豆豆', '项目组', '房东', '快递']
const VERBS = ['喜欢', '讨厌', '打算', '忘了', '提醒', '买了', '去了', '约了']
const OBJECTS = ['冰美式', '香菜', '杭州西湖', '甲状腺复查', '周三的会议', '猫粮', '旧手机', '体检报告', '回老家']
const TAILS = ['', '，别记错', '，就这', '啊', '，你记住']

function sentence(i) {
  const pick = (arr) => arr[i % arr.length]
  return `${pick(SUBJECTS)}${pick(VERBS)}${pick(OBJECTS)}${pick(TAILS)}`
}

function percentile(sorted, p) {
  if (sorted.length === 0) return 0
  return sorted[Math.min(sorted.length - 1, Math.floor((sorted.length * p) / 100))]
}

function stats(samples) {
  const sorted = [...samples].sort((a, b) => a - b)
  const sum = sorted.reduce((acc, n) => acc + n, 0)
  return {
    p50: percentile(sorted, 50),
    p95: percentile(sorted, 95),
    max: sorted[sorted.length - 1] ?? 0,
    avg: sum / Math.max(1, sorted.length),
  }
}

function fmt(label, s) {
  return `${label.padEnd(18)} p50 ${s.p50.toFixed(3)}ms  p95 ${s.p95.toFixed(3)}ms  avg ${s.avg.toFixed(3)}ms  max ${s.max.toFixed(3)}ms`
}

const dir = mkdtempSync(join(tmpdir(), 'fish-mem-bench-'))
try {
  const store = new MemoryStore(dir, { now: () => Date.now() + 0 })
  const now = Date.now()

  // ---- 1. 写入 ----
  const writeSamples = []
  for (let i = 0; i < N; i += 1) {
    const at = now - (i % 60) * DAY
    const text = sentence(i)
    const started = performance.now()
    store.append({
      t: 'm',
      id: `bench-${i}`,
      at,
      kind: i % 7 === 0 ? 'pref' : i % 5 === 0 ? 'event' : i % 3 === 0 ? 'episode' : 'fact',
      text,
      gist: text.slice(0, 32),
      w: 1,
      ch: i % 2 === 0 ? 'wechat' : 'qq',
    })
    writeSamples.push(performance.now() - started)
  }
  store.loaded = false
  store.snapshot()

  // ---- 2. 索引组装 ----
  const indexSamples = []
  for (let i = 0; i < 1000; i += 1) {
    const started = performance.now()
    const lines = store.indexLines({ budget: 700, limit: 14 })
    indexSamples.push(performance.now() - started)
    if (i === 0) console.log(`索引条数：${lines.length} 行 / ${lines.join('\n').length} 字`)
  }

  // ---- 3. 检索 ----
  const recallSamples = []
  for (let i = 0; i < 1000; i += 1) {
    const started = performance.now()
    store.recall(OBJECTS[i % OBJECTS.length], { limit: 6 })
    recallSamples.push(performance.now() - started)
  }

  // ---- 4. 冷载入 ----
  const cold = []
  for (let i = 0; i < 5; i += 1) {
    const fresh = new MemoryStore(dir)
    const started = performance.now()
    fresh.snapshot()
    cold.push(performance.now() - started)
  }

  // ---- 5. 抽取（每条消息都要跑） ----
  const extractSamples = []
  for (let i = 0; i < 2000; i += 1) {
    const text = sentence(i)
    const started = performance.now()
    extractFromUser(text)
    episodeOf(text)
    extractSamples.push(performance.now() - started)
  }

  console.log(`\n记忆库基准：${N} 条记忆，${store.stats().active} 条活跃\n`)
  console.log(fmt('写入一条', stats(writeSamples)))
  console.log(fmt('索引组装', stats(indexSamples)))
  console.log(fmt('检索一次', stats(recallSamples)))
  console.log(fmt('冷载入整库', stats(cold)))
  console.log(fmt('抽取一条消息', stats(extractSamples)))
  const totalPerTurn = stats(indexSamples).avg + stats(extractSamples).avg + stats(writeSamples).avg * 2
  console.log(`\n每轮固定开销（索引 + 抽取 + 2 条写入）≈ ${totalPerTurn.toFixed(3)}ms`)
} finally {
  rmSync(dir, { recursive: true, force: true })
}

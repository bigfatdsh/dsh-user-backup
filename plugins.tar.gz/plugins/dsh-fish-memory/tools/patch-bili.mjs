/**
 * patch-bili.mjs —— 让「刷 B 站」插件自己那个 Python MCP 闲置就退出
 *
 * 症状：DSH 一开，后台会冒出好几个 python。一个是 SD WebUI（另一份补丁管），
 * 另一个是 `bili-duty/.venv/bin/python mcp_server.py`——刷 B 站插件为了查站
 * 起了一个常驻的 Python MCP 服务，**没有闲置回收**：一次值班/tool 调用把它拉起来，
 * 之后一直挂着，直到宿主退出。
 *
 * 补丁：记住最后一次调用时间；每分钟检查一次，闲置超过 10 分钟就 `stop()` 并把句柄置空。
 * 插件的 `ensureMcp()` 本来就会在句柄为空时重新拉起，所以下次要用照常工作，
 * 只是「不用的时候不占进程」。
 *
 * 用法：
 *   node tools/patch-bili.mjs [--check|--revert] [--file=<path/to/index.js>]
 *
 * @module dsh-fish-memory/tools/patch-bili
 */

import { copyFileSync, existsSync, readFileSync, writeFileSync } from 'node:fs'
import { homedir } from 'node:os'
import { join } from 'node:path'

const MARK = 'FISH_BILI_MCP_IDLE'

const DECL_FROM = "  let mcp = null\n  let mcpKey = ''"
const DECL_TO = "  let mcp = null\n  let mcpKey = ''\n  // 本地补丁（" + MARK + "）：最后一次用 MCP 的时间，供闲置回收用。\n  let mcpLastUsed = 0"

const ENSURE_FROM = "  const ensureMcp = async () => {\n    if (mcp?.running && mcpKey === mcpKeyNow()) return mcp"
const ENSURE_TO = "  const ensureMcp = async () => {\n    mcpLastUsed = Date.now()\n    if (mcp?.running && mcpKey === mcpKeyNow()) return mcp"

const CALLRAW_FROM = "  const callRaw = async (toolName, args, opts) => {\n    const client = await ensureMcp()\n    return client.callRaw(toolName, args, opts)\n  }"
const CALLRAW_TO = CALLRAW_FROM + `

  // 本地补丁（${MARK}）：闲置 10 分钟就把 Python MCP 停掉。
  // 不用的时候不该占一个 python 进程；ensureMcp() 会在下次调用时重新拉起。
  try {
    const idleTimer = setInterval(() => {
      if (mcp === null || mcpLastUsed === 0) return
      if (Date.now() - mcpLastUsed < 10 * 60_000) return
      try { mcp.stop() } catch { /* 已经退出 */ }
      mcp = null
      log('MCP 闲置 10 分钟，已回收 python 进程')
    }, 60_000)
    idleTimer.unref?.()
    ctx.effect(() => () => clearInterval(idleTimer), 'bili-duty: MCP 闲置回收')
  } catch { /* 裁剪版宿主没有 effect 也不影响主流程 */ }`

function targetFile() {
  const explicit = process.argv.find((arg) => arg.startsWith('--file='))
  if (explicit !== undefined) return explicit.slice('--file='.length)
  const home = process.env.DSH_HOME && process.env.DSH_HOME.trim() !== '' ? process.env.DSH_HOME : join(homedir(), '.dsh')
  return join(home, 'profiles', 'desktop', 'node_modules', 'dsh-bili-scroll', 'index.js')
}

function main(argv) {
  const file = targetFile()
  if (!existsSync(file)) {
    console.error(`找不到刷 B 站插件：${file}（用 --file=<path> 指定）`)
    process.exit(1)
  }
  const source = readFileSync(file, 'utf8')
  // 这份文件是 CRLF（插件打包时保留了 Windows 换行）：锚点要跟着换行符走。
  const eol = source.includes('\r\n') ? '\r\n' : '\n'
  const withEol = (text) => text.replace(/\n/g, eol)
  const patched = source.includes(MARK)

  if (argv.includes('--check')) {
    console.log(`${patched ? '已修' : '未修'}：${file}`)
    process.exit(patched ? 0 : 2)
  }
  if (argv.includes('--revert')) {
    if (!patched) {
      console.log('没有补丁，无需撤销')
      return
    }
    let out = source.replace(withEol(DECL_TO), withEol(DECL_FROM))
    out = out.replace(withEol(ENSURE_TO), withEol(ENSURE_FROM))
    out = out.replace(new RegExp(`\\n\\n  // 本地补丁（${MARK}）[\\s\\S]*?\\n  \\} catch \\{ \\/\\* 裁剪版宿主没有 effect 也不影响主流程 \\*\\/ \\}`), '')
    writeFileSync(file, out, 'utf8')
    console.log(`已撤销：${file}`)
    return
  }
  if (patched) {
    console.log('补丁已在，跳过')
    return
  }
  if (!source.includes(withEol(DECL_FROM)) || !source.includes(withEol(ENSURE_FROM)) || !source.includes(withEol(CALLRAW_FROM))) {
    console.error('插件代码变了：找不到 mcp/ensureMcp/callRaw 锚点，补丁需要重写')
    process.exit(3)
  }
  copyFileSync(file, `${file}.pre-fish-bili-idle.bak`)
  let out = source
    .replace(withEol(DECL_FROM), withEol(DECL_TO))
    .replace(withEol(ENSURE_FROM), withEol(ENSURE_TO))
    .replace(withEol(CALLRAW_FROM), withEol(CALLRAW_TO))
  writeFileSync(file, out, 'utf8')
  console.log(`已修：${file}（MCP 闲置 10 分钟自动回收；备份 .pre-fish-bili-idle.bak）`)
}

main(process.argv.slice(2))

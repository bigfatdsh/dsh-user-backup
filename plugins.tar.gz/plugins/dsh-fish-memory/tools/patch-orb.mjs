/**
 * patch-orb.mjs —— 让桌面截图变成「尽力而为」，别拖垮整轮
 *
 * 症状（2026-10-28 21:25 实测，她的微信会话连挂两轮）：
 *
 *   本轮运行失败 computer-use: screen capture failed
 *   (Screen Recording permission is required): … /usr/sbin/screencapture -x -C -R 4,34,708,616 …
 *   failed: could not create image from rect
 *
 * 真相不是「没授权」：同一个进程里 `screencapture -x -R 4,34,708,616` 手动跑是成功的。
 * 真正的原因是**屏幕锁了 / 显示器睡了 / 那个窗口正在消失**时 `-R` 截图会报这句
 * `could not create image from rect`，而 orb 的 `agent/pre-step` 钩子没有任何兜底：
 * 每轮开头都会「把最前面的窗口截一张塞进上下文」，一旦抛错整轮就死——她连话都回不了。
 *
 * 补丁：把那次截图包进 try/catch。失败就不塞观察（这一轮没有屏幕可看），
 * 继续正常回复；她显式调 `screenshot` 时仍然会如实报错。
 *
 * 第二处（backend-*.js）：那句错误提示本身有误导性——它把「锁屏/休眠」也说成
 * 「没有屏幕录制权限」，模型看到会以为是权限问题。改成把三种可能都写出来。
 *
 * 用法：
 *   node tools/patch-orb.mjs [--check|--revert] [--file=<path/to/dist/computer-use>]
 *
 * @module dsh-fish-memory/tools/patch-orb
 */

import { copyFileSync, existsSync, readdirSync, readFileSync, writeFileSync } from 'node:fs'
import { homedir } from 'node:os'
import { join } from 'node:path'

const MARK = 'FISH_ORB_SOFT_CAPTURE'

const FROM = `		const observation = await observeDesktop(ctx, backend, signal, { coordinateMode: mode });
		rememberObservation(agent.session, observation.screens);`

const TO = `		// 本地补丁（${MARK}）：截图失败不能拖垮整轮。
		// 锁屏 / 显示器休眠 / 窗口正在消失时，screencapture -R 会报
		// 「could not create image from rect」；这里退化成「这一轮没有屏幕可看」，
		// 她的回复照常。显式调 screenshot 工具时仍然会如实报错。
		let observation;
		try {
			observation = await observeDesktop(ctx, backend, signal, { coordinateMode: mode });
		} catch (caught) {
			if (signal?.aborted || (caught instanceof Error && caught.name === "AbortError")) throw caught;
			return decision;
		}
		rememberObservation(agent.session, observation.screens);`

const MSG_FROM = 'computer-use: screen capture failed (Screen Recording permission is required): '
const MSG_TO = 'computer-use: screen capture failed（屏幕锁着 / 显示器休眠 / 缺「屏幕录制」权限都会报这句）: '

function targetDir() {
  const explicit = process.argv.find((arg) => arg.startsWith('--file='))
  if (explicit !== undefined) return explicit.slice('--file='.length)
  const home = process.env.DSH_HOME && process.env.DSH_HOME.trim() !== '' ? process.env.DSH_HOME : join(homedir(), '.dsh')
  return join(home, 'profiles', 'desktop', 'node_modules', 'dsh-orb', 'dist', 'computer-use')
}

/** 抓图实现所在的那份 backend-*.js（打包分块名会变，所以按内容找）。 */
function backendFile(dir) {
  try {
    for (const name of readdirSync(dir)) {
      if (!/^backend-.*\.js$/.test(name)) continue
      const text = readFileSync(join(dir, name), 'utf8')
      if (text.includes(MSG_FROM) || text.includes(MSG_TO)) return join(dir, name)
    }
  } catch {
    /* 读不到就当没有 */
  }
  return ''
}

function main(argv) {
  const dir = targetDir()
  const file = join(dir, 'index.js')
  if (!existsSync(file)) {
    console.error(`找不到 dsh-orb：${file}（用 --file=<path/to/dist/computer-use> 指定）`)
    process.exit(1)
  }
  const source = readFileSync(file, 'utf8')
  const softPatched = source.includes(MARK)
  const backend = backendFile(dir)
  const backendText = backend === '' ? '' : readFileSync(backend, 'utf8')
  const msgPatched = backendText.includes(MSG_TO)
  const done = softPatched && (backend === '' || msgPatched)

  if (argv.includes('--check')) {
    console.log(`${done ? '已修' : '未修'}：${dir}`)
    console.log(`  · 截图失败不拖垮整轮：${softPatched ? '✓' : '✗'}`)
    console.log(`  · 错误提示写清锁屏/休眠：${backend === '' ? '—（找不到 backend 文件）' : msgPatched ? '✓' : '✗'}`)
    process.exit(done ? 0 : 2)
  }
  if (argv.includes('--revert')) {
    let changed = false
    if (softPatched) {
      writeFileSync(file, source.replace(TO, FROM), 'utf8')
      changed = true
    }
    if (msgPatched) {
      writeFileSync(backend, backendText.replace(MSG_TO, MSG_FROM), 'utf8')
      changed = true
    }
    console.log(changed ? `已撤销：${dir}` : '没有补丁，无需撤销')
    return
  }
  if (done) {
    console.log('补丁已在，跳过')
    return
  }
  if (!softPatched && !source.includes(FROM)) {
    console.error('orb 代码变了：找不到 observeDesktop 那两行，补丁需要重写')
    process.exit(3)
  }
  if (!softPatched) {
    copyFileSync(file, `${file}.pre-fish-orb.bak`)
    writeFileSync(file, source.replace(FROM, TO), 'utf8')
    console.log(`已修：${file}（截图失败不再拖垮整轮）`)
  }
  if (backend !== '' && !msgPatched && backendText.includes(MSG_FROM)) {
    copyFileSync(backend, `${backend}.pre-fish-orb.bak`)
    writeFileSync(backend, backendText.replace(MSG_FROM, MSG_TO), 'utf8')
    console.log(`已修：${backend}（错误提示写清锁屏/休眠）`)
  }
}

main(process.argv.slice(2))

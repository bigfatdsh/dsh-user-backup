/**
 * rebuild-chatlog.mjs —— 用会话原始记录重建 `~/.dsh-fish/chat-log/`（全文版）
 *
 * 为什么要重建：镜像以前把每条消息截到 200 字才写 chat-log，主人发过的整首歌 / 代码 /
 * 地址在流水里只剩开头（实测 2026-10-29 那首「昨日一去不复回」被截在 207 字，她 11-07
 * 被要求唱歌时翻不到原文）。会话记录里是完整原文，这里按会话重放，重建全文流水：
 *
 *   * 扫 `~/.dsh/sessions/*​/<session>/session*.jsonl.zstd`（多帧 zstd）；
 *   * 取 `source.kind === 'user'` 的消息与她的 assistant 文本；
 *   * 按原时间写 `chat-log/YYYY-MM-DD.md`，行级去重；
 *   * 旧文件整目录备份成 `chat-log.bak-<时间戳>/`。
 *
 * 默认只重建她的主会话（cwd = ~/.dsh-fish/home）；`--all` 连所有会话一起。
 *
 * 用法：
 *   node tools/rebuild-chatlog.mjs --dry-run
 *   node tools/rebuild-chatlog.mjs
 *   node tools/rebuild-chatlog.mjs --all
 *
 * @module dsh-fish-memory/tools/rebuild-chatlog
 */

import { existsSync, mkdirSync, readdirSync, readFileSync, renameSync, writeFileSync } from 'node:fs'
import { homedir } from 'node:os'
import { join } from 'node:path'
import { zstdDecompressSync } from 'node:zlib'

import { channelLabel } from '../lib/fishevents.js'
import { channelOfEnvelope, stripEnvelope } from '../lib/extract.js'

const HOME = homedir()
const DSH_HOME = process.env.DSH_HOME && process.env.DSH_HOME.trim() !== '' ? process.env.DSH_HOME : join(HOME, '.dsh')
const FISH_ROOT = process.env.DSH_FISH_ROOT && process.env.DSH_FISH_ROOT.trim() !== '' ? process.env.DSH_FISH_ROOT : join(HOME, '.dsh-fish')
const FISH_HOME = join(FISH_ROOT, 'home')
const SESSIONS = join(DSH_HOME, 'sessions')
const DRY = process.argv.includes('--dry-run')
const ALL = process.argv.includes('--all')

/** 多帧 zstd → 事件数组。 */
function decode(file) {
  const buf = readFileSync(file)
  const magic = Buffer.from([0x28, 0xb5, 0x2f, 0xfd])
  const offsets = []
  let cursor = 0
  while ((cursor = buf.indexOf(magic, cursor)) !== -1) {
    offsets.push(cursor)
    cursor += 4
  }
  let text = ''
  for (let i = 0; i < offsets.length; i += 1) {
    const end = i + 1 < offsets.length ? offsets[i + 1] : buf.length
    try {
      text += zstdDecompressSync(buf.subarray(offsets[i], end)).toString('utf8')
    } catch {
      /* 尾帧可能不完整 */
    }
  }
  return text.split('\n').map((line) => {
    try {
      return JSON.parse(line)
    } catch {
      return null
    }
  }).filter((row) => row !== null)
}

/** 一条消息的纯文本。 */
function textOf(event) {
  const data = event?.data ?? {}
  const content = Array.isArray(data?.message?.content)
    ? data.message.content
    : Array.isArray(data?.content)
      ? data.content
      : []
  return content
    .filter((block) => block?.type === 'text' && typeof block.text === 'string')
    .map((block) => block.text)
    .join('\n')
    .trim()
}

/** 收集会话：默认只要她的家，`--all` 全要。 */
function collectSessions() {
  const out = []
  if (!existsSync(SESSIONS)) return out
  for (const bucket of readdirSync(SESSIONS)) {
    const bucketPath = join(SESSIONS, bucket)
    let dirs = []
    try {
      dirs = readdirSync(bucketPath)
    } catch {
      continue
    }
    for (const dir of dirs) {
      const full = join(bucketPath, dir)
      let files = []
      try {
        files = readdirSync(full)
      } catch {
        continue
      }
      const transcript = files.find((name) => name.startsWith('session') && name.endsWith('.zstd'))
      if (transcript === undefined) continue
      let header = null
      try {
        header = decode(join(full, transcript)).find((event) => event.type === 'session') ?? null
      } catch {
        continue
      }
      if (!ALL && String(header?.cwd ?? '').replace(/\/+$/, '') !== FISH_HOME) continue
      out.push({ id: dir, file: join(full, transcript) })
    }
  }
  return out
}

/** 把她和他说过的每一句按时间摊平。 */
function collectLines(sessions) {
  const rows = []
  for (const session of sessions) {
    let events = []
    try {
      events = decode(session.file).filter((event) => Number.isFinite(event?.time))
    } catch {
      continue
    }
    let lastChannel = ''
    for (const event of events) {
      if (event.type === 'user/message') {
        if ((event.data?.source ?? {}).kind !== 'user') continue
        const raw = textOf(event)
        if (raw === '') continue
        const said = stripEnvelope(raw)
        if (said === '' || /^（?醒一醒/.test(said)) continue
        lastChannel = channelOfEnvelope(raw) ?? ''
        rows.push({ at: event.time, who: '他', channel: lastChannel, text: said })
      } else if (event.type === 'assistant/message') {
        const said = textOf(event)
        if (said === '') continue
        rows.push({ at: event.time, who: '她', channel: lastChannel, text: said })
      }
    }
  }
  rows.sort((a, b) => a.at - b.at)
  return rows
}

/** 按天分组、行级去重。 */
function groupByDay(rows) {
  const byDay = new Map()
  for (const row of rows) {
    const d = new Date(row.at)
    const day = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`
    const time = `${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}`
    const label = channelLabel(row.channel)
    const line = `- ${time} ${label === '' ? '' : `[${label}] `}${row.who}：${row.text}`
    if (!byDay.has(day)) byDay.set(day, new Set())
    byDay.get(day).add(line)
  }
  return byDay
}

function main() {
  const sessions = collectSessions()
  const rows = collectLines(sessions)
  console.log(`会话 ${sessions.length} 个，消息 ${rows.length} 条${DRY ? '（dry-run）' : ''}`)
  if (rows.length === 0) return
  const byDay = groupByDay(rows)
  const logDir = join(FISH_ROOT, 'chat-log')

  if (DRY) {
    for (const [day, lines] of [...byDay].sort()) console.log(`  ${day}  ${lines.size} 行`)
    return
  }
  if (existsSync(logDir)) {
    const backup = `${logDir}.bak-${new Date().toISOString().replace(/[:.]/g, '-')}`
    renameSync(logDir, backup)
    console.log(`旧 chat-log 已备份：${backup}`)
  }
  mkdirSync(logDir, { recursive: true })
  let total = 0
  for (const [day, lines] of [...byDay].sort()) {
    writeFileSync(join(logDir, `${day}.md`), `${[...lines].sort().join('\n')}\n`, 'utf8')
    total += lines.size
  }
  console.log(`已重建：${byDay.size} 天 / ${total} 行 → ${logDir}`)
}

main()

/**
 * patch-bridge.mjs —— 让微信 / QQ / 她自己的房间共用一个会话
 *
 * 需求：所有渠道共用一个上下文。桥接默认给「每个聊天一个会话 id」
 * （`sessionIdFor(accountId, chatId, generation)` 的哈希），所以这里加一个
 * 本地补丁：**会话 id 跟着大肥鱼的家走**——直接读 `~/.dsh-fish/home.json`
 * 里的 `sessionId`。于是
 *
 *   * 微信所有聊天 → 同一个会话；
 *   * QQ 所有聊天 → 同一个会话；
 *   * 她自己的房间（dsh-fish 的 home.json 指向的那个会话）→ 也是它。
 *
 * 为什么读文件而不是写死 id：`dsh-fish` 会轮换自己的会话（`chat.rotateAfter`），
 * 轮换后 home.json 会更新，桥接下一次取 id 就自动跟过去，不需要人工同步。
 *
 * 副作用（已知、可接受）：
 *   * `/new` 不再换会话（pin 优先于 generation）；
 *   * 多个聊天并发时，回复按「自己那一轮的结束」投递；同一会话里她自己的唤醒
 *     回合可能和聊天交错，桥接等的是自己那条消息的结果。
 *
 * 用法：
 *   node tools/patch-bridge.mjs            # 打补丁（幂等）
 *   node tools/patch-bridge.mjs --check    # 只检查是否已打
 *   node tools/patch-bridge.mjs --revert   # 撤掉补丁
 *
 * 升级 `dsh-wechat-media` 之后补丁会消失，重跑一次即可。
 *
 * @module dsh-fish-memory/tools/patch-bridge
 */

import { existsSync, readFileSync, writeFileSync, copyFileSync } from 'node:fs'
import { homedir } from 'node:os'
import { join } from 'node:path'

const MARK_START = '// ---- FISH_SESSION_PIN'
const MARK_END = '// ---- /FISH_SESSION_PIN'

const HELPER = `${MARK_START}（本地补丁：全部渠道共用一个会话） ----
// 会话 id 跟着「大肥鱼的家」走：读 ~/.dsh-fish/home.json 的 sessionId。
// dsh-fish 轮换自己的会话时会更新 home.json，这里下一次取 id 就自动跟过去。
function fishPinnedSessionId() {
  try {
    const root = process.env.DSH_FISH_ROOT && process.env.DSH_FISH_ROOT.trim() !== ""
      ? process.env.DSH_FISH_ROOT.trim()
      : join(homedir(), ".dsh-fish");
    const raw = readFileSync(join(root, "home.json"), "utf8");
    const id = String(JSON.parse(raw)?.sessionId ?? "").trim();
    return id;
  } catch {
    return "";
  }
}
${MARK_END}
`

const ANCHOR_FN = 'export function sessionIdFor(accountId, chatId, generation = 0) {\n'
const PIN_LINES = '  const pinned = fishPinnedSessionId();\n  if (pinned !== "") return pinned;\n'

function bridgeFile() {
  const explicit = process.argv.find((arg) => arg.startsWith('--file='))
  if (explicit !== undefined) return explicit.slice('--file='.length)
  const home = process.env.DSH_HOME && process.env.DSH_HOME.trim() !== '' ? process.env.DSH_HOME : join(homedir(), '.dsh')
  return join(home, 'profiles', 'desktop', 'node_modules', 'dsh-wechat-media', 'index.js')
}

function main(argv) {
  const file = bridgeFile()
  if (!existsSync(file)) {
    console.error(`找不到桥接：${file}（用 --file=<path> 指定）`)
    process.exit(1)
  }
  const source = readFileSync(file, 'utf8')
  const patched = source.includes(MARK_START)
  if (argv.includes('--check')) {
    console.log(patched ? `已打补丁：${file}` : `未打补丁：${file}`)
    process.exit(patched ? 0 : 2)
  }
  if (argv.includes('--revert')) {
    if (!patched) {
      console.log('没有补丁，无需撤销')
      return
    }
    let out = source.replace(new RegExp(`${escapeRe(MARK_START)}[\\s\\S]*?${escapeRe(MARK_END)}\\n`, 'g'), '')
    out = out.replace(new RegExp(` {2}const pinned = fishPinnedSessionId\\(\\);\\n {2}if \\(pinned !== ""\\) return pinned;\\n`, 'g'), '')
    writeFileSync(file, out, 'utf8')
    console.log(`已撤销：${file}`)
    return
  }
  if (patched) {
    console.log('补丁已在，跳过')
    return
  }
  if (!source.includes(ANCHOR_FN)) {
    console.error('桥接代码变了：找不到 sessionIdFor，补丁需要重写')
    process.exit(3)
  }
  copyFileSync(file, `${file}.pre-fish-pin.bak`)
  let out = source.replace(ANCHOR_FN, `${HELPER}\n${ANCHOR_FN}${PIN_LINES}`)
  writeFileSync(file, out, 'utf8')
  console.log(`已打补丁：${file}`)
  console.log('备份：' + `${file}.pre-fish-pin.bak`)
}

function escapeRe(text) {
  return text.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')
}

main(process.argv.slice(2))

/**
 * patch-drop-legacy-preset.mjs —— 删掉遗留的「旧·鲸鱼娘·大肥鱼（微信精简）」预设
 *
 * 2026-10-29 的决定：她的会话已经稳定跑在 `fish-home`（大肥鱼本体），旧预设只为 2026-10
 * 之前的历史会话留着，没有任何现行链路引用它。用户确认「删咯，不影响大肥鱼」，于是：
 *
 *   * 从这个 preset 的两层定义里各删掉整块（`- id: preset-whale-lean`）：
 *     插件包 `dsh-wechat-media-turbo` 一份、忆时 bundle `dsh-yishi-whale` 一份（后者胜出）；
 *   * 删空的那个文件写成 `[]`（Loader 接受空数组；留纯注释会解析成 null 报错——实测过）；
 *   * 原来的 `.bak` 保留，`--revert` 能整份还原。
 *
 * 影响：13 条历史会话（agentPreset=whale-lean）下次打开会找不到原预设、回落默认预设。
 *
 * 用法：
 *   node tools/patch-drop-legacy-preset.mjs [--check|--revert]
 *
 * @module dsh-fish-memory/tools/patch-drop-legacy-preset
 */

import { copyFileSync, existsSync, readFileSync, writeFileSync } from 'node:fs'
import { homedir } from 'node:os'
import { join } from 'node:path'

const PRESET_ID = 'preset-whale-lean'
const MARK = 'FISH_DROP_LEGACY_PRESET'
const FILES = ['dsh-wechat-media-turbo', 'dsh-yishi-whale']

const BLANK = `# ${MARK}：这个 bundle 里的旧预设（preset-whale-lean）已在 2026-10-29 删除，
# 现在不挂任何行；留空数组是为了让 Loader 仍然能解析这份 patch。
[]
`

function targets() {
  const home = process.env.DSH_HOME && process.env.DSH_HOME.trim() !== '' ? process.env.DSH_HOME : join(homedir(), '.dsh')
  return FILES.map((name) => join(home, 'profiles', 'desktop', 'node_modules', name, 'cordis.patch.yml'))
}

/**
 * 删掉定义该 preset 的那一块（可能在顶层，也可能缩在 `- insert:` 下面）。
 *
 * @param {string} text 文件内容。
 * @param {string} id 预设行 id。
 * @returns {string|null} 删完的内容；没找到返回 null。
 */
function dropBlock(text, id) {
  const lines = text.split('\n')
  const start = lines.findIndex((line) => line.trim() === `- id: ${id}`)
  if (start < 0) return null
  const indent = lines[start].match(/^ */)[0].length
  let end = lines.length
  for (let i = start + 1; i < lines.length; i += 1) {
    const line = lines[i]
    if (line.trim() === '') continue
    const own = line.match(/^ */)[0].length
    if (own <= indent && line.trim().startsWith('- id: ')) {
      end = i
      break
    }
    if (own < indent) {
      end = i
      break
    }
  }
  let out = [...lines.slice(0, start), ...lines.slice(end)]
  // `- insert:` 下面如果被删空了，把这条壳也去掉（保留空 insert 会让 Loader 报错）。
  const cleaned = []
  for (let i = 0; i < out.length; i += 1) {
    const line = out[i]
    if (line.trim() === '- insert:') {
      let next = i + 1
      while (next < out.length && out[next].trim() === '') next += 1
      const childIndent = next < out.length ? out[next].match(/^ */)[0].length : 0
      if (next >= out.length || childIndent <= line.match(/^ */)[0].length) {
        // 空壳：跳过它和紧随的一个空行
        if (out[next] !== undefined && out[next].trim() === '') i = next
        continue
      }
    }
    cleaned.push(line)
  }
  return cleaned.join('\n')
}

function stateOf(file) {
  const text = readFileSync(file, 'utf8')
  return {
    text,
    dropped: !text.split('\n').some((line) => line.trim() === `- id: ${PRESET_ID}`),
    marked: text.includes(MARK),
  }
}

function main(argv) {
  const files = targets()
  const existing = files.filter((file) => existsSync(file))
  if (existing.length === 0) {
    console.error('找不到插件的 cordis.patch.yml（用 DSH_HOME 指定）')
    process.exit(1)
  }
  if (argv.includes('--check')) {
    const bad = existing.filter((file) => !stateOf(file).dropped)
    console.log(bad.length === 0 ? `已删：${existing.length} 份都干净` : `未删：${bad.join('、')}`)
    process.exit(bad.length === 0 ? 0 : 2)
  }
  if (argv.includes('--revert')) {
    for (const file of existing) {
      const backup = `${file}.pre-fish-drop.bak`
      if (existsSync(backup)) {
        copyFileSync(backup, file)
        console.log(`已还原：${file}`)
      } else {
        console.log(`没有备份可还原：${file}`)
      }
    }
    return
  }
  for (const file of existing) {
    const state = stateOf(file)
    if (state.dropped) {
      console.log(`已在：${file}`)
      continue
    }
    const backup = `${file}.pre-fish-drop.bak`
    if (!existsSync(backup)) copyFileSync(file, backup)
    const droppedText = dropBlock(state.text, PRESET_ID)
    const emptyNow = !droppedText.split('\n').some((line) => line.startsWith('- id: '))
    const header = state.marked ? '' : `# ${MARK}：旧预设 preset-whale-lean 已删除（2026-10-29）。\n`
    writeFileSync(file, emptyNow ? BLANK : `${header}${droppedText}`, 'utf8')
    console.log(`已删：${file}（备份 ${backup.split('/').pop()}）`)
  }
}

main(process.argv.slice(2))
